<?php
/**
 * Les réglages du plugin.
 *
 * Ils tiennent en une option, et en six lignes. Un plugin qui se réinstalle
 * sur d'autres sites doit avoir des valeurs par défaut justes, pas un écran de
 * réglages long : tout ce qui est ici a une valeur qui marche sans y toucher.
 *
 * @package BlocsCreator
 */

defined( 'ABSPATH' ) || exit;

/**
 * Lecture et écriture des réglages.
 */
class BC_Reglages {

	/**
	 * Nom de l'option.
	 */
	const OPTION = 'blocs_creator_reglages';

	/**
	 * Valeurs en cache.
	 *
	 * @var array|null
	 */
	private $valeurs = null;

	/**
	 * Branche les hooks.
	 */
	public function demarrer() {
		add_action( 'admin_init', array( $this, 'declarer' ) );
	}

	/**
	 * Retourne les valeurs par défaut.
	 *
	 * L'espace de noms se déduit du nom du site : sur « Cabinet Martin », les
	 * blocs s'appelleront `cabinet-martin/…`. C'est ce qu'on aurait écrit à la
	 * main, et ça évite d'avoir deux sites dont les blocs portent le même nom
	 * le jour où l'on copie un contenu de l'un vers l'autre.
	 *
	 * @return array
	 */
	public static function defauts() {
		$espace = sanitize_key( sanitize_title( get_bloginfo( 'name' ) ) );

		if ( '' === $espace || is_numeric( $espace ) ) {
			$espace = 'blocs';
		}

		return array(
			'espace'             => $espace,
			'categorie'          => 'blocs-creator',
			'categorie_titre'    => __( 'Mes blocs', 'blocs-creator' ),
			'dossier_gabarits'   => 'blocs',
			'creer_gabarit'      => true,
			'supprimer_donnees'  => false,
		);
	}

	/**
	 * Retourne toutes les valeurs.
	 *
	 * @return array
	 */
	public function tout() {
		if ( null === $this->valeurs ) {
			$this->valeurs = wp_parse_args(
				(array) get_option( self::OPTION, array() ),
				self::defauts()
			);
		}

		return $this->valeurs;
	}

	/**
	 * Retourne un réglage.
	 *
	 * @param string $cle Nom du réglage.
	 * @return mixed
	 */
	public function get( $cle ) {
		$tout = $this->tout();

		return $tout[ $cle ] ?? null;
	}

	/**
	 * Écrit les réglages.
	 *
	 * @param array $valeurs Nouvelles valeurs.
	 */
	public function set( $valeurs ) {
		$this->valeurs = null;

		update_option( self::OPTION, $this->assainir( (array) $valeurs ) );
	}

	/**
	 * Déclare l'option auprès de l'API des réglages.
	 */
	public function declarer() {
		register_setting(
			'blocs_creator_reglages',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'assainir' ),
				'default'           => self::defauts(),
			)
		);
	}

	/**
	 * Nettoie les réglages soumis.
	 *
	 * @param array $valeurs Valeurs brutes.
	 * @return array
	 */
	public function assainir( $valeurs ) {
		$defauts = self::defauts();
		$propres = array();

		$espace = sanitize_key( (string) ( $valeurs['espace'] ?? '' ) );
		$espace = preg_replace( '/[^a-z0-9-]/', '', $espace );

		$propres['espace']    = ( '' !== $espace && ! is_numeric( $espace ) ) ? $espace : $defauts['espace'];
		$propres['categorie'] = sanitize_key( (string) ( $valeurs['categorie'] ?? '' ) );

		if ( '' === $propres['categorie'] ) {
			$propres['categorie'] = $defauts['categorie'];
		}

		$propres['categorie_titre'] = sanitize_text_field( (string) ( $valeurs['categorie_titre'] ?? '' ) );

		if ( '' === $propres['categorie_titre'] ) {
			$propres['categorie_titre'] = $defauts['categorie_titre'];
		}

		// Un chemin de gabarits reste relatif au thème : ni racine absolue,
		// ni remontée de dossier.
		$dossier = trim( (string) ( $valeurs['dossier_gabarits'] ?? '' ), "/ \t\n\r\0\x0B" );
		$dossier = str_replace( '..', '', $dossier );
		$dossier = preg_replace( '#[^a-zA-Z0-9/_-]#', '', $dossier );

		$propres['dossier_gabarits']  = '' !== $dossier ? $dossier : $defauts['dossier_gabarits'];
		$propres['creer_gabarit']     = ! empty( $valeurs['creer_gabarit'] );
		$propres['supprimer_donnees'] = ! empty( $valeurs['supprimer_donnees'] );

		$this->valeurs = null;

		return $propres;
	}

	/**
	 * Retourne une sélection d'icônes Dashicons pour le sélecteur.
	 *
	 * Pas les trois cents : celles qui servent vraiment à nommer un bloc.
	 * Le champ reste libre, on peut y taper n'importe quel nom de Dashicon.
	 *
	 * @return array<int, string>
	 */
	public static function dashicons() {
		return array(
			'block-default', 'layout', 'align-wide', 'align-full-width', 'align-pull-left', 'align-pull-right',
			'columns', 'grid-view', 'list-view', 'screenoptions', 'menu-alt3', 'editor-table',
			'editor-alignleft', 'editor-aligncenter', 'editor-quote', 'editor-ul', 'editor-ol', 'editor-code',
			'format-image', 'format-gallery', 'format-video', 'format-audio', 'format-quote', 'format-aside',
			'images-alt', 'images-alt2', 'camera', 'video-alt3', 'media-document', 'media-spreadsheet',
			'admin-links', 'admin-page', 'admin-post', 'admin-users', 'admin-comments', 'admin-appearance',
			'star-filled', 'heart', 'awards', 'megaphone', 'lightbulb', 'flag',
			'calendar-alt', 'clock', 'location', 'email-alt', 'phone', 'businessperson',
			'cart', 'tag', 'tickets-alt', 'money-alt', 'chart-bar', 'analytics',
			'yes-alt', 'info-outline', 'warning', 'sos', 'shield', 'lock',
			'smiley', 'palmtree', 'universal-access', 'groups', 'testimonial', 'welcome-learn-more',
		);
	}
}
