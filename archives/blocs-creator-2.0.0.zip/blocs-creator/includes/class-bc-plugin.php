<?php
/**
 * Bootstrap du plugin.
 *
 * Une seule instance, un seul point de chargement. Les classes sont requises
 * ici plutôt que par un autoloader : à quinze fichiers, une liste explicite se
 * lit mieux qu'une convention de nommage.
 *
 * @package BlocsCreator
 */

defined( 'ABSPATH' ) || exit;

/**
 * Le plugin.
 */
final class BC_Plugin {

	/**
	 * Instance unique.
	 *
	 * @var BC_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Le registre des blocs.
	 *
	 * @var BC_Registre
	 */
	public $registre;

	/**
	 * Les réglages.
	 *
	 * @var BC_Reglages
	 */
	public $reglages;

	/**
	 * Les packs chargés.
	 *
	 * @var array<string, array>
	 */
	private $packs = array();

	/**
	 * Les packs laissés de côté, et le plugin qui les bloque.
	 *
	 * @var array<string, array<int, string>>
	 */
	private $conflits = array();

	/**
	 * Retourne l'instance unique.
	 *
	 * @return BC_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructeur privé : on passe par instance().
	 */
	private function __construct() {}

	/**
	 * Charge les fichiers et branche les hooks.
	 */
	public function demarrer() {
		$this->charger();

		$this->reglages = new BC_Reglages();
		$this->registre = new BC_Registre();

		/*
		 * Depuis WordPress 6.7, charger un domaine de traduction avant `init`
		 * vaut un avertissement : la priorité 0 le place au plus tôt de ce qui
		 * est permis, avant que nos propres hooks d'`init` n'appellent __().
		 */
		add_action( 'init', array( $this, 'traductions' ), 0 );
		add_action( 'plugins_loaded', array( $this, 'charger_packs' ), 20 );
		add_action( 'admin_notices', array( $this, 'notice_conflit' ) );

		$this->reglages->demarrer();
		$this->registre->demarrer();

		BC_Rendu::demarrer();
		BC_Rest::demarrer();

		if ( is_admin() ) {
			( new BC_Admin() )->demarrer();
		}
	}

	/**
	 * Requiert les fichiers du plugin.
	 */
	private function charger() {
		$fichiers = array(
			'includes/class-bc-reglages.php',
			'includes/class-bc-champs.php',
			'includes/class-bc-definition.php',
			'includes/class-bc-registre.php',
			'includes/class-bc-rendu.php',
			'includes/class-bc-gabarits.php',
			'includes/class-bc-usage.php',
			'includes/class-bc-rest.php',
			'includes/fonctions.php',
		);

		if ( is_admin() ) {
			$fichiers[] = 'admin/class-bc-admin.php';
			$fichiers[] = 'admin/class-bc-ecran-definition.php';
			$fichiers[] = 'admin/class-bc-outils.php';
		}

		foreach ( $fichiers as $fichier ) {
			require_once BLOCS_CREATOR_DIR . $fichier;
		}
	}

	/**
	 * Charge le domaine de traduction.
	 */
	public function traductions() {
		load_plugin_textdomain(
			'blocs-creator',
			false,
			dirname( plugin_basename( BLOCS_CREATOR_FICHIER ) ) . '/languages'
		);
	}

	/**
	 * Charge les packs de blocs codés.
	 *
	 * Un pack est un dossier de `packs/` portant un `pack.php`. Ce fichier est
	 * inclus une fois, avant `init`, et retourne ses métadonnées. Ses blocs —
	 * les dossiers de `blocs/` qui ont un `block.json` — sont enregistrés par
	 * le registre, pas par le pack : c'est ce qui garantit que l'écran « Tous
	 * les blocs » montre exactement ce qui tourne.
	 *
	 * Supprimer un dossier de pack suffit à le retirer. Aucune trace en base,
	 * aucun réglage à nettoyer.
	 */
	public function charger_packs() {
		$racine = BLOCS_CREATOR_DIR . 'packs';

		if ( ! is_dir( $racine ) ) {
			return;
		}

		foreach ( (array) glob( $racine . '/*/pack.php' ) as $fichier ) {
			$slug = basename( dirname( $fichier ) );

			/**
			 * Filtre le chargement d'un pack.
			 *
			 * Permet à un site de désactiver un pack sans supprimer son
			 * dossier — le temps d'un diagnostic, par exemple.
			 *
			 * @param bool   $charger Faut-il charger ce pack.
			 * @param string $slug    Identifiant du pack.
			 */
			if ( ! apply_filters( 'blocs_creator_charger_pack', true, $slug ) ) {
				continue;
			}

			/*
			 * Un pack qui reprend le code d'un ancien plugin ne peut pas
			 * cohabiter avec lui : les deux déclarent les mêmes fonctions, et
			 * PHP s'arrête net. On lit l'en-tête sans exécuter le fichier, et
			 * on s'abstient tant que le prédécesseur est actif.
			 */
			$remplaces = self::plugins_remplaces( $fichier, true );

			if ( ! empty( $remplaces ) ) {
				$this->conflits[ $slug ] = $remplaces;
				continue;
			}

			$meta = include_once $fichier;

			$this->packs[ $slug ] = wp_parse_args(
				is_array( $meta ) ? $meta : array(),
				array(
					'nom'         => $slug,
					'description' => '',
					'auteur'      => '',
					'version'     => '',
					'dossier'     => dirname( $fichier ),
				)
			);

			$this->packs[ $slug ]['dossier'] = dirname( $fichier );
		}
	}

	/**
	 * Retourne les packs chargés.
	 *
	 * @return array<string, array>
	 */
	public function packs() {
		return $this->packs;
	}

	/**
	 * Retourne un pack par son identifiant.
	 *
	 * @param string $slug Identifiant du pack.
	 * @return array|null
	 */
	public function pack( $slug ) {
		return $this->packs[ $slug ] ?? null;
	}

	/**
	 * Retourne les plugins qu'un pack remplace.
	 *
	 * L'en-tête `Replaces` est lu avec get_file_data(), qui ne lit que le
	 * premier bloc de commentaire : le fichier n'est pas exécuté, donc ses
	 * constantes et ses fonctions ne sont pas déclarées. C'est ce qui permet
	 * de poser la question sans provoquer le conflit qu'on cherche à éviter.
	 *
	 * @param string $fichier Chemin du pack.php.
	 * @param bool   $actifs  Ne retourner que les plugins actuellement actifs.
	 * @return array<int, string>
	 */
	private static function plugins_remplaces( $fichier, $actifs = false ) {
		$entete = get_file_data( $fichier, array( 'remplace' => 'Replaces' ) );
		$liste  = array_filter( array_map( 'trim', explode( ',', (string) $entete['remplace'] ) ) );

		if ( ! $actifs ) {
			return $liste;
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return array_values( array_filter( $liste, 'is_plugin_active' ) );
	}

	/**
	 * Prévient qu'un pack attend qu'on retire son prédécesseur.
	 *
	 * Le site tourne, mais sans les blocs du pack : mieux vaut le dire que de
	 * laisser chercher.
	 */
	public function notice_conflit() {
		if ( empty( $this->conflits ) || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		foreach ( $this->conflits as $slug => $remplaces ) {
			printf(
				'<div class="notice notice-warning"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: identifiant du pack, 2: liste de plugins. */
						__( 'Blocs Creator : le pack « %1$s » attend que vous désactiviez %2$s, dont il reprend le code. Ses blocs ne sont pas disponibles d\'ici là.', 'blocs-creator' ),
						$slug,
						implode( ', ', $remplaces )
					)
				)
			);
		}
	}

	/**
	 * À l'activation : déclarer le type de contenu, puis rafraîchir les
	 * permaliens et le cache des blocs.
	 *
	 * C'est aussi ici qu'on écarte les plugins que nos packs remplacent. Les
	 * laisser actifs, c'est deux déclarations des mêmes fonctions et un site
	 * blanc : mieux vaut désactiver d'office que planter poliment.
	 */
	public static function activation() {
		self::desactiver_predecesseurs();

		BC_Definition::declarer_type();
		flush_rewrite_rules();

		BC_Usage::vider_cache();

		if ( false === get_option( 'blocs_creator_reglages' ) ) {
			add_option( 'blocs_creator_reglages', BC_Reglages::defauts() );
		}

		update_option( 'blocs_creator_version', BLOCS_CREATOR_VERSION );
	}

	/**
	 * Désactive les plugins que les packs présents remplacent.
	 *
	 * @return array<int, string> Les plugins désactivés.
	 */
	private static function desactiver_predecesseurs() {
		$racine = BLOCS_CREATOR_DIR . 'packs';

		if ( ! is_dir( $racine ) ) {
			return array();
		}

		$a_retirer = array();

		foreach ( (array) glob( $racine . '/*/pack.php' ) as $fichier ) {
			$a_retirer = array_merge( $a_retirer, self::plugins_remplaces( $fichier, true ) );
		}

		$a_retirer = array_unique( $a_retirer );

		if ( empty( $a_retirer ) ) {
			return array();
		}

		if ( ! function_exists( 'deactivate_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		// `true` : on ne déclenche pas leurs hooks de désactivation. Ils
		// viennent d'être remplacés, pas retirés — rien à nettoyer.
		deactivate_plugins( $a_retirer, true );

		update_option( 'blocs_creator_predecesseurs', array_values( $a_retirer ) );

		return array_values( $a_retirer );
	}

	/**
	 * À la désactivation : rien à détruire, juste les caches à vider.
	 *
	 * Les définitions de blocs restent en base et les gabarits sur le disque :
	 * désactiver n'est pas désinstaller.
	 */
	public static function desactivation() {
		BC_Usage::vider_cache();
		flush_rewrite_rules();
	}
}
