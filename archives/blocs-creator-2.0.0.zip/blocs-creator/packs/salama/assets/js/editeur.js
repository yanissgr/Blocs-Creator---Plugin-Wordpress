/*
 * Éditeur des blocs Salama.
 *
 * Écrit en JavaScript natif : `wp.element.createElement` plutôt que du JSX,
 * parce que le thème n'a aucun outil de build et qu'on ne lui en impose pas un
 * pour huit blocs. Plus verbeux, mais lisible et modifiable sans
 * `npm install`.
 *
 * Deux règles tiennent ce fichier, et valent pour tout bloc à venir :
 *
 *   1. L'APERÇU NE MENT PAS. Chaque `edit` produit les mêmes classes que le
 *      rendu PHP, et les feuilles du thème (jetons, composants) sont chargées
 *      dans l'éditeur : ce qu'on voit ici est ce que le visiteur verra. Quand
 *      un bloc dépend de données du site — les publications d'un carrousel —
 *      il en demande le rendu au serveur plutôt que de le redessiner.
 *
 *   2. LE RÉGLAGE EST LÀ OÙ SE TROUVE LA CHOSE. Ce qui s'écrit s'écrit dans le
 *      bloc (RichText), ce qui se choisit d'un geste est dans la barre d'outils
 *      (niveau de titre, sens de l'image, lien), et la colonne de droite ne
 *      garde que ce qui ne se montre pas — la source des publications, le
 *      décor. Un panneau de moins, c'est un aller-retour de moins.
 *
 * Les blocs sont déclarés côté PHP par leurs block.json : attributs, titre,
 * catégorie, variantes et supports viennent de là. Ce fichier ne fournit que
 * `edit` et `save` — le reste serait de la redite, donc de la dérive en
 * puissance.
 */

( function ( wp ) {
	'use strict';

	var el        = wp.element.createElement;
	var Fragment  = wp.element.Fragment;
	var useState  = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var __        = wp.i18n.__;
	var sprintf   = wp.i18n.sprintf;

	var registerBlockType = wp.blocks.registerBlockType;

	var be                  = wp.blockEditor;
	var useBlockProps       = be.useBlockProps;
	var useInnerBlocksProps = be.useInnerBlocksProps;
	var InnerBlocks         = be.InnerBlocks;
	var RichText            = be.RichText;
	var BlockControls       = be.BlockControls;
	var InspectorControls   = be.InspectorControls;
	var MediaPlaceholder    = be.MediaPlaceholder;
	var MediaReplaceFlow    = be.MediaReplaceFlow;
	var URLInput            = be.URLInput;

	/*
	 * Composants que WordPress a stabilisés au fil des versions. On prend le
	 * nom définitif s'il existe, l'expérimental sinon, et on se replie sur un
	 * champ de la colonne de droite si aucun des deux n'est là : un bloc doit
	 * rester réglable même sur une version plus ancienne.
	 */
	var HeadingLevelDropdown = be.HeadingLevelDropdown || be.__experimentalHeadingLevelDropdown || null;
	var LinkControl          = be.LinkControl || be.__experimentalLinkControl || null;

	var FocalPointPicker = wp.components.FocalPointPicker;
	var PanelBody      = wp.components.PanelBody;
	var Button         = wp.components.Button;
	var ToggleControl  = wp.components.ToggleControl;
	var SelectControl  = wp.components.SelectControl;
	var RangeControl   = wp.components.RangeControl;
	var BaseControl    = wp.components.BaseControl;
	var Notice         = wp.components.Notice;
	var Spinner        = wp.components.Spinner;
	var ToolbarGroup   = wp.components.ToolbarGroup;
	var ToolbarButton  = wp.components.ToolbarButton;
	var Popover        = wp.components.Popover;

	var useSelect     = wp.data.useSelect;
	var apiFetch      = wp.apiFetch;
	var addQueryArgs  = wp.url.addQueryArgs;

	/* -------------------------------------------------------------- *
	 * Aides communes
	 * -------------------------------------------------------------- */

	/**
	 * Lit un média de la médiathèque.
	 *
	 * @param {number} id Identifiant du média.
	 * @return {Object|null} Le média, ou null tant qu'il n'est pas chargé.
	 */
	function useMedia( id ) {
		return useSelect(
			function ( select ) {
				return id ? select( 'core' ).getMedia( id ) : null;
			},
			[ id ]
		);
	}

	/**
	 * Aperçu de l'image dans l'éditeur, ou surface d'attente.
	 *
	 * Le rendu public passe par salama_blocs_image() : ici on ne reproduit que
	 * ce qu'il faut pour que l'aperçu ressemble au site.
	 *
	 * @param {Object|null} media Média chargé.
	 * @return {Object} Élément React.
	 */
	function apercu( media ) {
		if ( media && media.source_url ) {
			return el( 'img', {
				src: media.source_url,
				alt: media.alt_text || '',
			} );
		}

		return el( 'span', {
			className: 'salama-blocs__attente',
			'aria-hidden': 'true',
		} );
	}

	/**
	 * Niveau de titre, dans la barre d'outils du bloc.
	 *
	 * Le même bouton que sur un bloc Titre natif : la rédaction le connaît
	 * déjà, et le réglage se trouve à côté du titre plutôt qu'au fond de la
	 * colonne de droite.
	 *
	 * Le plafond n'est pas une coquetterie : un bloc dont le rendu borne le
	 * niveau doit borner la liste au même endroit, sinon la rédaction choisit
	 * un niveau que le site n'écrira jamais.
	 *
	 * @param {number}   niveau   Niveau courant.
	 * @param {Function} onChange Rappel.
	 * @param {number}   minimum  Niveau le plus haut proposé.
	 * @param {number}   maximum  Niveau le plus bas proposé. 6 par défaut.
	 * @return {Object|null} Élément React, ou null sans le composant natif.
	 */
	function barreNiveau( niveau, onChange, minimum, maximum ) {
		if ( ! HeadingLevelDropdown ) {
			return null;
		}

		var niveaux = [];

		for ( var n = minimum || 2; n <= ( maximum || 6 ); n++ ) {
			niveaux.push( n );
		}

		return el(
			BlockControls,
			{ group: 'block' },
			el( HeadingLevelDropdown, {
				value: niveau,
				// `options` depuis WordPress 6.6, `levels` avant : passer les
				// deux coûte un mot et évite d'avoir à tester la version.
				options: niveaux,
				levels: niveaux,
				onChange: onChange,
			} )
		);
	}

	/**
	 * Niveau de titre, en repli dans la colonne de droite.
	 *
	 * N'est rendu que si la barre d'outils n'a pas pu l'accueillir : deux
	 * commandes pour le même réglage sèmeraient le doute.
	 *
	 * @param {number}   niveau   Niveau courant.
	 * @param {Function} onChange Rappel.
	 * @param {number}   minimum  Niveau le plus haut proposé.
	 * @param {number}   maximum  Niveau le plus bas proposé. 6 par défaut.
	 * @return {Object|null} Élément React.
	 */
	function champNiveau( niveau, onChange, minimum, maximum ) {
		if ( HeadingLevelDropdown ) {
			return null;
		}

		var options = [];

		for ( var n = minimum || 2; n <= ( maximum || 6 ); n++ ) {
			options.push( { label: 'H' + n, value: String( n ) } );
		}

		return el( SelectControl, {
			label: __( 'Niveau du titre', 'salama-blocs' ),
			value: String( niveau ),
			options: options,
			onChange: function ( valeur ) {
				onChange( parseInt( valeur, 10 ) );
			},
			__nextHasNoMarginBottom: true,
		} );
	}

	/**
	 * Bouton « Remplacer l'image » de la barre d'outils du bloc.
	 *
	 * @param {number}      id       Identifiant du média courant.
	 * @param {Object|null} media    Média chargé.
	 * @param {Function}    onSelect Rappel de sélection.
	 * @return {Object|null} Élément React, ou null s'il n'y a pas d'image.
	 */
	function barreImage( id, media, onSelect ) {
		if ( ! id ) {
			return null;
		}

		return el(
			BlockControls,
			{ group: 'other' },
			el( MediaReplaceFlow, {
				mediaId: id,
				mediaURL: media ? media.source_url : '',
				allowedTypes: [ 'image' ],
				accept: 'image/*',
				onSelect: onSelect,
				name: __( "Remplacer l'image", 'salama-blocs' ),
			} )
		);
	}

	/**
	 * Sélecteur d'image affiché tant qu'aucune n'est choisie.
	 *
	 * @param {string}   titre    Intitulé du sélecteur.
	 * @param {Function} onSelect Rappel de sélection.
	 * @return {Object} Élément React.
	 */
	function choixImage( titre, onSelect ) {
		return el( MediaPlaceholder, {
			icon: 'format-image',
			labels: { title: titre, instructions: '' },
			allowedTypes: [ 'image' ],
			accept: 'image/*',
			onSelect: onSelect,
		} );
	}

	/* -------------------------------------------------------------- *
	 * Salama — Lien avec icône
	 * -------------------------------------------------------------- */
	registerBlockType( 'salama/lien-icone', {
		edit: function ( props ) {
			var a = props.attributes;
			var set = props.setAttributes;
			var media = useMedia( a.imageId );
			var blockProps = useBlockProps( { className: 'salama-lien-icone' } );
			var choisir = function ( image ) { set( { imageId: image.id } ); };
			return el( Fragment, null,
				barreImage( a.imageId, media, choisir ),
				el( InspectorControls, null,
					el( PanelBody, { title: __( 'Lien', 'salama-blocs' ) },
						el( BaseControl, {
							label: __( 'Destination', 'salama-blocs' ),
							id: 'salama-lien-icone-url-' + props.clientId,
							help: __( 'Recherchez une page ou saisissez une adresse, tel:+33612345678 ou mailto:contact@exemple.fr.', 'salama-blocs' ),
						}, el( URLInput, {
							id: 'salama-lien-icone-url-' + props.clientId,
							value: a.url,
							onChange: function ( value ) { set( { url: value } ); },
						} ) ),
						el( ToggleControl, {
							label: __( 'Ouvrir dans un nouvel onglet', 'salama-blocs' ),
							checked: !! a.nouvelOnglet,
							onChange: function ( value ) { set( { nouvelOnglet: value } ); },
							__nextHasNoMarginBottom: true,
						} ),
						! a.url ? el( Notice, { status: 'warning', isDismissible: false }, __( 'Ajoutez une destination pour rendre le lien cliquable.', 'salama-blocs' ) ) : null
					),
					el( PanelBody, { title: __( 'Image de l’icône', 'salama-blocs' ) },
						choixImage( __( 'Choisir ou remplacer l’icône', 'salama-blocs' ), choisir ),
						a.imageId ? el( Button, {
							variant: 'secondary',
							isDestructive: true,
							onClick: function () { set( { imageId: 0 } ); },
						}, __( 'Retirer l’icône', 'salama-blocs' ) ) : null
					)
				),
				el( 'div', blockProps,
					el( 'span', { className: 'salama-lien-icone__lien' },
						a.imageId && media && media.source_url ? el( 'img', {
							className: 'salama-lien-icone__image', src: media.source_url, alt: '', 'aria-hidden': true,
						} ) : null,
						el( RichText, {
							tagName: 'span', className: 'salama-lien-icone__libelle',
							value: a.libelle, allowedFormats: [],
							placeholder: __( 'Texte du lien…', 'salama-blocs' ),
							onChange: function ( value ) { set( { libelle: value } ); },
						} )
					)
				)
			);
		},
		save: function () { return null; },
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Contact
	 * -------------------------------------------------------------- */

	registerBlockType( 'salama/contact', {
		edit: function ( props ) {
			var a = props.attributes;
			var niveau = Math.min( 6, Math.max( 2, a.niveau || 2 ) );
			var blockProps = useBlockProps( { className: 'salama-contact' } );
			var changerNiveau = function ( n ) { props.setAttributes( { niveau: n } ); };
			var repli = champNiveau( niveau, changerNiveau );
			function champ( libelle, type, placeholder ) {
				return el( 'label', { className: 'salama-contact__champ' },
					el( 'span', { className: 'salama-contact__libelle' }, libelle ),
					type === 'textarea'
						? el( 'textarea', { disabled: true, rows: 5 } )
						: el( 'input', { type: type, disabled: true, placeholder: placeholder } )
				);
			}
			return el( Fragment, null,
				barreNiveau( niveau, changerNiveau ),
				repli ? el( InspectorControls, null,
					el( PanelBody, { title: __( 'Titre', 'salama-blocs' ) }, repli )
				) : null,
				el( 'div', blockProps,
					el( RichText, {
						tagName: 'h' + niveau,
						className: 'salama-contact__titre',
						value: a.titre,
						allowedFormats: [ 'core/bold', 'core/italic' ],
						placeholder: __( 'Titre du formulaire…', 'salama-blocs' ),
						onChange: function ( titre ) { props.setAttributes( { titre: titre } ); },
					} ),
					el( 'div', { className: 'salama-contact__panneau' },
						el( 'div', { className: 'salama-contact__champ' },
							el( 'span', { className: 'salama-contact__libelle' }, __( 'Nom', 'salama-blocs' ) ),
							el( 'div', { className: 'salama-contact__identite' },
								el( 'input', { type: 'text', disabled: true, 'aria-label': __( 'Prénom', 'salama-blocs' ), placeholder: __( 'Prénom', 'salama-blocs' ) } ),
								el( 'input', { type: 'text', disabled: true, 'aria-label': __( 'Nom', 'salama-blocs' ), placeholder: __( 'Nom', 'salama-blocs' ) } )
							)
						),
						champ( __( 'Mail', 'salama-blocs' ), 'email', __( 'Adresse mail', 'salama-blocs' ) ),
						champ( __( 'Téléphone', 'salama-blocs' ), 'tel', '06 00 00 00 00' ),
						champ( __( 'Sujet du message', 'salama-blocs' ), 'text', __( 'Demande', 'salama-blocs' ) ),
						champ( __( 'Message', 'salama-blocs' ), 'textarea' ),
						el( 'div', { className: 'salama-contact__actions' },
							el( 'button', { className: 'salama-contact__bouton', type: 'button', disabled: true }, __( 'Envoyer', 'salama-blocs' ) )
						)
					)
				)
			);
		},
		save: function () { return null; },
	} );

	/* Salama — Titre avec flag. */
	registerBlockType( 'salama/titre-flag', {
		edit: function ( props ) {
			var a = props.attributes;
			var set = props.setAttributes;
			var niveau = Math.min( 6, Math.max( 2, a.niveau || 2 ) );
			var blockProps = useBlockProps( {
				className: 'salama-titre-flag' + ( a.inverse ? ' salama-titre-flag--inverse' : '' ),
			} );
			var changerNiveau = function ( n ) { set( { niveau: n } ); };
			var repli = champNiveau( niveau, changerNiveau );

			return el( Fragment, null,
				barreNiveau( niveau, changerNiveau ),
				el( BlockControls, { group: 'block' },
					el( ToolbarGroup, null,
						el( ToolbarButton, {
							icon: 'image-flip-horizontal',
							label: __( 'Inverser le sens du titre et du flag', 'salama-blocs' ),
							isPressed: !! a.inverse,
							onClick: function () { set( { inverse: ! a.inverse } ); },
						} )
					)
				),
				repli ? el( InspectorControls, null,
					el( PanelBody, { title: __( 'Titre', 'salama-blocs' ) }, repli )
				) : null,
				el( 'div', blockProps,
					el( 'div', { className: 'salama-titre-flag__flag' },
						el( RichText, {
							tagName: 'p',
							className: 'salama-titre-flag__texte',
							value: a.texte,
							allowedFormats: [ 'core/bold', 'core/italic' ],
							placeholder: __( 'Texte du flag…', 'salama-blocs' ),
							onChange: function ( texte ) { set( { texte: texte } ); },
						} )
					),
					el( RichText, {
						tagName: 'h' + niveau,
						className: 'salama-titre-flag__titre',
						value: a.titre,
						allowedFormats: [ 'core/bold', 'core/italic' ],
						placeholder: __( 'Votre titre…', 'salama-blocs' ),
						onChange: function ( titre ) { set( { titre: titre } ); },
					} )
				)
			);
		},
		save: function () { return null; },
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Bannière
	 * -------------------------------------------------------------- */
	registerBlockType( 'salama/banniere', {
		edit: function ( props ) {
			var a     = props.attributes;
			var set   = props.setAttributes;
			var media = useMedia( a.imageId );

			/*
			 * Le niveau est borné ici comme il l'est dans rendu.php : une
			 * bannière posée avant que la liste ne soit plafonnée peut porter
			 * un niveau que le site n'écrira plus.
			 */
			var niveau = Math.min( 2, Math.max( 1, a.niveau || 1 ) );

			var point = a.pointFocal || { x: 0.5, y: 0.5 };
			var classes = 'salama-banniere' + ( a.imageId ? ' salama-banniere--avec-image' : '' );
			if ( a.fondVert === false ) {
				classes += ' salama-banniere--sans-fond-vert';
			}
			if ( a.couleurFond === 'rouge' ) {
				classes += ' salama-banniere--fond-rouge';
			}
			var blockProps = useBlockProps( {
				className: classes,
				style: { '--salama-image-position': ( point.x * 100 ) + '% ' + ( point.y * 100 ) + '%' },
			} );

			var choisirImage = function ( m ) {
				set( { imageId: m.id, pointFocal: { x: 0.5, y: 0.5 } } );
			};

			var repliNiveau = champNiveau( niveau, function ( n ) {
				set( { niveau: n } );
			}, 1, 2 );

			return el(
				Fragment,
				null,

				barreNiveau( niveau, function ( n ) {
					set( { niveau: n } );
				}, 1, 2 ),
				barreImage( a.imageId, media, choisirImage ),

				el(
					InspectorControls,
					null,

					repliNiveau
						? el( PanelBody, { title: __( 'Titre', 'salama-blocs' ) }, repliNiveau )
						: null,

					el(
						PanelBody,
						{ title: __( 'Bouton', 'salama-blocs' ) },
						el(
							BaseControl,
							{
								label: __( 'Destination', 'salama-blocs' ),
								id: 'salama-banniere-lien-' + props.clientId,
								help: __(
									'Cherchez une page par son titre, ou collez une adresse. Une ancre s’ajoute à la fin : /ma-page/#ma-section',
									'salama-blocs'
								),
								__nextHasNoMarginBottom: true,
							},
							el( URLInput, {
								id: 'salama-banniere-lien-' + props.clientId,
								value: a.lien,
								onChange: function ( valeur ) {
									set( { lien: valeur } );
								},
								placeholder: __( 'Rechercher une page…', 'salama-blocs' ),
								__nextHasNoMarginBottom: true,
							} )
						),
						el( ToggleControl, {
							label: __( 'Ouvrir dans un nouvel onglet', 'salama-blocs' ),
							checked: !! a.nouvelOnglet,
							onChange: function ( v ) {
								set( { nouvelOnglet: v } );
							},
							__nextHasNoMarginBottom: true,
						} ),
						a.bouton && ! a.lien
							? el(
									Notice,
									{ status: 'warning', isDismissible: false },
									__(
										'Sans destination, le bouton s’affiche mais n’est pas cliquable.',
										'salama-blocs'
									)
							  )
							: null
					),

					a.imageId
						? el(
								PanelBody,
								{ title: __( 'Image', 'salama-blocs' ) },
								el( ToggleControl, {
									label: __( 'Afficher le fond', 'salama-blocs' ),
									help: __( 'L’ombre colorée suit la découpe de l’image.', 'salama-blocs' ),
									checked: a.fondVert !== false,
									onChange: function ( valeur ) { set( { fondVert: valeur } ); },
									__nextHasNoMarginBottom: true,
								} ),
								a.fondVert !== false
									? el( SelectControl, {
										label: __( 'Couleur du fond', 'salama-blocs' ),
										value: a.couleurFond || 'vert',
										options: [
											{ label: __( 'Vert du thème', 'salama-blocs' ), value: 'vert' },
											{ label: __( 'Rouge du thème', 'salama-blocs' ), value: 'rouge' },
										],
										onChange: function ( valeur ) { set( { couleurFond: valeur } ); },
										__nextHasNoMarginBottom: true,
									} )
									: null,
								media && media.source_url
									? el( FocalPointPicker, {
										label: __( 'Cadrage de l’image', 'salama-blocs' ),
										help: __( 'Déplacez le point vers la partie de la photo à garder visible dans le masque.', 'salama-blocs' ),
										url: media.source_url,
										value: point,
										onDrag: function ( valeur ) { set( { pointFocal: valeur } ); },
										onChange: function ( valeur ) { set( { pointFocal: valeur } ); },
									} )
									: null,
								el( Button, {
									variant: 'secondary',
									onClick: function () { set( { pointFocal: { x: 0.5, y: 0.5 } } ); },
								}, __( 'Recentrer l’image', 'salama-blocs' ) ),
								el(
									'p',
									{ className: 'salama-blocs__aide' },
									__(
										'L’image prend la forme du cercle au pinceau et déborde du cadre : elle ne change pas la hauteur de la bannière.',
										'salama-blocs'
									)
								),
								el(
									Button,
									{
										variant: 'secondary',
										isDestructive: true,
										onClick: function () {
											set( { imageId: 0 } );
										},
									},
									__( 'Retirer l’image', 'salama-blocs' )
								)
						  )
						: null
				),

				el(
					'section',
					blockProps,

					el(
						'div',
						{ className: 'salama-banniere__texte' },

						el( RichText, {
							tagName: 'h' + niveau,
							className: 'salama-banniere__titre',
							value: a.titre,
							onChange: function ( valeur ) {
								set( { titre: valeur } );
							},
							placeholder: __( 'Titre de la page', 'salama-blocs' ),
							allowedFormats: [ 'core/bold', 'core/italic' ],
						} ),

						el( RichText, {
							tagName: 'p',
							className: 'salama-banniere__chapo',
							value: a.chapo,
							onChange: function ( valeur ) {
								set( { chapo: valeur } );
							},
							placeholder: __( 'Une phrase d’accroche.', 'salama-blocs' ),
							allowedFormats: [ 'core/italic' ],
						} ),

						el( RichText, {
							tagName: 'span',
							className: 'salama-btn salama-btn--fill salama-banniere__bouton',
							value: a.bouton,
							onChange: function ( valeur ) {
								set( { bouton: valeur } );
							},
							placeholder: __( 'Libellé du bouton', 'salama-blocs' ),
							allowedFormats: [],
						} ),

						a.imageId ? null : choixImage( __( 'Image de la bannière (facultative)', 'salama-blocs' ), choisirImage )
					),

					a.imageId
						? el( 'div', { className: 'salama-banniere__media' }, apercu( media ) )
						: null
				)
			);
		},

		save: function () {
			return null;
		},
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Texte et image
	 * -------------------------------------------------------------- */

	registerBlockType( 'salama/texte-image', {
		edit: function ( props ) {
			var a     = props.attributes;
			var set   = props.setAttributes;
			var media = useMedia( a.imageId );

			var classes = [ 'salama-ti', 'salama-ti--' + a.sens ];

			if ( a.decorBloc ) {
				classes.push( 'salama-ti--bloc' );
			}

			if ( a.decorDisque ) {
				classes.push( 'salama-ti--disque' );
			}

			var blockProps = useBlockProps( { className: classes.join( ' ' ) } );

			var innerProps = useInnerBlocksProps(
				{ className: 'salama-ti__corps' },
				{
					template: [
						[
							'core/paragraph',
							{ placeholder: __( 'Racontez votre parcours…', 'salama-blocs' ) },
						],
					],
				}
			);

			var choisirImage = function ( m ) {
				set( { imageId: m.id } );
			};

			return el(
				Fragment,
				null,

				barreNiveau( a.niveau, function ( n ) {
					set( { niveau: n } );
				}, 2 ),

				/*
				 * Le sens de la mise en page se choisit d'un geste, à côté du
				 * bloc : les deux icônes montrent le résultat, là où un menu
				 * déroulant demandait de lire deux libellés.
				 */
				el(
					BlockControls,
					{ group: 'block' },
					el(
						ToolbarGroup,
						null,
						el( ToolbarButton, {
							icon: 'align-pull-left',
							label: __( "Image à gauche du texte", 'salama-blocs' ),
							isActive: 'image-gauche' === a.sens,
							onClick: function () {
								set( { sens: 'image-gauche' } );
							},
						} ),
						el( ToolbarButton, {
							icon: 'align-pull-right',
							label: __( "Image à droite du texte", 'salama-blocs' ),
							isActive: 'image-droite' === a.sens,
							onClick: function () {
								set( { sens: 'image-droite' } );
							},
						} )
					)
				),

				barreImage( a.imageId, media, choisirImage ),

				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __( 'Décor', 'salama-blocs' ) },
						el( ToggleControl, {
							label: __( "Bloc rosé derrière l'image", 'salama-blocs' ),
							checked: !! a.decorBloc,
							onChange: function ( v ) {
								set( { decorBloc: v } );
							},
							__nextHasNoMarginBottom: true,
						} ),
						el( ToggleControl, {
							label: __( 'Disque orange', 'salama-blocs' ),
							checked: !! a.decorDisque,
							onChange: function ( v ) {
								set( { decorDisque: v } );
							},
							__nextHasNoMarginBottom: true,
						} ),
						el( ToggleControl, {
							label: __( 'Coup de pinceau sous le texte', 'salama-blocs' ),
							checked: !! a.decorPinceau,
							onChange: function ( v ) {
								set( { decorPinceau: v } );
							},
							__nextHasNoMarginBottom: true,
						} ),
						champNiveau( a.niveau, function ( n ) {
							set( { niveau: n } );
						}, 2 )
					)
				),

				el(
					'section',
					blockProps,
					el(
						'div',
						{ className: 'salama-ti__grille' },
						el(
							'div',
							{ className: 'salama-ti__texte' },
							el( RichText, {
								tagName: 'h' + a.niveau,
								className: 'salama-ti__titre',
								value: a.titre,
								onChange: function ( valeur ) {
									set( { titre: valeur } );
								},
								placeholder: __( 'Titre de la section', 'salama-blocs' ),
								allowedFormats: [ 'core/bold', 'core/italic' ],
							} ),
							el( 'div', innerProps ),
							a.decorPinceau
								? el( 'span', {
										className: 'salama-ti__pinceau',
										'aria-hidden': 'true',
								  } )
								: null
						),
						el(
							'figure',
							{
								className:
									'salama-ti__figure' +
									( a.imageId ? '' : ' salama-blocs--vide' ),
							},
							a.imageId
								? apercu( media )
								: choixImage(
										__( 'Image de la section', 'salama-blocs' ),
										choisirImage
								  )
						)
					)
				)
			);
		},

		save: function () {
			return el( InnerBlocks.Content );
		},
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Spécialités
	 * -------------------------------------------------------------- */

	registerBlockType( 'salama/specialites', {
		edit: function ( props ) {
			var a   = props.attributes;
			var set = props.setAttributes;

			var blockProps = useBlockProps( { className: 'salama-spe' } );

			var innerProps = useInnerBlocksProps(
				{ className: 'salama-spe__grille' },
				{
					allowedBlocks: [ 'salama/carte' ],
					orientation: 'horizontal',
					template: [
						[ 'salama/carte', { libelle: __( "L'accompagnement des femmes", 'salama-blocs' ) } ],
						[ 'salama/carte', { libelle: __( "L'accompagnement des entreprises", 'salama-blocs' ) } ],
					],
				}
			);

			var repliNiveau = champNiveau( a.niveau, function ( n ) {
				set( { niveau: n } );
			}, 2 );

			return el(
				Fragment,
				null,

				barreNiveau( a.niveau, function ( n ) {
					set( { niveau: n } );
				}, 2 ),

				repliNiveau
					? el(
							InspectorControls,
							null,
							el( PanelBody, { title: __( 'Titre', 'salama-blocs' ) }, repliNiveau )
					  )
					: null,

				el(
					'section',
					blockProps,
					el( RichText, {
						tagName: 'h' + a.niveau,
						className: 'salama-spe__titre',
						value: a.titre,
						onChange: function ( valeur ) {
							set( { titre: valeur } );
						},
						placeholder: __( 'Titre de la section', 'salama-blocs' ),
						allowedFormats: [ 'core/bold', 'core/italic' ],
					} ),
					el( 'div', innerProps )
				)
			);
		},

		save: function () {
			return el( InnerBlocks.Content );
		},
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Carte de spécialité
	 * -------------------------------------------------------------- */

	/**
	 * Bouton « Lien » de la barre d'outils, avec la recherche de page native.
	 *
	 * C'est la commande que la rédaction utilise déjà sur un texte ou un
	 * bouton : même icône, même popover, même recherche par titre de page.
	 *
	 * @param {Object} props Attributs et rappels du bloc.
	 * @return {Object|null} Élément React.
	 */
	function barreLien( props ) {
		var a   = props.attributes;
		var set = props.setAttributes;

		var ouvert = useState( false );

		if ( ! LinkControl ) {
			return null;
		}

		return el(
			BlockControls,
			{ group: 'block' },
			el(
				ToolbarGroup,
				null,
				el( ToolbarButton, {
					icon: 'admin-links',
					label: a.url
						? __( 'Modifier le lien', 'salama-blocs' )
						: __( 'Ajouter un lien', 'salama-blocs' ),
					isActive: !! a.url,
					onClick: function () {
						ouvert[ 1 ]( ! ouvert[ 0 ] );
					},
				} )
			),
			ouvert[ 0 ]
				? el(
						Popover,
						{
							placement: 'bottom-start',
							onClose: function () {
								ouvert[ 1 ]( false );
							},
						},
						el( LinkControl, {
							value: { url: a.url, opensInNewTab: !! a.nouvelOnglet },
							settings: [
								{
									id: 'opensInNewTab',
									title: __( 'Ouvrir dans un nouvel onglet', 'salama-blocs' ),
								},
							],
							onChange: function ( valeur ) {
								set( {
									url: valeur.url || '',
									nouvelOnglet: !! valeur.opensInNewTab,
								} );
							},
							onRemove: function () {
								set( { url: '', nouvelOnglet: false } );
								ouvert[ 1 ]( false );
							},
						} )
				  )
				: null
		);
	}

	registerBlockType( 'salama/carte', {
		edit: function ( props ) {
			var a     = props.attributes;
			var set   = props.setAttributes;
			var media = useMedia( a.imageId );

			var blockProps = useBlockProps( { className: 'salama-spe__item' } );

			var choisirImage = function ( m ) {
				set( { imageId: m.id } );
			};

			return el(
				Fragment,
				null,

				barreLien( props ),
				barreImage( a.imageId, media, choisirImage ),

				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __( 'Destination', 'salama-blocs' ) },

						/*
						 * Le champ de la colonne de droite ne sert que si la
						 * barre d'outils n'a pas pu accueillir le lien.
						 */
						LinkControl
							? null
							: el(
									BaseControl,
									{
										label: __( 'Lien', 'salama-blocs' ),
										id: 'salama-carte-url-' + props.clientId,
										help: __(
											'Cherchez une page par son titre, ou collez une adresse. Une ancre s’ajoute à la fin : /ma-page/#ma-section',
											'salama-blocs'
										),
										__nextHasNoMarginBottom: true,
									},
									el( URLInput, {
										id: 'salama-carte-url-' + props.clientId,
										value: a.url,
										onChange: function ( valeur ) {
											set( { url: valeur } );
										},
										placeholder: __( 'Rechercher une page…', 'salama-blocs' ),
										__nextHasNoMarginBottom: true,
									} )
							  ),

						LinkControl
							? null
							: el( ToggleControl, {
									label: __( 'Ouvrir dans un nouvel onglet', 'salama-blocs' ),
									checked: !! a.nouvelOnglet,
									onChange: function ( v ) {
										set( { nouvelOnglet: v } );
									},
									__nextHasNoMarginBottom: true,
							  } ),

						a.url
							? el(
									'p',
									{ className: 'salama-blocs__aide' },
									__( 'Destination :', 'salama-blocs' ) + ' ' + a.url
							  )
							: el(
									Notice,
									{ status: 'warning', isDismissible: false },
									__(
										'Sans destination, la carte s’affiche mais n’est pas cliquable. Le bouton « Lien » de la barre d’outils, au-dessus du bloc, cherche une page par son titre.',
										'salama-blocs'
									)
							  )
					)
				),

				el(
					'div',
					blockProps,
					el(
						'div',
						{ className: 'salama-carte' },
						el( RichText, {
							tagName: 'span',
							className: 'salama-carte__libelle',
							value: a.libelle,
							onChange: function ( valeur ) {
								set( { libelle: valeur } );
							},
							placeholder: __( 'Libellé de la pastille', 'salama-blocs' ),
							allowedFormats: [],
						} ),
						el(
							'span',
							{
								className:
									'salama-carte__media' +
									( a.imageId ? '' : ' salama-blocs--vide' ),
							},
							a.imageId
								? apercu( media )
								: choixImage(
										__( 'Image de la carte', 'salama-blocs' ),
										choisirImage
								  )
						)
					)
				)
			);
		},

		save: function () {
			return null;
		},
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Cartes
	 *
	 * Le seul réglage du parent est le nombre de colonnes, et il est dans la
	 * barre d'outils : il change ce qu'on voit, on doit pouvoir l'essayer sans
	 * quitter le bloc des yeux.
	 * -------------------------------------------------------------- */

	registerBlockType( 'salama/cartes', {
		edit: function ( props ) {
			var a   = props.attributes;
			var set = props.setAttributes;

			var colonnes = Math.min( 4, Math.max( 1, a.colonnes || 3 ) );

			var blockProps = useBlockProps( {
				className: 'salama-cartes salama-cartes--' + colonnes,
			} );

			var innerProps = useInnerBlocksProps(
				{ className: 'salama-cartes__grille' },
				{
					allowedBlocks: [ 'salama/carte-libre' ],
					orientation: 'horizontal',
					template: [ [ 'salama/carte-libre' ], [ 'salama/carte-libre' ], [ 'salama/carte-libre' ] ],
				}
			);

			var repliNiveau = champNiveau( a.niveau, function ( n ) {
				set( { niveau: n } );
			}, 2 );

			return el(
				Fragment,
				null,

				barreNiveau( a.niveau, function ( n ) {
					set( { niveau: n } );
				}, 2 ),

				el(
					BlockControls,
					{ group: 'other' },
					el(
						ToolbarGroup,
						null,
						[ 1, 2, 3, 4 ].map( function ( n ) {
							return el( ToolbarButton, {
								key: n,
								/* translators: %d : nombre de colonnes. */
								label: sprintf( __( '%d colonnes', 'salama-blocs' ), n ),
								isActive: colonnes === n,
								onClick: function () {
									set( { colonnes: n } );
								},
							}, String( n ) );
						} )
					)
				),

				repliNiveau
					? el(
							InspectorControls,
							null,
							el( PanelBody, { title: __( 'Titre', 'salama-blocs' ) }, repliNiveau )
					  )
					: null,

				el(
					'section',
					blockProps,
					el( RichText, {
						tagName: 'h' + a.niveau,
						className: 'salama-cartes__titre',
						value: a.titre,
						onChange: function ( valeur ) {
							set( { titre: valeur } );
						},
						placeholder: __( 'Titre de la section (facultatif)', 'salama-blocs' ),
						allowedFormats: [ 'core/bold', 'core/italic' ],
					} ),
					el( 'ul', innerProps )
				)
			);
		},

		save: function () {
			return el( InnerBlocks.Content );
		},
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Carte
	 *
	 * Le libellé s'écrit sur le bloc d'accent, à sa place définitive : c'est
	 * la différence visible avec salama/carte, dont le libellé vit dans une
	 * pastille.
	 * -------------------------------------------------------------- */

	registerBlockType( 'salama/carte-libre', {
		edit: function ( props ) {
			var a     = props.attributes;
			var set   = props.setAttributes;
			var media = useMedia( a.imageId );

			var blockProps = useBlockProps( { className: 'salama-cartes__item' } );

			var choisirImage = function ( m ) {
				set( { imageId: m.id } );
			};

			return el(
				Fragment,
				null,

				barreLien( props ),
				barreImage( a.imageId, media, choisirImage ),

				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __( 'Destination', 'salama-blocs' ) },
						LinkControl
							? null
							: el(
									BaseControl,
									{
										label: __( 'Lien', 'salama-blocs' ),
										id: 'salama-cl-url-' + props.clientId,
										help: __(
											'Cherchez une page par son titre, ou collez une adresse.',
											'salama-blocs'
										),
										__nextHasNoMarginBottom: true,
									},
									el( URLInput, {
										id: 'salama-cl-url-' + props.clientId,
										value: a.url,
										onChange: function ( valeur ) {
											set( { url: valeur } );
										},
										placeholder: __( 'Rechercher une page…', 'salama-blocs' ),
										__nextHasNoMarginBottom: true,
									} )
							  ),

						LinkControl
							? null
							: el( ToggleControl, {
									label: __( 'Ouvrir dans un nouvel onglet', 'salama-blocs' ),
									checked: !! a.nouvelOnglet,
									onChange: function ( v ) {
										set( { nouvelOnglet: v } );
									},
									__nextHasNoMarginBottom: true,
							  } ),

						a.url
							? el(
									'p',
									{ className: 'salama-blocs__aide' },
									__( 'Destination :', 'salama-blocs' ) + ' ' + a.url
							  )
							: el(
									Notice,
									{ status: 'warning', isDismissible: false },
									__(
										'Sans destination, la carte s’affiche mais n’est pas cliquable. Le bouton « Lien » de la barre d’outils, au-dessus du bloc, cherche une page par son titre.',
										'salama-blocs'
									)
							  )
					)
				),

				el(
					'li',
					blockProps,
					el(
						'div',
						{ className: 'salama-cl' },
						el( RichText, {
							tagName: 'span',
							className: 'salama-cl__libelle',
							value: a.libelle,
							onChange: function ( valeur ) {
								set( { libelle: valeur } );
							},
							placeholder: __( 'Libellé', 'salama-blocs' ),
							allowedFormats: [ 'core/italic' ],
						} ),
						el(
							'span',
							{ className: 'salama-cl__media' },
							a.imageId
								? apercu( media )
								: choixImage( __( 'Image de la carte', 'salama-blocs' ), choisirImage )
						)
					)
				)
			);
		},

		save: function () {
			return null;
		},
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Carrousel, horizontal et vertical
	 *
	 * Les cartes ne sont pas redessinées ici : elles sont demandées au serveur,
	 * qui les rend avec le code du site public. L'aperçu montre donc les vraies
	 * publications, leurs vraies images et leurs vraies dates — et ne peut pas
	 * diverger du rendu final. Le titre et le libellé du bouton, eux, restent
	 * saisissables sur place.
	 *
	 * Elles arrivent en revanche sans lien : dans l'éditeur, cliquer une carte
	 * quitterait la page en cours d'écriture. C'est la route REST qui le
	 * décide (inc/editeur.php), donc les deux blocs en héritent sans le savoir.
	 *
	 * Ces deux blocs sont distincts — chacun son block.json, son rendu PHP et
	 * son entrée d'inséreur — mais leur aperçu est le même à une classe près :
	 * il s'écrit une fois, dans `editCarrousel()`, plutôt que deux fois à
	 * corriger en parallèle.
	 * -------------------------------------------------------------- */

	/**
	 * Demande au serveur les cartes d'un carrousel.
	 *
	 * @param {string} type   Type de contenu.
	 * @param {number} nombre Nombre de publications.
	 * @return {Object} État : { chargement, cartes, libelle, erreur }.
	 */
	function usePiste( type, nombre ) {
		var etat = useState( { chargement: true, cartes: '', libelle: '', erreur: '' } );

		useEffect(
			function () {
				var annule = false;

				etat[ 1 ]( function ( precedent ) {
					return {
						chargement: true,
						cartes: precedent.cartes,
						libelle: precedent.libelle,
						erreur: '',
					};
				} );

				// Le curseur du nombre de publications déclenche un changement
				// par cran : on laisse la main se poser avant d'interroger.
				var minuteur = window.setTimeout( function () {
					apiFetch( {
						path: addQueryArgs( '/salama/v1/carrousel', {
							type: type,
							nombre: nombre,
						} ),
					} )
						.then( function ( reponse ) {
							if ( ! annule ) {
								etat[ 1 ]( {
									chargement: false,
									cartes: reponse.cartes || '',
									libelle: reponse.libelle || '',
									erreur: '',
								} );
							}
						} )
						.catch( function ( erreur ) {
							if ( ! annule ) {
								etat[ 1 ]( {
									chargement: false,
									cartes: '',
									libelle: '',
									erreur:
										( erreur && erreur.message ) ||
										__( 'Aperçu indisponible.', 'salama-blocs' ),
								} );
							}
						} );
				}, 300 );

				return function () {
					annule = true;
					window.clearTimeout( minuteur );
				};
			},
			[ type, nombre ]
		);

		return etat[ 0 ];
	}

	/**
	 * Options du menu « Type de publication ».
	 *
	 * La liste vient de PHP (inc/editeur.php) : un type de contenu ajouté plus
	 * tard y apparaît sans qu'on touche à ce fichier.
	 *
	 * @return {Array} Options du SelectControl.
	 */
	function typesPublication() {
		var donnees = window.salamaBlocs && window.salamaBlocs.typesPublication;

		if ( donnees && donnees.length ) {
			return donnees;
		}

		return [ { value: 'post', label: __( 'Articles', 'salama-blocs' ) } ];
	}

	/**
	 * Retourne les classes d'un carrousel.
	 *
	 * Pendant exact de salama_carousel_classes() côté PHP : l'aperçu doit
	 * porter les mêmes classes que le site, sinon il cesse de lui ressembler.
	 *
	 * @param {string}  sens Sens de défilement : « vertical », horizontal sinon.
	 * @param {boolean} fond Cadre autour du carrousel.
	 * @return {string} Liste de classes, séparées par une espace.
	 */
	function classesCarrousel( sens, fond ) {
		var classes = [ 'carousel' ];

		if ( 'vertical' === sens ) {
			classes.push( 'carousel--vertical' );
		}

		if ( fond ) {
			classes.push( 'carousel--reverse' );
		}

		return classes.join( ' ' );
	}

	/**
	 * Fabrique l'`edit` d'un carrousel.
	 *
	 * @param {string} sens Sens de défilement : « vertical », horizontal sinon.
	 * @return {Function} Composant `edit` du bloc.
	 */
	function editCarrousel( sens ) {
		return function ( props ) {
			var a   = props.attributes;
			var set = props.setAttributes;

			var piste = usePiste( a.type, a.nombre );

			var blockProps = useBlockProps( {
				className: classesCarrousel( sens, a.fond ),
			} );

			/*
			 * Les flèches n'apparaissent sur le site que lorsqu'il y a de quoi
			 * défiler : au-delà de trois cartes à l'horizontale, où la piste en
			 * montre trois, et au-delà de deux à la verticale, où la colonne en
			 * montre une et demie. L'aperçu fait de même.
			 */
			var nbCartes = ( piste.cartes.match( /class="carousel__item"/g ) || [] ).length;
			var seuil    = 'vertical' === sens ? 2 : 3;

			return el(
				Fragment,
				null,

				barreNiveau( a.niveau, function ( n ) {
					set( { niveau: n } );
				}, 1 ),

				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __( 'Publications', 'salama-blocs' ) },
						el( SelectControl, {
							label: __( 'Type de publication', 'salama-blocs' ),
							help: __(
								'Le bouton mène automatiquement à la page qui les liste toutes.',
								'salama-blocs'
							),
							value: a.type,
							options: typesPublication(),
							onChange: function ( valeur ) {
								set( { type: valeur } );
							},
							__nextHasNoMarginBottom: true,
						} ),
						el( RangeControl, {
							label: __( 'Nombre affiché', 'salama-blocs' ),
							help: __(
								'Les plus récentes d’abord. Au-delà, mieux vaut renvoyer vers la page qui les liste toutes.',
								'salama-blocs'
							),
							value: a.nombre,
							min: 2,
							max: 12,
							onChange: function ( valeur ) {
								set( { nombre: valeur || 5 } );
							},
							__nextHasNoMarginBottom: true,
						} )
					),
					el(
						PanelBody,
						{ title: __( 'Mise en page', 'salama-blocs' ) },
						el( ToggleControl, {
							label: __( 'Encadré', 'salama-blocs' ),
							help: __(
								'Un filet autour du carrousel et des cartes retournées, texte en haut : de quoi distinguer deux carrousels sur une même page.',
								'salama-blocs'
							),
							checked: !! a.fond,
							onChange: function ( v ) {
								set( { fond: v } );
							},
							__nextHasNoMarginBottom: true,
						} ),
						champNiveau( a.niveau, function ( n ) {
							set( { niveau: n } );
						}, 1 ),
						el(
							'p',
							{ className: 'salama-blocs__aide' },
							__(
								'Le titre, le chapô et le libellé du bouton s’écrivent directement dans le bloc. Laissés vides, ils ne s’affichent pas sur le site.',
								'salama-blocs'
							)
						)
					)
				),

				el(
					'section',
					blockProps,

					el(
						'div',
						{ className: 'carousel__head' },
						el( RichText, {
							tagName: 'h' + a.niveau,
							className: 'carousel__title',
							value: a.titre,
							onChange: function ( valeur ) {
								set( { titre: valeur } );
							},
							placeholder: __( 'Titre du carrousel', 'salama-blocs' ),
							allowedFormats: [ 'core/bold', 'core/italic' ],
						} ),

						nbCartes > seuil
							? el(
									'div',
									{ className: 'carousel__controls', 'aria-hidden': 'true' },
									el( 'span', {
										className:
											'carousel__control carousel__control--prev',
									} ),
									el( 'span', {
										className:
											'carousel__control carousel__control--next',
									} )
							  )
							: null
					),

					el(
						'div',
						{
							className:
								'carousel__intro' +
								( a.intro ? '' : ' salama-carrousel__intro--vide' ),
						},
						el( RichText, {
							tagName: 'p',
							value: a.intro,
							onChange: function ( valeur ) {
								set( { intro: valeur } );
							},
							placeholder: __(
								'Chapô : deux ou trois lignes pour annoncer la section (facultatif)',
								'salama-blocs'
							),
							allowedFormats: [ 'core/bold', 'core/italic', 'core/link' ],
						} )
					),

					piste.erreur
						? el(
								Notice,
								{ status: 'error', isDismissible: false },
								piste.erreur
						  )
						: null,

					nbCartes
						? el( 'ul', {
								className: 'carousel__track',
								dangerouslySetInnerHTML: { __html: piste.cartes },
						  } )
						: el(
								'div',
								{ className: 'salama-carrousel__vide' },
								piste.chargement
									? el( Spinner )
									: el(
											'span',
											null,
											piste.libelle
												? sprintf(
														/* translators: %s: nom du type de contenu au pluriel. */
														__(
															'Aucune publication dans « %s » pour l’instant. Le carrousel restera invisible pour les visiteurs.',
															'salama-blocs'
														),
														piste.libelle
												  )
												: __( 'Chargement de l’aperçu…', 'salama-blocs' )
									  )
						  ),

					el(
						'div',
						{
							className:
								'carousel__footer' +
								( a.bouton ? '' : ' salama-carrousel__footer--vide' ),
						},
						el( RichText, {
							tagName: 'span',
							className: 'salama-btn salama-btn--outline',
							value: a.bouton,
							onChange: function ( valeur ) {
								set( { bouton: valeur } );
							},
							placeholder: __( 'Libellé du bouton', 'salama-blocs' ),
							allowedFormats: [],
						} )
					)
				)
			);
		};
	}

	registerBlockType( 'salama/carrousel', {
		edit: editCarrousel( '' ),

		save: function () {
			return null;
		},
	} );

	registerBlockType( 'salama/carrousel-vertical', {
		edit: editCarrousel( 'vertical' ),

		save: function () {
			return null;
		},
	} );

	/* -------------------------------------------------------------- *
	 * Salama — Calendrier de réservation
	 *
	 * Le panneau — le mois et la liste des éléments de réservation — vient du
	 * serveur, comme la piste du carrousel : il dépend du mois en cours et de
	 * ce qui a été saisi dans le menu « Réservations », deux choses que
	 * l'éditeur ne peut pas deviner. Seuls le titre et le chapô s'écrivent ici.
	 * -------------------------------------------------------------- */

	/**
	 * Demande au serveur le panneau du calendrier.
	 *
	 * @return {Object} État : { chargement, panneau, erreur }.
	 */
	function usePanneauCalendrier() {
		var etat = useState( { chargement: true, panneau: '', erreur: '' } );

		useEffect( function () {
			var annule = false;

			apiFetch( { path: '/salama/v1/calendrier' } )
				.then( function ( reponse ) {
					if ( ! annule ) {
						etat[ 1 ]( {
							chargement: false,
							panneau: reponse.panneau || '',
							erreur: '',
						} );
					}
				} )
				.catch( function ( erreur ) {
					if ( ! annule ) {
						etat[ 1 ]( {
							chargement: false,
							panneau: '',
							erreur:
								( erreur && erreur.message ) ||
								__( 'Aperçu indisponible.', 'salama-blocs' ),
						} );
					}
				} );

			return function () {
				annule = true;
			};
		}, [] );

		return etat[ 0 ];
	}

	registerBlockType( 'salama/calendrier', {
		edit: function ( props ) {
			var a      = props.attributes;
			var set    = props.setAttributes;
			var niveau = Math.min( 6, Math.max( 2, a.niveau || 2 ) );
			var etat   = usePanneauCalendrier();

			var blockProps = useBlockProps( { className: 'salama-calendrier' } );

			var changerNiveau = function ( n ) { set( { niveau: n } ); };
			var repli = champNiveau( niveau, changerNiveau );

			var panneau;

			if ( etat.chargement ) {
				panneau = el( 'div', { className: 'salama-calendrier__attente' },
					el( Spinner, null ),
					el( 'span', null, __( 'Chargement du calendrier…', 'salama-blocs' ) )
				);
			} else if ( etat.erreur ) {
				panneau = el( Notice, { status: 'warning', isDismissible: false }, etat.erreur );
			} else {
				/*
				 * Le balisage vient de notre propre route REST, réservée aux
				 * comptes qui peuvent déjà écrire dans le site : il est produit
				 * par le même PHP que le rendu public, et déjà échappé.
				 */
				panneau = el( 'div', {
					className: 'salama-calendrier__apercu',
					dangerouslySetInnerHTML: { __html: etat.panneau },
				} );
			}

			return el( Fragment, null,
				barreNiveau( niveau, changerNiveau ),
				repli ? el( InspectorControls, null,
					el( PanelBody, { title: __( 'Titre', 'salama-blocs' ) }, repli )
				) : null,
				el( 'div', blockProps,
					el( RichText, {
						tagName: 'h' + niveau,
						className: 'salama-calendrier__titre',
						value: a.titre,
						allowedFormats: [ 'core/bold', 'core/italic' ],
						placeholder: __( 'Titre du calendrier…', 'salama-blocs' ),
						onChange: function ( titre ) { set( { titre: titre } ); },
					} ),
					el( RichText, {
						tagName: 'p',
						className:
							'salama-calendrier__intro' +
							( a.chapo ? '' : ' salama-calendrier__intro--vide' ),
						value: a.chapo,
						allowedFormats: [ 'core/bold', 'core/italic', 'core/link' ],
						placeholder: __( 'Chapô (facultatif)…', 'salama-blocs' ),
						onChange: function ( chapo ) { set( { chapo: chapo } ); },
					} ),
					panneau
				)
			);
		},

		save: function () {
			return null;
		},
	} );
} )( window.wp );
