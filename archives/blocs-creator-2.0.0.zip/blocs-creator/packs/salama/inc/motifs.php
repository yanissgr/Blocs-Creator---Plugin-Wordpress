<?php
/**
 * Motifs de blocs.
 *
 * Le hero n'est pas un bloc sur mesure mais un motif de blocs natifs : il ne
 * figure pas sur la maquette, son dessin n'est donc pas arrêté. Un motif se
 * retouche dans l'éditeur, un bloc se recode.
 *
 * @package BlocsCreator\Packs\Salama
 */

defined( 'ABSPATH' ) || exit;

/**
 * Retourne le balisage de la bannière d'accueil.
 *
 * Un bloc Bannière du thème : cadre, titre, accroche, bouton. L'image est
 * facultative et la rédaction la pose d'un clic le jour venu — elle prendra la
 * forme du cercle au pinceau sans changer la hauteur du bloc.
 *
 * La bannière porte le h1 de la page. Le gabarit de la page d'accueil n'en
 * affiche aucun de son côté — sans elle, l'accueil n'aurait pas de titre.
 *
 * @return string
 */
function salama_blocs_motif_hero() {
	return '<!-- wp:salama/banniere {"titre":"Retrouver son souffle, retrouver son axe","chapo":"Yoga et sophrologie, en accompagnement individuel comme en entreprise. Un temps pour soi, ajusté à ce que vous traversez.","bouton":"Prendre rendez-vous","lien":"/prendre-rendez-vous/","niveau":1} /-->';
}

/**
 * Retourne le balisage de la section « Qui suis-je ? ».
 *
 * @param int $image_id Identifiant du média, 0 pour la surface d'attente.
 * @return string
 */
function salama_blocs_motif_qui_suis_je( $image_id = 0 ) {
	return sprintf(
		'<!-- wp:salama/texte-image {"titre":"Qui suis-je ?","imageId":%d} -->
<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur mattis, magna in pellentesque aliquam, dolor elit sollicitudin orci, at pulvinar augue lacus lacinia enim. Donec rhoncus felis nec dolor tempor, at sodales nisi commodo. In vel massa ac elit blandit finibus.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Proin placerat risus a quam vulputate, a aliquam nulla faucibus. Aliquam dictum porta ante eu efficitur. Pellentesque felis enim, tempor ac lorem vitae, gravida imperdiet nunc. Vestibulum eu lorem convallis, semper odio vel, iaculis dolor.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Quisque maximus sem ac ipsum gravida, eu mollis lorem accumsan. Pellentesque facilisis justo in diam finibus feugiat. Nam id commodo augue, quis faucibus eros.</p>
<!-- /wp:paragraph -->
<!-- /wp:salama/texte-image -->',
		(int) $image_id
	);
}

/**
 * Retourne le balisage de la section « Je suis spécialisée dans… ».
 *
 * @param int $femmes_id      Média de la première carte.
 * @param int $entreprises_id Média de la seconde carte.
 * @return string
 */
function salama_blocs_motif_specialites( $femmes_id = 0, $entreprises_id = 0 ) {
	return sprintf(
		'<!-- wp:salama/specialites {"titre":"Je suis spécialisée dans…"} -->
<!-- wp:salama/carte {"imageId":%1$d,"libelle":"L\'accompagnement des femmes","url":"/accompagnement/sophrologies/#accompagnement-des-femmes"} /-->

<!-- wp:salama/carte {"imageId":%2$d,"libelle":"L\'accompagnement des entreprises","url":"/entreprises/"} /-->
<!-- /wp:salama/specialites -->',
		(int) $femmes_id,
		(int) $entreprises_id
	);
}

/**
 * Enregistre la catégorie de motifs et les motifs eux-mêmes.
 *
 * Les motifs partent sans image : ils servent à reconstruire une section, pas
 * à recopier celle de l'accueil. La rédaction choisit ses visuels.
 */
function salama_blocs_enregistrer_motifs() {
	register_block_pattern_category(
		'salama',
		array( 'label' => __( 'Salama', 'salama-blocs' ) )
	);

	register_block_pattern(
		'salama/hero',
		array(
			'title'       => __( 'Salama — Bannière d\'accueil', 'salama-blocs' ),
			'description' => __( 'Un cadre portant le titre de la page, une accroche et un bouton de rendez-vous.', 'salama-blocs' ),
			'categories'  => array( 'salama' ),
			'keywords'    => array( 'hero', 'bannière', 'accueil' ),
			'content'     => salama_blocs_motif_hero(),
		)
	);

	register_block_pattern(
		'salama/accueil',
		array(
			'title'       => __( 'Salama — Page d\'accueil', 'salama-blocs' ),
			'description' => __( 'La page d\'accueil complète : bannière, « Qui suis-je ? » et les cartes de spécialité.', 'salama-blocs' ),
			'categories'  => array( 'salama' ),
			'keywords'    => array( 'accueil', 'page' ),
			'content'     => salama_blocs_motif_hero()
				. "\n\n" . salama_blocs_motif_qui_suis_je()
				. "\n\n" . '<!-- wp:separator {"className":"is-style-wide"} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide"/>
<!-- /wp:separator -->'
				. "\n\n" . salama_blocs_motif_specialites(),
		)
	);
}
add_action( 'init', 'salama_blocs_enregistrer_motifs' );
