<?php
/**
 * La réservation : le type de contenu « Réservations » et le panneau du calendrier.
 *
 * Les éléments de réservation sont, pour l'instant, de simples noms — « Séance
 * découverte », « Sophrologie », « Massage ». Ils se saisissent dans le menu
 * « Réservations » du back-office et s'affichent dans la colonne du bloc
 * calendrier.
 *
 * Le calendrier est une MAQUETTE : il dessine le mois en cours et ses créneaux,
 * mais rien ne s'y clique et aucune réservation n'est enregistrée. C'est aussi
 * le cas du bloc Contact — un dessin d'abord, la mécanique ensuite.
 *
 * Le panneau est rendu ici, et non dans blocs/calendrier/rendu.php, parce que
 * l'aperçu de l'éditeur en demande le rendu au serveur (route
 * salama/v1/calendrier) : le site et l'éditeur appellent la même fonction, ils
 * ne peuvent donc pas diverger.
 *
 * @package BlocsCreator\Packs\Salama
 */

defined( 'ABSPATH' ) || exit;

/**
 * Déclare le type de contenu « Réservations ».
 *
 * Il ne prend que le titre : un élément de réservation n'est qu'un nom. Sans
 * `show_in_rest`, WordPress sert l'éditeur classique — pour un seul champ,
 * c'est l'écran le plus court : un titre, un bouton Publier, rien d'autre.
 *
 * Le type n'est pas public : ces éléments n'ont ni page à eux, ni archive, ni
 * place dans les résultats de recherche. Ils n'existent que dans le calendrier.
 */
function salama_blocs_type_reservation() {
	register_post_type(
		'salama_resa',
		array(
			'labels'          => array(
				'name'               => __( 'Réservations', 'salama-blocs' ),
				'singular_name'      => __( 'Élément de réservation', 'salama-blocs' ),
				'menu_name'          => __( 'Réservations', 'salama-blocs' ),
				'add_new'            => __( 'Ajouter', 'salama-blocs' ),
				'add_new_item'       => __( 'Ajouter un élément de réservation', 'salama-blocs' ),
				'edit_item'          => __( 'Modifier l\'élément', 'salama-blocs' ),
				'new_item'           => __( 'Nouvel élément', 'salama-blocs' ),
				'view_item'          => __( 'Voir l\'élément', 'salama-blocs' ),
				'search_items'       => __( 'Rechercher un élément', 'salama-blocs' ),
				'not_found'          => __( 'Aucun élément de réservation pour le moment.', 'salama-blocs' ),
				'not_found_in_trash' => __( 'Aucun élément dans la corbeille.', 'salama-blocs' ),
				'all_items'          => __( 'Tous les éléments', 'salama-blocs' ),
			),
			'description'     => __( 'Les prestations proposées à la réservation. Pour l\'instant, un nom suffit.', 'salama-blocs' ),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'show_in_rest'    => false,
			'menu_position'   => 26,
			'menu_icon'       => 'dashicons-calendar-alt',
			'supports'        => array( 'title', 'page-attributes' ),
			'has_archive'     => false,
			'rewrite'         => false,
			'query_var'       => false,
			'capability_type' => 'post',
		)
	);
}
add_action( 'init', 'salama_blocs_type_reservation' );

/**
 * Remplace « Saisissez le titre » par ce qu'on attend vraiment ici.
 *
 * @param string  $texte Texte d'invite.
 * @param WP_Post $post  Publication en cours d'édition.
 * @return string
 */
function salama_blocs_invite_reservation( $texte, $post ) {
	if ( $post instanceof WP_Post && 'salama_resa' === $post->post_type ) {
		return __( 'Nom de l\'élément — par exemple « Séance découverte »', 'salama-blocs' );
	}

	return $texte;
}
add_filter( 'enter_title_here', 'salama_blocs_invite_reservation', 10, 2 );

/**
 * Retourne les noms des éléments de réservation publiés.
 *
 * L'ordre est celui du champ « Ordre » des attributs, puis celui de création :
 * la rédaction range sa liste sans avoir à republier.
 *
 * @param int $nombre Nombre maximal d'éléments.
 * @return array<int, string>
 */
function salama_blocs_reservations( $nombre = 12 ) {
	$posts = get_posts(
		array(
			'post_type'        => 'salama_resa',
			'post_status'      => 'publish',
			'numberposts'      => (int) $nombre,
			'orderby'          => array(
				'menu_order' => 'ASC',
				'date'       => 'ASC',
			),
			'suppress_filters' => false,
		)
	);

	return array_values(
		array_filter(
			array_map(
				static function ( $post ) {
					return trim( get_the_title( $post ) );
				},
				$posts
			),
			static function ( $titre ) {
				return '' !== $titre;
			}
		)
	);
}

/**
 * Décrit le mois en cours : ses cases, et le jour mis en avant.
 *
 * Les disponibilités sont une DÉCORATION, pas une donnée : tant que rien n'est
 * réservable pour de bon, le calendrier montre à quoi ressemblera un mois
 * ouvert — les mardis, jeudis et samedis à venir. La règle est écrite une fois
 * ici, et le même calcul sert au site et à l'aperçu.
 *
 * Un jour sans état particulier n'en porte aucun : `etat` reste vide, et la
 * case ne reçoit pas de classe de plus.
 *
 * @return array{mois:string, cases:array<int, array{jour:int, etat:string}>, vides:int, choisi:string}
 */
function salama_blocs_calendrier_mois() {
	$fuseau     = wp_timezone();
	$maintenant = new DateTimeImmutable( 'now', $fuseau );
	$premier    = $maintenant->modify( 'first day of this month' )->setTime( 0, 0 );
	$aujourdhui = (int) $maintenant->format( 'j' );
	$total      = (int) $premier->format( 't' );

	// Jours de la semaine ouverts, au sens de date('N') : 2 mardi, 4 jeudi, 6 samedi.
	$ouverts = array( 2, 4, 6 );

	$debut_semaine = (int) get_option( 'start_of_week', 1 );
	$colonne       = ( (int) $premier->format( 'w' ) - $debut_semaine + 7 ) % 7;

	$cases  = array();
	$choisi = null;

	for ( $jour = 1; $jour <= $total; $jour++ ) {
		$date = $premier->setDate( (int) $premier->format( 'Y' ), (int) $premier->format( 'n' ), $jour );
		$etat = '';

		if ( $jour < $aujourdhui ) {
			$etat = 'passe';
		} elseif ( in_array( (int) $date->format( 'N' ), $ouverts, true ) ) {
			$etat = 'dispo';

			if ( null === $choisi ) {
				$etat   = 'choisi';
				$choisi = $date;
			}
		}

		$cases[] = array(
			'jour' => $jour,
			'etat' => $etat,
		);
	}

	// Fin de mois sans créneau ouvert : le jour mis en avant reste aujourd'hui.
	if ( null === $choisi ) {
		$choisi = $maintenant;
	}

	return array(
		'mois'   => wp_date( 'F Y', $premier->getTimestamp() ),
		'cases'  => $cases,
		'vides'  => $colonne,
		'choisi' => wp_date( 'l j F', $choisi->getTimestamp() ),
	);
}

/**
 * Retourne les initiales des jours de la semaine, dans l'ordre du site.
 *
 * @return array<int, array{initiale:string, nom:string}>
 */
function salama_blocs_calendrier_semaine() {
	global $wp_locale;

	$debut  = (int) get_option( 'start_of_week', 1 );
	$jours  = array();

	for ( $i = 0; $i < 7; $i++ ) {
		$nom = $wp_locale->get_weekday( ( $debut + $i ) % 7 );

		$jours[] = array(
			'initiale' => $wp_locale->get_weekday_initial( $nom ),
			'nom'      => $nom,
		);
	}

	return $jours;
}

/**
 * Retourne le panneau du calendrier : le mois, et la colonne des créneaux.
 *
 * Rien n'y est actionnable — les flèches, les créneaux et le bouton sont des
 * commandes désactivées, comme les champs du bloc Contact. Un calendrier qui
 * répondrait au clic sans rien réserver mentirait davantage qu'un calendrier
 * visiblement inerte.
 *
 * @return string
 */
function salama_blocs_calendrier_panneau() {
	$mois     = salama_blocs_calendrier_mois();
	$semaine  = salama_blocs_calendrier_semaine();
	$elements = salama_blocs_reservations();

	ob_start();
	?>
	<div class="salama-calendrier__panneau">
		<div class="salama-calendrier__mois">
			<div class="salama-calendrier__entete">
				<button type="button" class="salama-calendrier__fleche" disabled aria-label="<?php esc_attr_e( 'Mois précédent', 'salama-blocs' ); ?>">&lsaquo;</button>
				<p class="salama-calendrier__nom-mois"><?php echo esc_html( $mois['mois'] ); ?></p>
				<button type="button" class="salama-calendrier__fleche" disabled aria-label="<?php esc_attr_e( 'Mois suivant', 'salama-blocs' ); ?>">&rsaquo;</button>
			</div>

			<div class="salama-calendrier__grille">
				<?php foreach ( $semaine as $jour ) : ?>
					<span class="salama-calendrier__initiale"><abbr title="<?php echo esc_attr( $jour['nom'] ); ?>"><?php echo esc_html( $jour['initiale'] ); ?></abbr></span>
				<?php endforeach; ?>

				<?php for ( $vide = 0; $vide < $mois['vides']; $vide++ ) : ?>
					<span class="salama-calendrier__case salama-calendrier__case--vide" aria-hidden="true"></span>
				<?php endfor; ?>

				<?php foreach ( $mois['cases'] as $case ) : ?>
					<span class="salama-calendrier__case<?php echo '' !== $case['etat'] ? ' is-' . esc_attr( $case['etat'] ) : ''; ?>"><?php echo esc_html( $case['jour'] ); ?></span>
				<?php endforeach; ?>
			</div>

			<p class="salama-calendrier__legende">
				<span class="salama-calendrier__puce" aria-hidden="true"></span>
				<?php esc_html_e( 'Jours avec des créneaux disponibles', 'salama-blocs' ); ?>
			</p>
		</div>

		<div class="salama-calendrier__creneaux">
			<p class="salama-calendrier__jour-choisi"><?php echo esc_html( $mois['choisi'] ); ?></p>

			<?php if ( $elements ) : ?>
				<ul class="salama-calendrier__liste">
					<?php foreach ( $elements as $index => $element ) : ?>
						<li>
							<button type="button" class="salama-calendrier__creneau<?php echo 0 === $index ? ' is-choisi' : ''; ?>" disabled><?php echo esc_html( $element ); ?></button>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<?php
				echo salama_blocs_rappel( // phpcs:ignore WordPress.Security.EscapeOutput -- balisage déjà échappé.
					__( 'Aucun élément de réservation : ajoutez-en dans le menu « Réservations ».', 'salama-blocs' )
				);
				?>
			<?php endif; ?>

			<button type="button" class="salama-calendrier__bouton" disabled><?php esc_html_e( 'Réserver', 'salama-blocs' ); ?></button>
		</div>
	</div>
	<?php

	return (string) ob_get_clean();
}
