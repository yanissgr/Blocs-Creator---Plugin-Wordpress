<?php
/**
 * Ce dont l'éditeur a besoin pour montrer un aperçu conforme.
 *
 * Deux choses, et rien de plus :
 *
 *   - la liste des types de contenu qu'un carrousel peut parcourir, pour que
 *     le menu déroulant du bloc se remplisse tout seul quand un type s'ajoute ;
 *   - une route qui rend les cartes d'un carrousel telles qu'elles seront sur
 *     le site, pour que l'aperçu montre les vraies publications avec leurs
 *     vraies images plutôt qu'un dessin approximatif ;
 *   - une route qui rend le panneau du calendrier de réservation, pour la même
 *     raison : il dépend du mois en cours et des éléments saisis en back-office.
 *
 * @package BlocsCreator\Packs\Salama
 */

defined( 'ABSPATH' ) || exit;

/**
 * Retourne les types de contenu qu'un carrousel peut parcourir.
 *
 * Un carrousel se termine par un bouton vers l'archive : ne sont donc listés
 * que les types qui en ont une. Les articles font exception — leur « archive »
 * est la page des articles, que le thème sait retrouver.
 *
 * @return array<int, array{value:string, label:string}>
 */
function salama_blocs_types_publication() {
	$types = array();

	foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) {
		if ( 'attachment' === $type->name || 'page' === $type->name ) {
			continue;
		}

		if ( 'post' !== $type->name && ! $type->has_archive ) {
			continue;
		}

		$types[] = array(
			'value' => $type->name,
			'label' => $type->labels->name,
		);
	}

	return $types;
}

/**
 * Passe à l'éditeur la liste des types de contenu.
 *
 * Le calcul se fait ici, et non à l'enregistrement des blocs : les types de
 * contenu déclarés par ACF ne sont pas tous connus au moment où le script est
 * enregistré.
 */
function salama_blocs_donnees_editeur() {
	wp_localize_script(
		'salama-blocs-editeur',
		'salamaBlocs',
		array(
			'typesPublication' => salama_blocs_types_publication(),
		)
	);
}
add_action( 'enqueue_block_editor_assets', 'salama_blocs_donnees_editeur' );

/**
 * Déclare la route qui rend les cartes d'un carrousel.
 *
 * L'éditeur s'en sert pour afficher, dans le bloc, exactement les cartes que
 * le visiteur verra. C'est le même code que le rendu public — impossible que
 * l'aperçu et le site divergent.
 */
function salama_blocs_rest() {
	register_rest_route(
		'salama/v1',
		'/calendrier',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'salama_blocs_rest_calendrier',
			'permission_callback' => static function () {
				return current_user_can( 'edit_posts' );
			},
		)
	);

	register_rest_route(
		'salama/v1',
		'/carrousel',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'salama_blocs_rest_carrousel',
			'permission_callback' => static function () {
				return current_user_can( 'edit_posts' );
			},
			'args'                => array(
				'type'   => array(
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_key',
				),
				'nombre' => array(
					'type'    => 'integer',
					'default' => 5,
					'minimum' => 1,
					'maximum' => 20,
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'salama_blocs_rest' );

/**
 * Retourne les cartes d'un carrousel, pour l'aperçu de l'éditeur.
 *
 * @param WP_REST_Request $requete Requête.
 * @return WP_REST_Response|WP_Error
 */
function salama_blocs_rest_carrousel( $requete ) {
	if ( ! function_exists( 'salama_carousel_track' ) ) {
		return new WP_Error(
			'salama_theme_absent',
			__( 'Le thème Salama n\'est pas actif.', 'salama-blocs' ),
			array( 'status' => 501 )
		);
	}

	$type = (string) $requete['type'];

	if ( ! post_type_exists( $type ) ) {
		return new WP_Error(
			'salama_type_inconnu',
			__( 'Ce type de contenu n\'existe pas.', 'salama-blocs' ),
			array( 'status' => 404 )
		);
	}

	$objet = get_post_type_object( $type );
	$meta  = function_exists( 'salama_type_a_des_dates' ) && salama_type_a_des_dates( $type );

	/*
	 * Les cartes de l'aperçu sont rendues sans lien : cliquer l'une d'elles
	 * dans l'éditeur quitterait la page en cours d'écriture. C'est le dernier
	 * argument de salama_carousel_track() — les cartes deviennent des <span>,
	 * au dessin identique mais sans href, donc hors de portée de la souris,
	 * du clavier et des lecteurs d'écran.
	 */
	return rest_ensure_response(
		array(
			'cartes'  => salama_carousel_track( $type, (int) $requete['nombre'], $meta, false ),
			'archive' => function_exists( 'salama_archive_link' ) ? salama_archive_link( $type ) : '',
			'libelle' => $objet->labels->name,
		)
	);
}

/**
 * Retourne le panneau du calendrier, pour l'aperçu de l'éditeur.
 *
 * Le mois en cours et la liste des éléments de réservation sont deux données du
 * site : les redessiner en JavaScript, c'était accepter qu'ils divergent du
 * rendu public au premier ajustement.
 *
 * @return WP_REST_Response
 */
function salama_blocs_rest_calendrier() {
	return rest_ensure_response(
		array(
			'panneau' => salama_blocs_calendrier_panneau(),
		)
	);
}
