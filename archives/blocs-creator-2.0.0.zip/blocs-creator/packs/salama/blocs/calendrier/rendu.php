<?php
/**
 * Maquette du calendrier de réservation : aucun créneau réservable pour l'instant.
 *
 * Le panneau vient de salama_blocs_calendrier_panneau() — la même fonction que
 * l'aperçu de l'éditeur appelle par la route salama/v1/calendrier.
 *
 * @package BlocsCreator\Packs\Salama
 * @var array $attributes Attributs du bloc.
 */
defined( 'ABSPATH' ) || exit;

$salama_niveau    = salama_blocs_niveau( $attributes['niveau'] ?? 2 );
$salama_titre     = trim( (string) ( $attributes['titre'] ?? '' ) );
$salama_chapo     = trim( (string) ( $attributes['chapo'] ?? '' ) );
$salama_attributs = get_block_wrapper_attributes( array( 'class' => 'salama-calendrier' ) );
?>
<div <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<?php if ( '' !== $salama_titre ) : ?>
		<?php printf( '<h%1$d class="salama-calendrier__titre">%2$s</h%1$d>', $salama_niveau, wp_kses_post( $salama_titre ) ); ?>
	<?php endif; ?>

	<?php if ( '' !== $salama_chapo ) : ?>
		<p class="salama-calendrier__intro"><?php echo wp_kses_post( $salama_chapo ); ?></p>
	<?php endif; ?>

	<?php echo salama_blocs_calendrier_panneau(); // phpcs:ignore WordPress.Security.EscapeOutput -- balisage déjà échappé. ?>
</div>
