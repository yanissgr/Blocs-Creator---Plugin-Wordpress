<?php
/**
 * Maquette du bloc Contact : aucun formulaire soumis ni traitement de données.
 *
 * @package BlocsCreator\Packs\Salama
 * @var array $attributes Attributs du bloc.
 */
defined( 'ABSPATH' ) || exit;

$salama_niveau = salama_blocs_niveau( $attributes['niveau'] ?? 2 );
$salama_attributs = get_block_wrapper_attributes( array( 'class' => 'salama-contact' ) );
?>
<div <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<?php printf( '<h%1$d class="salama-contact__titre">%2$s</h%1$d>', $salama_niveau, wp_kses_post( $attributes['titre'] ?? '' ) ); ?>
	<div class="salama-contact__panneau">
		<div class="salama-contact__champ">
			<span class="salama-contact__libelle"><?php esc_html_e( 'Nom', 'salama-blocs' ); ?></span>
			<div class="salama-contact__identite">
				<input type="text" disabled aria-label="<?php esc_attr_e( 'Prénom', 'salama-blocs' ); ?>" placeholder="<?php esc_attr_e( 'Prénom', 'salama-blocs' ); ?>">
				<input type="text" disabled aria-label="<?php esc_attr_e( 'Nom', 'salama-blocs' ); ?>" placeholder="<?php esc_attr_e( 'Nom', 'salama-blocs' ); ?>">
			</div>
		</div>
		<label class="salama-contact__champ">
			<span class="salama-contact__libelle"><?php esc_html_e( 'Mail', 'salama-blocs' ); ?></span>
			<input type="email" disabled placeholder="<?php esc_attr_e( 'Adresse mail', 'salama-blocs' ); ?>">
		</label>
		<label class="salama-contact__champ">
			<span class="salama-contact__libelle"><?php esc_html_e( 'Téléphone', 'salama-blocs' ); ?></span>
			<input type="tel" disabled placeholder="06 00 00 00 00">
		</label>
		<label class="salama-contact__champ">
			<span class="salama-contact__libelle"><?php esc_html_e( 'Sujet du message', 'salama-blocs' ); ?></span>
			<input type="text" disabled placeholder="<?php esc_attr_e( 'Demande', 'salama-blocs' ); ?>">
		</label>
		<label class="salama-contact__champ">
			<span class="salama-contact__libelle"><?php esc_html_e( 'Message', 'salama-blocs' ); ?></span>
			<textarea disabled rows="5"></textarea>
		</label>
		<div class="salama-contact__actions">
			<button class="salama-contact__bouton" type="button" disabled><?php esc_html_e( 'Envoyer', 'salama-blocs' ); ?></button>
		</div>
	</div>
</div>
