<?php
/**
 * Rendu du bloc « Bannière ».
 *
 * Reprend le dessin du bloc Couverture qui ouvrait l'accueil, à trois
 * changements près : plus d'aplat, un filet qui le remplace, et une image
 * facultative masquée par le cercle au pinceau.
 *
 * La hauteur de la bannière ne dépend jamais de l'image : le cercle est posé
 * en absolu par le CSS et déborde du cadre en haut comme en bas. C'est une
 * demande de dessin, pas un accident — voir .salama-banniere__media dans
 * blocs.css.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Inutilisé, le bloc n'a pas de contenu interne.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_titre  = trim( (string) ( $attributes['titre'] ?? '' ) );
$salama_chapo  = trim( (string) ( $attributes['chapo'] ?? '' ) );
$salama_bouton = trim( (string) ( $attributes['bouton'] ?? '' ) );
$salama_lien   = trim( (string) ( $attributes['lien'] ?? '' ) );
$salama_onglet = ! empty( $attributes['nouvelOnglet'] );
$salama_image  = (int) ( $attributes['imageId'] ?? 0 );
$salama_point  = is_array( $attributes['pointFocal'] ?? null ) ? $attributes['pointFocal'] : array();
$salama_x      = is_numeric( $salama_point['x'] ?? null ) ? max( 0, min( 1, (float) $salama_point['x'] ) ) : 0.5;
$salama_y      = is_numeric( $salama_point['y'] ?? null ) ? max( 0, min( 1, (float) $salama_point['y'] ) ) : 0.5;

/*
 * La bannière porte le titre de la page : son plancher est donc h1, là où les
 * autres blocs partent de h2. Le plafond est h2 — au-delà, ce n'est plus une
 * bannière mais une section, et le bloc Texte et image fait déjà cela.
 */
$salama_niveau = min( 2, salama_blocs_niveau( $attributes['niveau'] ?? 1, 1 ) );

$salama_classes = 'salama-banniere';

if ( $salama_image > 0 ) {
	$salama_classes .= ' salama-banniere--avec-image';
}

if ( false === ( $attributes['fondVert'] ?? true ) ) {
	$salama_classes .= ' salama-banniere--sans-fond-vert';
}

if ( 'rouge' === ( $attributes['couleurFond'] ?? 'vert' ) ) {
	$salama_classes .= ' salama-banniere--fond-rouge';
}

$salama_attributs = get_block_wrapper_attributes(
	array(
		'class' => $salama_classes,
		'style' => sprintf( '--salama-image-position: %s%% %s%%;', $salama_x * 100, $salama_y * 100 ),
	)
);
?>
<section <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>

	<div class="salama-banniere__texte">

		<?php if ( '' !== $salama_titre ) : ?>
			<h<?php echo (int) $salama_niveau; ?> class="salama-banniere__titre">
				<?php echo wp_kses_post( $salama_titre ); ?>
			</h<?php echo (int) $salama_niveau; ?>>
		<?php endif; ?>

		<?php if ( '' !== $salama_chapo ) : ?>
			<p class="salama-banniere__chapo"><?php echo wp_kses_post( $salama_chapo ); ?></p>
		<?php endif; ?>

		<?php if ( '' !== $salama_bouton ) : ?>

			<?php if ( '' !== $salama_lien ) : ?>

				<a
					class="salama-btn salama-btn--fill salama-banniere__bouton"
					href="<?php echo esc_url( $salama_lien ); ?>"
					<?php echo $salama_onglet ? ' target="_blank" rel="noreferrer noopener"' : ''; ?>
				><?php echo wp_kses_post( $salama_bouton ); ?></a>

			<?php else : ?>

				<?php
				/*
				 * Sans destination, on rend un <span> plutôt qu'un <a href="">
				 * qui renverrait le visiteur sur la page courante : mieux vaut
				 * un bouton inerte qu'un lien menteur. La rédaction, elle, est
				 * prévenue.
				 */
				?>
				<span class="salama-btn salama-btn--fill salama-banniere__bouton"><?php echo wp_kses_post( $salama_bouton ); ?></span>
				<?php echo salama_blocs_rappel( __( 'Le bouton de cette bannière n\'a pas de destination : il s\'affiche mais n\'est pas cliquable. Renseignez son lien dans la colonne de droite de l\'éditeur.', 'salama-blocs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

			<?php endif; ?>

		<?php endif; ?>

	</div>

	<?php if ( $salama_image > 0 ) : ?>
		<div class="salama-banniere__media">
			<?php echo salama_blocs_image( $salama_image, 'full' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>
	<?php endif; ?>

</section>
