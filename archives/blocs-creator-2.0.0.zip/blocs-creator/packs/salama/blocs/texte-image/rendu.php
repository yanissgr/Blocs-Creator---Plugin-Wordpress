<?php
/**
 * Rendu du bloc « Texte et image ».
 *
 * Le bloc rosé et le disque sont des pseudo-éléments de la figure : purement
 * décoratifs, ils n'ajoutent aucun balisage et n'ont rien à annoncer à un
 * lecteur d'écran. Leurs interrupteurs posent donc des classes sur la section.
 *
 * Le pinceau, lui, est un vrai <span> : il se place dans le flux, sous le
 * dernier paragraphe, ce qu'une hauteur de pseudo-élément ne permettrait pas.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Blocs internes déjà rendus.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_sens   = 'image-gauche' === ( $attributes['sens'] ?? '' ) ? 'image-gauche' : 'image-droite';
$salama_niveau = salama_blocs_niveau( $attributes['niveau'] ?? 2 );
$salama_titre  = trim( (string) ( $attributes['titre'] ?? '' ) );

$salama_classes = array( 'salama-ti', 'salama-ti--' . $salama_sens );

if ( ! empty( $attributes['decorBloc'] ) ) {
	$salama_classes[] = 'salama-ti--bloc';
}

if ( ! empty( $attributes['decorDisque'] ) ) {
	$salama_classes[] = 'salama-ti--disque';
}

$salama_attributs = get_block_wrapper_attributes(
	array( 'class' => implode( ' ', $salama_classes ) )
);
?>
<section <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<div class="salama-ti__grille">

		<div class="salama-ti__texte">
			<?php if ( '' !== $salama_titre ) : ?>
				<?php printf( '<h%1$d class="salama-ti__titre">%2$s</h%1$d>', $salama_niveau, wp_kses_post( $salama_titre ) ); ?>
			<?php endif; ?>

			<div class="salama-ti__corps">
				<?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>

			<?php if ( ! empty( $attributes['decorPinceau'] ) ) : ?>
				<span class="salama-ti__pinceau" aria-hidden="true"></span>
			<?php endif; ?>
		</div>

		<figure class="salama-ti__figure">
			<?php echo salama_blocs_image( $attributes['imageId'] ?? 0, 'salama-wide' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</figure>

	</div>
</section>
