<?php
/**
 * Lien compact avec une image décorative, utilisable dans toute colonne.
 *
 * @package BlocsCreator\Packs\Salama
 * @var array $attributes Attributs du bloc.
 */
defined( 'ABSPATH' ) || exit;

$salama_libelle = trim( wp_strip_all_tags( $attributes['libelle'] ?? '' ) );
if ( '' === $salama_libelle ) {
	echo salama_blocs_rappel( __( 'Ajoutez un libellé au lien avec icône pour le rendre visible sur le site.', 'salama-blocs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	return;
}

$salama_url   = esc_url( trim( $attributes['url'] ?? '' ) );
$salama_image = absint( $attributes['imageId'] ?? 0 );
$salama_tag   = $salama_url ? 'a' : 'span';
$salama_attributs = get_block_wrapper_attributes( array( 'class' => 'salama-lien-icone' ) );
?>
<div <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<<?php echo $salama_tag; // phpcs:ignore WordPress.Security.EscapeOutput ?> class="salama-lien-icone__lien"
		<?php if ( $salama_url ) : ?>
			href="<?php echo $salama_url; // phpcs:ignore WordPress.Security.EscapeOutput ?>"
			<?php if ( ! empty( $attributes['nouvelOnglet'] ) ) : ?>target="_blank" rel="noopener noreferrer"<?php endif; ?>
		<?php endif; ?>
	>
		<?php if ( $salama_image && wp_attachment_is_image( $salama_image ) ) : ?>
			<?php echo wp_get_attachment_image( $salama_image, 'full', false, array( 'class' => 'salama-lien-icone__image', 'alt' => '', 'aria-hidden' => 'true', 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<?php endif; ?>
		<span class="salama-lien-icone__libelle"><?php echo esc_html( $salama_libelle ); ?></span>
	</<?php echo $salama_tag; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<?php if ( ! $salama_url ) : ?>
		<?php echo salama_blocs_rappel( __( 'Renseignez la destination de ce lien dans les réglages du bloc.', 'salama-blocs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<?php endif; ?>
</div>
