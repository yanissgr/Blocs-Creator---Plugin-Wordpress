<?php
/**
 * Rendu du bloc « Spécialités ».
 *
 * Les cartes sont des blocs internes : ce fichier ne fait que poser le titre et
 * la liste qui les contient. Le sens du débord de chaque carte se déduit de sa
 * position en CSS (:nth-child), pas d'un attribut — rien à régler, et une
 * troisième carte s'insère sans réfléchir.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Cartes déjà rendues.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_niveau = salama_blocs_niveau( $attributes['niveau'] ?? 2 );
$salama_titre  = trim( (string) ( $attributes['titre'] ?? '' ) );
$salama_cartes = trim( (string) $content );

$salama_attributs = get_block_wrapper_attributes( array( 'class' => 'salama-spe' ) );
?>
<section <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>

	<?php if ( '' !== $salama_titre ) : ?>
		<?php printf( '<h%1$d class="salama-spe__titre">%2$s</h%1$d>', $salama_niveau, wp_kses_post( $salama_titre ) ); ?>
	<?php endif; ?>

	<?php if ( '' !== $salama_cartes ) : ?>
		<ul class="salama-spe__grille">
			<?php echo $salama_cartes; // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</ul>
	<?php else : ?>
		<?php echo salama_blocs_rappel( __( 'Cette grille ne contient aucune carte : elle reste invisible pour les visiteurs. Ajoutez une carte depuis l\'éditeur.', 'salama-blocs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<?php endif; ?>

</section>
