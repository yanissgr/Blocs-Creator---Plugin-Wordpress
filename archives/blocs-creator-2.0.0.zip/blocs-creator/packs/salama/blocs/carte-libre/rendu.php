<?php
/**
 * Rendu du bloc « Carte ».
 *
 * Le libellé vient AVANT l'image dans le balisage : c'est lui qui nomme le
 * lien, il doit donc être lu en premier. Le CSS le pose ensuite sur le bloc
 * d'accent, au-dessus de l'image.
 *
 * Ce bloc ressemble à salama/carte sans le remplacer : celui-là loge son
 * libellé dans une pastille à cheval sur l'image et ne vit que dans le bloc
 * Spécialités. Ici le libellé est écrit sur le bloc d'accent, et la grille se
 * règle de une à quatre colonnes.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Inutilisé, le bloc n'a pas de contenu interne.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_url     = trim( (string) ( $attributes['url'] ?? '' ) );
$salama_libelle = trim( (string) ( $attributes['libelle'] ?? '' ) );
$salama_onglet  = ! empty( $attributes['nouvelOnglet'] );

$salama_attributs = get_block_wrapper_attributes( array( 'class' => 'salama-cartes__item' ) );

$salama_media = salama_blocs_image( $attributes['imageId'] ?? 0, 'salama-card' );

// La balise change, son contenu non : on le prépare une seule fois.
ob_start();
?>
	<?php if ( '' !== $salama_libelle ) : ?>
		<span class="salama-cl__libelle"><?php echo wp_kses_post( $salama_libelle ); ?></span>
	<?php endif; ?>
	<span class="salama-cl__media"><?php echo $salama_media; // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
<?php
$salama_interieur = ob_get_clean();
?>
<li <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>

	<?php if ( '' !== $salama_url ) : ?>

		<a
			class="salama-cl"
			href="<?php echo esc_url( $salama_url ); ?>"
			<?php echo $salama_onglet ? ' target="_blank" rel="noreferrer noopener"' : ''; ?>
		><?php echo $salama_interieur; // phpcs:ignore WordPress.Security.EscapeOutput ?></a>

	<?php else : ?>

		<div class="salama-cl salama-cl--sans-lien"><?php echo $salama_interieur; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
		<?php echo salama_blocs_rappel( __( 'Cette carte n\'a pas de destination : elle s\'affiche mais n\'est pas cliquable. Renseignez son lien dans la colonne de droite de l\'éditeur.', 'salama-blocs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

	<?php endif; ?>

</li>
