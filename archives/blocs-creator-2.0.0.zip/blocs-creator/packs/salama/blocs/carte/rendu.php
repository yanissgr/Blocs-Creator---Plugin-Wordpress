<?php
/**
 * Rendu du bloc « Carte de spécialité ».
 *
 * La carte entière est le lien, et la pastille vient AVANT l'image dans le
 * balisage : c'est elle qui nomme le lien, elle doit donc être lue en premier.
 * Le CSS la repositionne ensuite à cheval sur le bord haut de l'image.
 *
 * Sans destination, la carte n'est pas rendue en lien : un <a href=""> renverrait
 * le visiteur sur la page courante — mieux vaut un bloc inerte qu'un lien menteur.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Inutilisé, le bloc n'a pas de contenu interne.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_url     = trim( (string) ( $attributes['url'] ?? '' ) );
$salama_libelle = trim( (string) ( $attributes['libelle'] ?? '' ) );
$salama_onglet  = ! empty( $attributes['nouvelOnglet'] );

$salama_attributs = get_block_wrapper_attributes( array( 'class' => 'salama-spe__item' ) );

/*
 * L'image porte l'alt de la médiathèque. Quand la pastille nomme déjà le lien,
 * un alt qui répète le libellé ferait entendre deux fois la même chose : c'est
 * à la rédaction de décrire la photo, ou de laisser l'alt vide.
 */
$salama_media = salama_blocs_image( $attributes['imageId'] ?? 0, 'salama-card' );

// La balise change, son contenu non : on le prépare une seule fois.
ob_start();
?>
	<?php if ( '' !== $salama_libelle ) : ?>
		<span class="salama-carte__libelle"><?php echo wp_kses_post( $salama_libelle ); ?></span>
	<?php endif; ?>
	<span class="salama-carte__media"><?php echo $salama_media; // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
<?php
$salama_interieur = ob_get_clean();
?>
<li <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>

	<?php if ( '' !== $salama_url ) : ?>

		<a
			class="salama-carte"
			href="<?php echo esc_url( $salama_url ); ?>"
			<?php echo $salama_onglet ? ' target="_blank" rel="noreferrer noopener"' : ''; ?>
		><?php echo $salama_interieur; // phpcs:ignore WordPress.Security.EscapeOutput ?></a>

	<?php else : ?>

		<div class="salama-carte salama-carte--sans-lien"><?php echo $salama_interieur; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
		<?php echo salama_blocs_rappel( __( 'Cette carte n\'a pas de destination : elle s\'affiche mais n\'est pas cliquable. Renseignez son lien dans la colonne de droite de l\'éditeur.', 'salama-blocs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

	<?php endif; ?>

</li>
