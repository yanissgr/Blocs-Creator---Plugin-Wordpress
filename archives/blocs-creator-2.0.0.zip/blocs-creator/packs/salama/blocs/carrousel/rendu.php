<?php
/**
 * Rendu du bloc « Carrousel ».
 *
 * Le balisage vient du thème (`salama_carousel()`, inc/carousel.php) : le bloc
 * ne fait que traduire ses réglages en arguments. C'est ce qui garantit qu'un
 * carrousel posé au bloc, un carrousel posé au code court `[carrousel]` et un
 * carrousel appelé depuis un gabarit PHP donnent exactement le même résultat.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Inutilisé, le bloc n'a pas de contenu interne.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'salama_carousel' ) ) {
	echo salama_blocs_rappel( // phpcs:ignore WordPress.Security.EscapeOutput
		__( 'Ce bloc a besoin du thème Salama pour s\'afficher.', 'salama-blocs' )
	);

	return;
}

$salama_variante = empty( $attributes['fond'] ) ? '' : 'inverse';

echo salama_carousel( // phpcs:ignore WordPress.Security.EscapeOutput -- balisage déjà échappé.
	array(
		'type'      => (string) ( $attributes['type'] ?? 'atelier' ),
		'titre'     => (string) ( $attributes['titre'] ?? '' ),
		'intro'     => (string) ( $attributes['intro'] ?? '' ),
		'niveau'    => 'h' . salama_blocs_niveau( $attributes['niveau'] ?? 2, 1 ),
		'variante'  => $salama_variante,
		'lien'      => (string) ( $attributes['bouton'] ?? '' ),
		'nombre'    => (int) ( $attributes['nombre'] ?? 5 ),
		'attributs' => get_block_wrapper_attributes(
			array( 'class' => salama_carousel_classes( '', $salama_variante ) )
		),
	)
);
