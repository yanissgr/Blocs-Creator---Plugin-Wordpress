<?php
/**
 * Rendu du bloc « Titre avec flag ».
 *
 * @package BlocsCreator\Packs\Salama
 * @var array $attributes Attributs du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_niveau = salama_blocs_niveau( $attributes['niveau'] ?? 2 );
$salama_classes = 'salama-titre-flag';
if ( ! empty( $attributes['inverse'] ) ) {
	$salama_classes .= ' salama-titre-flag--inverse';
}
$salama_attributs = get_block_wrapper_attributes( array( 'class' => $salama_classes ) );
?>
<div <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<div class="salama-titre-flag__flag">
		<p class="salama-titre-flag__texte"><?php echo wp_kses_post( $attributes['texte'] ?? '' ); ?></p>
	</div>
	<?php printf( '<h%1$d class="salama-titre-flag__titre">%2$s</h%1$d>', $salama_niveau, wp_kses_post( $attributes['titre'] ?? '' ) ); ?>
</div>
