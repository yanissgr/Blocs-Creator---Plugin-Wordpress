<?php
/**
 * Rendu du bloc « Cartes ».
 *
 * Le parent ne porte qu'un réglage — le nombre de colonnes — et le passe au
 * CSS par une classe plutôt que par un style en ligne : les replis de
 * mobile (deux colonnes, puis une) sont des décisions de feuille de style, pas
 * de rédaction.
 *
 * Le titre est facultatif : une grille de cartes n'a pas toujours besoin d'être
 * annoncée.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Les cartes enfants, déjà rendues.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_titre    = trim( (string) ( $attributes['titre'] ?? '' ) );
$salama_niveau   = salama_blocs_niveau( $attributes['niveau'] ?? 2 );
$salama_colonnes = min( 4, max( 1, (int) ( $attributes['colonnes'] ?? 3 ) ) );

$salama_attributs = get_block_wrapper_attributes(
	array( 'class' => 'salama-cartes salama-cartes--' . $salama_colonnes )
);
?>
<section <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>

	<?php if ( '' !== $salama_titre ) : ?>
		<h<?php echo (int) $salama_niveau; ?> class="salama-cartes__titre">
			<?php echo wp_kses_post( $salama_titre ); ?>
		</h<?php echo (int) $salama_niveau; ?>>
	<?php endif; ?>

	<ul class="salama-cartes__grille">
		<?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</ul>

</section>
