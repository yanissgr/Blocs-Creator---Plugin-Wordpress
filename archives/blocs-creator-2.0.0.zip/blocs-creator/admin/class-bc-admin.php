<?php
/**
 * L'administration : menu, écrans, actions.
 *
 * Un seul menu, quatre entrées, et la règle qui les ordonne : on regarde
 * d'abord ce qui existe (Tous les blocs), on en ajoute (Ajouter), on règle ce
 * qui vaut pour tous (Réglages), on déplace d'un site à l'autre (Outils).
 * L'aide vient en dernier parce qu'elle ne se lit qu'une fois.
 *
 * @package BlocsCreator
 */

defined( 'ABSPATH' ) || exit;

/**
 * Écrans d'administration.
 */
class BC_Admin {

	/**
	 * Identifiant de la page principale.
	 */
	const PAGE = 'blocs-creator';

	/**
	 * Capacité requise.
	 */
	const CAP = 'manage_options';

	/**
	 * L'écran d'édition d'une définition.
	 *
	 * @var BC_Ecran_Definition
	 */
	private $ecran;

	/**
	 * Branche les hooks.
	 */
	public function demarrer() {
		$this->ecran = new BC_Ecran_Definition();
		$this->ecran->demarrer();

		( new BC_Outils() )->demarrer();

		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_filter( 'parent_file', array( $this, 'menu_ouvert' ) );
		add_filter( 'submenu_file', array( $this, 'sous_menu_ouvert' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( BLOCS_CREATOR_FICHIER ), array( $this, 'liens_plugin' ) );
		add_action( 'admin_post_bc_creer_gabarit', array( $this, 'action_creer_gabarit' ) );
		add_action( 'admin_post_bc_dupliquer', array( $this, 'action_dupliquer' ) );
		add_action( 'admin_notices', array( $this, 'notices' ) );
	}

	/* ------------------------------------------------------------------ *
	 * Menu
	 * ------------------------------------------------------------------ */

	/**
	 * Déclare le menu et ses pages.
	 */
	public function menu() {
		add_menu_page(
			__( 'Blocs Creator', 'blocs-creator' ),
			__( 'Blocs Creator', 'blocs-creator' ),
			self::CAP,
			self::PAGE,
			array( $this, 'page_liste' ),
			'dashicons-layout',
			58
		);

		add_submenu_page(
			self::PAGE,
			__( 'Tous les blocs', 'blocs-creator' ),
			__( 'Tous les blocs', 'blocs-creator' ),
			self::CAP,
			self::PAGE,
			array( $this, 'page_liste' )
		);

		add_submenu_page(
			self::PAGE,
			__( 'Ajouter un bloc', 'blocs-creator' ),
			__( 'Ajouter un bloc', 'blocs-creator' ),
			self::CAP,
			'post-new.php?post_type=' . BC_Definition::TYPE
		);

		add_submenu_page(
			self::PAGE,
			__( 'Réglages', 'blocs-creator' ),
			__( 'Réglages', 'blocs-creator' ),
			self::CAP,
			self::PAGE . '-reglages',
			array( $this, 'page_reglages' )
		);

		add_submenu_page(
			self::PAGE,
			__( 'Outils', 'blocs-creator' ),
			__( 'Outils', 'blocs-creator' ),
			self::CAP,
			self::PAGE . '-outils',
			array( 'BC_Outils', 'page' )
		);

		add_submenu_page(
			self::PAGE,
			__( 'Écrire un gabarit', 'blocs-creator' ),
			__( 'Écrire un gabarit', 'blocs-creator' ),
			self::CAP,
			self::PAGE . '-aide',
			array( $this, 'page_aide' )
		);
	}

	/**
	 * Garde le menu ouvert sur les écrans du type de contenu.
	 *
	 * @param string $parent Fichier parent courant.
	 * @return string
	 */
	public function menu_ouvert( $parent ) {
		$ecran = get_current_screen();

		if ( $ecran && BC_Definition::TYPE === $ecran->post_type ) {
			return self::PAGE;
		}

		return $parent;
	}

	/**
	 * Souligne la bonne entrée du sous-menu.
	 *
	 * @param string $sous_menu Entrée courante.
	 * @return string
	 */
	public function sous_menu_ouvert( $sous_menu ) {
		$ecran = get_current_screen();

		if ( $ecran && BC_Definition::TYPE === $ecran->post_type ) {
			return 'post-new' === $ecran->base
				? 'post-new.php?post_type=' . BC_Definition::TYPE
				: self::PAGE;
		}

		return $sous_menu;
	}

	/**
	 * Ajoute les liens utiles sous le plugin, dans la liste des extensions.
	 *
	 * @param array $liens Liens existants.
	 * @return array
	 */
	public function liens_plugin( $liens ) {
		array_unshift(
			$liens,
			sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ),
				esc_html__( 'Mes blocs', 'blocs-creator' )
			),
			sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=' . self::PAGE . '-reglages' ) ),
				esc_html__( 'Réglages', 'blocs-creator' )
			)
		);

		return $liens;
	}

	/* ------------------------------------------------------------------ *
	 * Assets
	 * ------------------------------------------------------------------ */

	/**
	 * Charge le style et le script de l'administration.
	 *
	 * @param string $hook Écran courant.
	 */
	public function assets( $hook ) {
		$ecran     = get_current_screen();
		$est_nous  = str_contains( (string) $hook, self::PAGE );
		$est_bloc  = $ecran && BC_Definition::TYPE === $ecran->post_type;

		if ( ! $est_nous && ! $est_bloc ) {
			return;
		}

		wp_enqueue_style( 'dashicons' );

		wp_enqueue_style(
			'blocs-creator-admin',
			BLOCS_CREATOR_URL . 'admin/css/admin.css',
			array(),
			$this->version( 'admin/css/admin.css' )
		);

		if ( ! $est_bloc ) {
			return;
		}

		wp_enqueue_script(
			'blocs-creator-constructeur',
			BLOCS_CREATOR_URL . 'admin/js/constructeur.js',
			array( 'wp-i18n', 'wp-dom-ready' ),
			$this->version( 'admin/js/constructeur.js' ),
			true
		);

		wp_set_script_translations( 'blocs-creator-constructeur', 'blocs-creator', BLOCS_CREATOR_DIR . 'languages' );

		wp_add_inline_script(
			'blocs-creator-constructeur',
			'window.blocsCreatorAdmin = ' . wp_json_encode( $this->donnees_constructeur() ) . ';',
			'before'
		);
	}

	/**
	 * Retourne une version d'asset basée sur la date du fichier.
	 *
	 * @param string $chemin Chemin relatif à la racine du plugin.
	 * @return string
	 */
	private function version( $chemin ) {
		$fichier = BLOCS_CREATOR_DIR . ltrim( $chemin, '/' );

		return file_exists( $fichier ) ? (string) filemtime( $fichier ) : BLOCS_CREATOR_VERSION;
	}

	/**
	 * Rassemble ce dont le constructeur de champs a besoin.
	 *
	 * @return array
	 */
	private function donnees_constructeur() {
		$types = array();

		foreach ( BC_Champs::catalogue() as $slug => $def ) {
			$types[] = array(
				'type'        => $slug,
				'libelle'     => $def['libelle'],
				'famille'     => $def['famille'],
				'description' => $def['description'],
				'reglages'    => (array) ( $def['reglages'] ?? array() ),
				'sousChamps'  => ! empty( $def['sous_champs'] ),
				'porteValeur' => $def['porte_valeur'] ?? true,
			);
		}

		$types_contenu = array();

		foreach ( get_post_types( array( 'show_ui' => true ), 'objects' ) as $type ) {
			if ( in_array( $type->name, array( 'attachment', BC_Definition::TYPE ), true ) ) {
				continue;
			}

			$types_contenu[] = array(
				'value' => $type->name,
				'label' => $type->labels->name,
			);
		}

		$taxonomies = array();

		foreach ( get_taxonomies( array( 'show_ui' => true ), 'objects' ) as $taxonomie ) {
			$taxonomies[] = array(
				'value' => $taxonomie->name,
				'label' => $taxonomie->labels->name,
			);
		}

		$tailles = array();

		foreach ( array_merge( get_intermediate_image_sizes(), array( 'full' ) ) as $taille ) {
			$tailles[] = array(
				'value' => $taille,
				'label' => $taille,
			);
		}

		return array(
			'types'        => $types,
			'familles'     => BC_Champs::familles(),
			'typesContenu' => $types_contenu,
			'taxonomies'   => $taxonomies,
			'tailles'      => $tailles,
			'dashicons'    => BC_Reglages::dashicons(),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Pages
	 * ------------------------------------------------------------------ */

	/**
	 * Affiche l'écran « Tous les blocs ».
	 */
	public function page_liste() {
		// WP_List_Table n'est déclarée qu'une fois wp-admin chargé : notre
		// tableau, qui en hérite, ne peut donc pas l'être plus tôt.
		require_once BLOCS_CREATOR_DIR . 'admin/class-bc-liste-table.php';

		$table = new BC_Liste_Table();
		$table->prepare_items();

		include BLOCS_CREATOR_DIR . 'admin/vues/liste.php';
	}

	/**
	 * Affiche l'écran des réglages.
	 */
	public function page_reglages() {
		$reglages = blocs_creator()->reglages;

		include BLOCS_CREATOR_DIR . 'admin/vues/reglages.php';
	}

	/**
	 * Affiche l'aide à l'écriture d'un gabarit.
	 */
	public function page_aide() {
		include BLOCS_CREATOR_DIR . 'admin/vues/aide.php';
	}

	/* ------------------------------------------------------------------ *
	 * Actions
	 * ------------------------------------------------------------------ */

	/**
	 * Crée le fichier de gabarit d'un bloc.
	 */
	public function action_creer_gabarit() {
		$post_id = isset( $_GET['bloc'] ) ? absint( $_GET['bloc'] ) : 0;

		if ( ! current_user_can( self::CAP ) || ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ?? '' ), 'bc_creer_gabarit_' . $post_id ) ) {
			wp_die( esc_html__( 'Action non autorisée.', 'blocs-creator' ), 403 );
		}

		$definition = BC_Definition::charger( $post_id );

		if ( null === $definition ) {
			$this->rediriger( $post_id, 'erreur', __( 'Ce bloc est introuvable.', 'blocs-creator' ) );
		}

		$resultat = BC_Gabarits::creer( $definition );

		if ( is_wp_error( $resultat ) ) {
			$this->rediriger( $post_id, 'erreur', $resultat->get_error_message() );
		}

		$this->rediriger(
			$post_id,
			'succes',
			sprintf(
				/* translators: %s: chemin du fichier créé. */
				__( 'Gabarit créé : %s', 'blocs-creator' ),
				BC_Gabarits::chemin_court( $resultat )
			)
		);
	}

	/**
	 * Duplique un bloc.
	 */
	public function action_dupliquer() {
		$post_id = isset( $_GET['bloc'] ) ? absint( $_GET['bloc'] ) : 0;

		if ( ! current_user_can( self::CAP ) || ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ?? '' ), 'bc_dupliquer_' . $post_id ) ) {
			wp_die( esc_html__( 'Action non autorisée.', 'blocs-creator' ), 403 );
		}

		$copie = BC_Definition::dupliquer( $post_id );

		if ( is_wp_error( $copie ) ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'       => self::PAGE,
						'bc_message' => 'erreur',
						'bc_texte'   => rawurlencode( $copie->get_error_message() ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		wp_safe_redirect( admin_url( 'post.php?post=' . (int) $copie . '&action=edit' ) );
		exit;
	}

	/**
	 * Renvoie vers l'écran d'édition d'un bloc avec un message.
	 *
	 * @param int    $post_id Bloc concerné.
	 * @param string $type    `succes` ou `erreur`.
	 * @param string $texte   Message.
	 */
	private function rediriger( $post_id, $type, $texte ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'post'       => $post_id,
					'action'     => 'edit',
					'bc_message' => $type,
					'bc_texte'   => rawurlencode( $texte ),
				),
				admin_url( 'post.php' )
			)
		);
		exit;
	}

	/**
	 * Affiche les messages posés par les actions.
	 */
	public function notices() {
		if ( empty( $_GET['bc_message'] ) ) {
			return;
		}

		$type  = 'succes' === $_GET['bc_message'] ? 'success' : 'error';
		$texte = isset( $_GET['bc_texte'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['bc_texte'] ) ) ) : '';

		if ( '' === $texte ) {
			return;
		}

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $texte )
		);
	}
}
