<?php
/**
 * L'écran des réglages.
 *
 * @package BlocsCreator
 *
 * @var BC_Reglages $reglages Les réglages.
 */

defined( 'ABSPATH' ) || exit;

$bc_valeurs = $reglages->tout();
$bc_dossier = get_stylesheet_directory() . '/' . trim( (string) $bc_valeurs['dossier_gabarits'], '/' );
?>
<div class="wrap bc-wrap">

	<h1><?php esc_html_e( 'Réglages', 'blocs-creator' ); ?></h1>

	<p class="bc-chapo">
		<?php esc_html_e( 'Ces réglages valent pour les blocs à venir. Les blocs déjà créés gardent ce qu\'ils ont : un identifiant de bloc ne change pas sans casser les pages qui s\'en servent.', 'blocs-creator' ); ?>
	</p>

	<form method="post" action="options.php">
		<?php settings_fields( 'blocs_creator_reglages' ); ?>

		<table class="form-table" role="presentation">

			<tr>
				<th scope="row">
					<label for="bc-r-espace"><?php esc_html_e( 'Espace de noms', 'blocs-creator' ); ?></label>
				</th>
				<td>
					<input type="text" id="bc-r-espace" class="regular-text"
						name="<?php echo esc_attr( BC_Reglages::OPTION ); ?>[espace]"
						value="<?php echo esc_attr( $bc_valeurs['espace'] ); ?>"
						pattern="[a-z0-9-]+">
					<p class="description">
						<?php
						printf(
							/* translators: %s: exemple de nom de bloc. */
							esc_html__( 'Le préfixe des blocs que vous créerez : %s. En minuscules, sans espace.', 'blocs-creator' ),
							'<code>' . esc_html( $bc_valeurs['espace'] ) . '/temoignages</code>'
						);
						?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					<label for="bc-r-categorie-titre"><?php esc_html_e( 'Catégorie dans l\'inséreur', 'blocs-creator' ); ?></label>
				</th>
				<td>
					<input type="text" id="bc-r-categorie-titre" class="regular-text"
						name="<?php echo esc_attr( BC_Reglages::OPTION ); ?>[categorie_titre]"
						value="<?php echo esc_attr( $bc_valeurs['categorie_titre'] ); ?>">
					<p class="description">
						<?php esc_html_e( 'Le titre de la section où vos blocs apparaissent quand on clique sur le « + » de l\'éditeur.', 'blocs-creator' ); ?>
					</p>

					<input type="hidden"
						name="<?php echo esc_attr( BC_Reglages::OPTION ); ?>[categorie]"
						value="<?php echo esc_attr( $bc_valeurs['categorie'] ); ?>">
				</td>
			</tr>

			<tr>
				<th scope="row">
					<label for="bc-r-dossier"><?php esc_html_e( 'Dossier des gabarits', 'blocs-creator' ); ?></label>
				</th>
				<td>
					<input type="text" id="bc-r-dossier" class="regular-text"
						name="<?php echo esc_attr( BC_Reglages::OPTION ); ?>[dossier_gabarits]"
						value="<?php echo esc_attr( $bc_valeurs['dossier_gabarits'] ); ?>">
					<p class="description">
						<?php esc_html_e( 'Relatif au thème actif. Les fichiers de rendu y sont cherchés, et créés.', 'blocs-creator' ); ?>
					</p>
					<p class="description">
						<code><?php echo esc_html( BC_Gabarits::chemin_court( $bc_dossier ) ); ?></code>
						<?php if ( is_dir( $bc_dossier ) ) : ?>
							<span class="bc-oui dashicons dashicons-yes-alt" aria-hidden="true"></span>
							<?php
							echo is_writable( $bc_dossier )
								? esc_html__( 'existe, accessible en écriture', 'blocs-creator' )
								: esc_html__( 'existe, mais verrouillé en écriture', 'blocs-creator' );
							?>
						<?php else : ?>
							<span class="bc-non dashicons dashicons-marker" aria-hidden="true"></span>
							<?php esc_html_e( 'sera créé au premier gabarit', 'blocs-creator' ); ?>
						<?php endif; ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row"><?php esc_html_e( 'À la création d\'un bloc', 'blocs-creator' ); ?></th>
				<td>
					<label>
						<input type="checkbox" value="1"
							name="<?php echo esc_attr( BC_Reglages::OPTION ); ?>[creer_gabarit]"
							<?php checked( ! empty( $bc_valeurs['creer_gabarit'] ) ); ?>>
						<?php esc_html_e( 'Créer le fichier de gabarit automatiquement', 'blocs-creator' ); ?>
					</label>
					<p class="description">
						<?php esc_html_e( 'Un fichier de départ, avec un exemple de code pour chaque champ déclaré. Il n\'est jamais réécrit ensuite.', 'blocs-creator' ); ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row"><?php esc_html_e( 'À la désinstallation', 'blocs-creator' ); ?></th>
				<td>
					<label>
						<input type="checkbox" value="1"
							name="<?php echo esc_attr( BC_Reglages::OPTION ); ?>[supprimer_donnees]"
							<?php checked( ! empty( $bc_valeurs['supprimer_donnees'] ) ); ?>>
						<?php esc_html_e( 'Supprimer les définitions de blocs et les réglages', 'blocs-creator' ); ?>
					</label>
					<p class="description">
						<?php esc_html_e( 'Décoché, tout reste en base : désinstaller puis réinstaller le plugin retrouve vos blocs. Les fichiers de gabarit du thème ne sont jamais supprimés, dans un cas comme dans l\'autre.', 'blocs-creator' ); ?>
					</p>
				</td>
			</tr>

		</table>

		<?php submit_button(); ?>
	</form>

</div>
