<?php
/**
 * Métabox « Identité ».
 *
 * L'espace de noms et l'identifiant composent le nom que le bloc portera dans
 * le contenu des pages. Les changer après coup casse les pages qui s'en
 * servent : l'écran le dit plutôt que de le laisser découvrir.
 *
 * @package BlocsCreator
 *
 * @var array   $definition La définition.
 * @var WP_Post $post       Le post.
 */

defined( 'ABSPATH' ) || exit;

$bc_usages = BC_Usage::compter( BC_Definition::nom( $definition ) );
?>
<div class="bc-metabox">

	<p class="bc-champ">
		<label for="bc-espace"><?php esc_html_e( 'Espace de noms', 'blocs-creator' ); ?></label>
		<input type="text" id="bc-espace" name="bc[espace]" class="widefat bc-surveille"
			value="<?php echo esc_attr( $definition['espace'] ); ?>"
			pattern="[a-z0-9-]+"
			data-role="espace">
		<span class="bc-aide"><?php esc_html_e( 'Le préfixe commun à vos blocs. En minuscules, sans espace.', 'blocs-creator' ); ?></span>
	</p>

	<p class="bc-champ">
		<label for="bc-slug"><?php esc_html_e( 'Identifiant', 'blocs-creator' ); ?></label>
		<input type="text" id="bc-slug" name="bc[slug]" class="widefat bc-surveille"
			value="<?php echo esc_attr( $definition['slug'] ); ?>"
			pattern="[a-z0-9-]+"
			data-role="slug">
		<span class="bc-aide"><?php esc_html_e( 'Déduit du nom si vous le laissez vide.', 'blocs-creator' ); ?></span>
	</p>

	<?php if ( $bc_usages > 0 ) : ?>
		<div class="bc-avertissement">
			<span class="dashicons dashicons-warning" aria-hidden="true"></span>
			<?php
			printf(
				esc_html(
					/* translators: %d: nombre de publications. */
					_n(
						'Ce bloc est posé dans %d publication. Changer son espace de noms ou son identifiant l\'y rendrait méconnaissable.',
						'Ce bloc est posé dans %d publications. Changer son espace de noms ou son identifiant l\'y rendrait méconnaissable.',
						$bc_usages,
						'blocs-creator'
					)
				),
				(int) $bc_usages
			);
			?>
		</div>
	<?php endif; ?>

	<p class="bc-champ">
		<label for="bc-description"><?php esc_html_e( 'Description', 'blocs-creator' ); ?></label>
		<textarea id="bc-description" name="bc[description]" class="widefat" rows="3"><?php echo esc_textarea( $definition['description'] ); ?></textarea>
		<span class="bc-aide"><?php esc_html_e( 'Affichée dans l\'inséreur de blocs, sous le nom.', 'blocs-creator' ); ?></span>
	</p>

	<div class="bc-champ">
		<label for="bc-icone"><?php esc_html_e( 'Icône', 'blocs-creator' ); ?></label>
		<div class="bc-icone-choix">
			<input type="text" id="bc-icone" name="bc[icone]" class="bc-icone-valeur"
				value="<?php echo esc_attr( $definition['icone'] ); ?>">
			<button type="button" class="button bc-icone-ouvrir" aria-expanded="false">
				<span class="dashicons dashicons-<?php echo esc_attr( $definition['icone'] ); ?>" aria-hidden="true"></span>
				<?php esc_html_e( 'Choisir', 'blocs-creator' ); ?>
			</button>
		</div>
		<div class="bc-icone-grille" hidden>
			<?php foreach ( BC_Reglages::dashicons() as $bc_icone ) : ?>
				<button type="button" class="bc-icone-bouton<?php echo $bc_icone === $definition['icone'] ? ' est-actif' : ''; ?>"
					data-icone="<?php echo esc_attr( $bc_icone ); ?>"
					title="<?php echo esc_attr( $bc_icone ); ?>">
					<span class="dashicons dashicons-<?php echo esc_attr( $bc_icone ); ?>" aria-hidden="true"></span>
				</button>
			<?php endforeach; ?>
		</div>
	</div>

	<p class="bc-champ">
		<label for="bc-categorie"><?php esc_html_e( 'Catégorie de l\'inséreur', 'blocs-creator' ); ?></label>
		<select id="bc-categorie" name="bc[categorie]" class="widefat">
			<?php
			$bc_categories = array( blocs_creator()->reglages->get( 'categorie' ) => blocs_creator()->reglages->get( 'categorie_titre' ) );

			foreach ( array( 'text', 'media', 'design', 'widgets', 'theme', 'embed' ) as $bc_native ) {
				$bc_categories[ $bc_native ] = $bc_native;
			}

			if ( ! isset( $bc_categories[ $definition['categorie'] ] ) ) {
				$bc_categories[ $definition['categorie'] ] = $definition['categorie'];
			}

			foreach ( $bc_categories as $bc_slug => $bc_titre ) :
				?>
				<option value="<?php echo esc_attr( $bc_slug ); ?>" <?php selected( $definition['categorie'], $bc_slug ); ?>>
					<?php echo esc_html( $bc_titre ); ?>
				</option>
			<?php endforeach; ?>
		</select>
	</p>

	<p class="bc-champ">
		<label for="bc-mots-cles"><?php esc_html_e( 'Mots-clés', 'blocs-creator' ); ?></label>
		<input type="text" id="bc-mots-cles" name="bc[mots_cles]" class="widefat"
			value="<?php echo esc_attr( implode( ', ', $definition['mots_cles'] ) ); ?>">
		<span class="bc-aide"><?php esc_html_e( 'Séparés par des virgules. Ils servent à retrouver le bloc dans la recherche de l\'inséreur.', 'blocs-creator' ); ?></span>
	</p>

</div>
