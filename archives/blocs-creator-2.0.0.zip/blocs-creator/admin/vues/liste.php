<?php
/**
 * L'écran « Tous les blocs ».
 *
 * @package BlocsCreator
 *
 * @var BC_Liste_Table $table Le tableau, déjà préparé.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap bc-wrap">

	<h1 class="wp-heading-inline"><?php esc_html_e( 'Blocs Creator', 'blocs-creator' ); ?></h1>

	<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . BC_Definition::TYPE ) ); ?>" class="page-title-action">
		<?php esc_html_e( 'Ajouter un bloc', 'blocs-creator' ); ?>
	</a>

	<hr class="wp-header-end">

	<p class="bc-chapo">
		<?php
		esc_html_e(
			'Tous les blocs de ce site, qu\'ils aient été déclarés ici ou écrits à la main dans un fichier. Les blocs générés se modifient d\'un clic ; les blocs codés se modifient dans leur dossier.',
			'blocs-creator'
		);
		?>
	</p>

	<?php $table->views(); ?>

	<form method="get">
		<input type="hidden" name="page" value="<?php echo esc_attr( BC_Admin::PAGE ); ?>">
		<?php if ( isset( $_GET['filtre'] ) ) : ?>
			<input type="hidden" name="filtre" value="<?php echo esc_attr( sanitize_key( wp_unslash( $_GET['filtre'] ) ) ); ?>">
		<?php endif; ?>
		<?php $table->search_box( __( 'Rechercher un bloc', 'blocs-creator' ), 'bc-recherche' ); ?>
		<?php $table->display(); ?>
	</form>

</div>
