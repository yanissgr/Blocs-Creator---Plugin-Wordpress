=== Blocs Creator ===
Contributors: yanissinger
Tags: blocks, gutenberg, custom blocks, fields, acf
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 3.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Créez vos blocs Gutenberg en déclarant leurs champs, puis dessinez-les dans un simple fichier PHP de votre thème.

== Description ==

Blocs Creator sépare deux choses que la plupart des outils mélangent.

**Ce que le bloc contient** se déclare dans le back-office : un nom, des champs,
un type par champ. Aucune ligne de code.

**Ce à quoi le bloc ressemble** s'écrit dans un fichier PHP de votre thème. Le
plugin l'appelle avec les valeurs saisies, et se retire. Pas de constructeur
visuel qui génère du balisage que vous devrez déjouer ensuite : votre HTML
reste le vôtre.

= Ce que vous obtenez =

* Un écran qui liste **tous** les blocs du site — ceux déclarés ici comme ceux
  écrits à la main dans un fichier. Avec, pour chacun, son identifiant, ses
  champs, son gabarit et le nombre de pages qui s'en servent.
* Vingt-deux types de champs, du texte simple au répéteur, en passant par les
  images, les liens, les publications et les blocs imbriqués.
* Un fichier de rendu créé pour vous à la publication du bloc, avec un point de
  départ pour chaque champ déclaré — et jamais réécrit ensuite.
* Un aperçu fidèle dans l'éditeur : le bloc s'affiche par son rendu serveur,
  exactement le code qui tournera sur le site. Une bascule dans la barre
  d'outils passe au formulaire pour saisir.
* Un import/export JSON, pour emporter vos blocs d'un site à l'autre.
* **Reprendre la main** sur un bloc écrit à la main : sa déclaration devient une
  définition modifiable, son fichier de rendu s'installe dans votre thème, et
  son identifiant ne bouge pas. L'opération se défait.
* **Le tri de l'inséreur** : une case à cocher par bloc — ceux de WordPress,
  ceux des autres extensions — pour que le « + » ne propose que ce qui sert.
* **Les apparitions** : quinze gestes d'entrée au défilement, réglables bloc par
  bloc, sur n'importe quel bloc.

= Les types de champs =

Texte, texte long, texte enrichi, nombre, oui/non, liste déroulante, groupe de
boutons, cases à cocher, niveau de titre, couleur, icône, image, galerie,
fichier, lien, publication, publications, terme, groupe, répéteur, blocs
imbriqués, note.

= Écrire un gabarit =

Un fichier, une quinzaine de fonctions :

`
<section <?php echo bc_attributs( 'temoignages' ); ?>>

    <?php printf( '<h%1$d>%2$s</h%1$d>', bc_niveau( 'niveau' ), esc_html( bc_champ( 'titre' ) ) ); ?>

    <?php foreach ( bc_boucle( 'lignes' ) as $ligne ) : ?>
        <blockquote><?php echo wp_kses_post( $ligne['citation'] ); ?></blockquote>
        <cite><?php echo esc_html( $ligne['auteur'] ); ?></cite>
    <?php endforeach; ?>

    <?php if ( bc_lien_rempli( 'cta' ) ) : ?>
        <a <?php echo bc_lien_attrs( 'cta' ); ?>><?php echo esc_html( bc_lien_titre( 'cta' ) ); ?></a>
    <?php endif; ?>

</section>
`

La liste complète des fonctions est dans le menu **Blocs Creator → Écrire un
gabarit**, avec ce que rend chaque type de champ.

= Les blocs déjà codés =

Si vous avez déjà des blocs écrits à la main, Blocs Creator les découvre et les
enregistre : posez un dossier portant un `block.json` dans `blocs/` de votre
thème, dans `wp-content/blocs-creator/blocs/`, ou dans un pack du plugin. Ils
apparaissent dans la même liste que les autres, marqués « Codés ».

Et vous pouvez les **reprendre en main**. L'action traduit le `block.json` en
définition — ses attributs deviennent des champs —, recopie son `rendu.php`
dans votre thème comme gabarit, et garde son identifiant, ses feuilles de style
et ses variantes. Le bloc se modifie alors comme si vous l'aviez créé ici. Un
attribut qu'aucun type de champ ne sait porter est conservé tel quel plutôt
qu'abandonné, et l'écran vous le dit avant de confirmer. « Rendre au code »
défait tout : le dossier reprend la main, et il n'a jamais été touché.

= Les blocs disponibles =

**Réglages → Blocs disponibles** liste tous les blocs enregistrés, groupés par
provenance, avec une case à cocher. Décocher un bloc le retire de l'inséreur —
et de lui seul : les pages qui le portent déjà continuent de s'afficher et de
se modifier.

Deux familles résistent : vos propres blocs, et les blocs qui n'existent qu'à
l'intérieur d'un autre. La liste enregistrée est celle de ce que vous retirez,
jamais de ce que vous gardez : un bloc qui arrive avec une nouvelle extension
est donc disponible d'emblée.

= Les apparitions =

Chaque bloc gagne un panneau « Apparition » dans la colonne de droite : un
geste d'entrée parmi quinze, une durée, un retard. La classe est posée au
rendu, pas dans le contenu enregistré — un bloc statique garde donc exactement
le balisage qu'il avait, et retirer le plugin ne laisse rien derrière.

Rien ne s'anime pour qui a demandé moins d'animations dans les réglages de son
appareil, et rien n'est jamais caché si le JavaScript ne se charge pas.

== Installation ==

1. Déposez le dossier `blocs-creator` dans `wp-content/plugins/`.
2. Activez le plugin.
3. Ouvrez **Blocs Creator** dans le menu, puis **Ajouter un bloc**.

Un dossier `packs/` peut contenir des blocs livrés avec le plugin. Sur une
installation neuve, supprimez ce dossier : le plugin n'en saura rien.

== Frequently Asked Questions ==

= Où est le fichier de rendu de mon bloc ? =

Dans `wp-content/themes/<votre-thème>/blocs/<identifiant>.php`. Le chemin exact
est écrit dans la colonne de droite de l'écran du bloc, et dans la liste. Le
dossier se change dans les réglages.

= Le plugin va-t-il écraser mon fichier ? =

Jamais. Il le crée s'il n'existe pas, et n'y retouche plus — même si vous
ajoutez ou supprimez des champs.

= Puis-je charger une feuille de style avec un bloc ? =

Oui. Posez un `<identifiant>.css` à côté du gabarit : il est chargé
automatiquement, et seulement sur les pages qui portent le bloc.

= Que se passe-t-il si je renomme un bloc déjà utilisé ? =

Les pages qui s'en servent ne le reconnaîtront plus. L'écran vous avertit du
nombre de pages concernées avant que vous ne changiez quoi que ce soit.

= Et si je désinstalle le plugin ? =

Par défaut, rien n'est supprimé : vos définitions restent en base et vos
gabarits dans le thème. Une case dans les réglages permet de tout effacer à la
désinstallation, si c'est ce que vous voulez.

== Screenshots ==

1. Tous les blocs du site, générés et codés, dans une seule liste.
2. Le constructeur de champs.
3. Un bloc généré dans l'éditeur : son rendu serveur, et ses champs.
4. L'aide à l'écriture d'un gabarit.

== Changelog ==

= 3.0.0 =
* Reprise en main des blocs codés : un bloc écrit à la main devient une
  définition modifiable, sans changer d'identifiant ni d'aspect. Réversible.
* Écran « Blocs disponibles » : cocher ou décocher les blocs de WordPress et
  des autres extensions pour ne garder dans l'inséreur que ce qui sert.
* Apparitions au défilement : quinze gestes d'entrée, réglables bloc par bloc,
  sur n'importe quel bloc.
* Une seule catégorie dans l'inséreur : celle que vous choisissez parmi les
  sections existantes. Deux sections de même nom ne sont plus créées, et les
  blocs déjà rangés dans l'ancienne déménagent à la montée de version.
* Les clés de champs gardent leur casse : `imageId` reste `imageId`.

= 2.0.0 =
* Création de blocs par déclaration de champs, sans code.
* Écran unique listant les blocs générés et les blocs codés.
* Vingt-deux types de champs, dont le répéteur et les blocs imbriqués.
* Génération du fichier de rendu, avec un exemple par champ.
* Aperçu par rendu serveur dans l'éditeur.
* Import et export JSON.
* Découverte des blocs codés dans le thème, dans wp-content et dans les packs.
