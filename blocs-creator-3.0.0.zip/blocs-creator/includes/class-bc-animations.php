<?php
/**
 * Les apparitions : faire entrer un bloc quand il arrive à l'écran.
 *
 * L'option est posée sur TOUS les blocs, pas seulement sur ceux du plugin :
 * une page mélange des blocs créés ici, des blocs de WordPress et des blocs
 * d'autres extensions, et une page dont la moitié des éléments apparaissent
 * est plus décousue qu'une page qui n'anime rien.
 *
 * Trois choix de fond :
 *
 *   1. LA CLASSE EST POSÉE AU RENDU, pas dans le balisage enregistré. Un bloc
 *      statique — un paragraphe, une image — garde donc exactement le HTML
 *      qu'il avait : changer une animation ne rend jamais un contenu
 *      « inattendu », et retirer le plugin ne laisse aucune classe orpheline.
 *   2. RIEN NE SE CACHE SANS JAVASCRIPT. Le CSS ne masque que sous une classe
 *      posée par un script d'en-tête, lui-même muet quand l'appareil demande
 *      moins d'animations. Sans JavaScript, la page s'affiche entière.
 *   3. L'ÉDITEUR NE JOUE RIEN. On y règle l'apparition, on ne la subit pas à
 *      chaque frappe.
 *
 * @package BlocsCreator
 */

defined( 'ABSPATH' ) || exit;

/**
 * Réglage et rendu des apparitions.
 */
class BC_Animations {

	/**
	 * Attribut qui porte la variante.
	 */
	const ATTRIBUT = 'bcAnim';

	/**
	 * Blocs auxquels l'option n'est pas proposée.
	 *
	 * Ceux qui n'ont pas de balise à eux, ceux qui n'existent que dans
	 * l'éditeur, et ceux dont l'enveloppe appartient à leur parent.
	 *
	 * @var array<int, string>
	 */
	const EXCLUS = array(
		'core/freeform',
		'core/html',
		'core/shortcode',
		'core/missing',
		'core/block',
		'core/pattern',
		'core/template-part',
		'core/post-content',
		'core/list-item',
		'core/navigation-link',
		'core/navigation-submenu',
		'core/page-list-item',
		'core/nextpage',
		'core/more',
		'core/legacy-widget',
		'core/widget-group',
	);

	/**
	 * Branche les hooks.
	 */
	public static function demarrer() {
		/*
		 * L'option est lue à la main, sans passer par BC_Reglages : ses
		 * valeurs par défaut appellent __(), et nous sommes ici bien avant
		 * `init`. C'est le prix à payer pour que le filtre soit en place
		 * avant que WordPress n'enregistre ses propres blocs.
		 */
		$brut = (array) get_option( BC_Reglages::OPTION, array() );

		if ( array_key_exists( 'animations', $brut ) && empty( $brut['animations'] ) ) {
			return;
		}

		add_filter( 'register_block_type_args', array( __CLASS__, 'attributs' ), 20, 2 );
		add_filter( 'render_block', array( __CLASS__, 'rendre' ), 20, 2 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets_site' ) );
		add_action( 'wp_head', array( __CLASS__, 'amorce' ), 1 );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'assets_editeur' ) );
	}

	/* ------------------------------------------------------------------ *
	 * Le catalogue
	 * ------------------------------------------------------------------ */

	/**
	 * Retourne les variantes d'apparition.
	 *
	 * Quinze gestes, rangés du plus discret au plus appuyé. Chacun est décrit
	 * dans assets/css/animations.css, et nulle part ailleurs : ajouter une
	 * variante, c'est ajouter une entrée ici et une règle là-bas.
	 *
	 * @return array<string, string> Libellé, par identifiant.
	 */
	public static function variantes() {
		$variantes = array(
			'fondu'        => __( 'Fondu', 'blocs-creator' ),
			'haut'         => __( 'Monte', 'blocs-creator' ),
			'bas'          => __( 'Descend', 'blocs-creator' ),
			'gauche'       => __( 'Vient de la gauche', 'blocs-creator' ),
			'droite'       => __( 'Vient de la droite', 'blocs-creator' ),
			'zoom'         => __( 'Grandit', 'blocs-creator' ),
			'reduction'    => __( 'Se pose', 'blocs-creator' ),
			'pastille'     => __( 'Pastille', 'blocs-creator' ),
			'ressort'      => __( 'Ressort', 'blocs-creator' ),
			'bascule'      => __( 'Bascule', 'blocs-creator' ),
			'tourne'       => __( 'Tourne', 'blocs-creator' ),
			'pivot'        => __( 'Pivote', 'blocs-creator' ),
			'rideau'       => __( 'Se dévoile du bas', 'blocs-creator' ),
			'rideau-cote'  => __( 'Se dévoile de la gauche', 'blocs-creator' ),
			'nettete'      => __( 'Se précise', 'blocs-creator' ),
		);

		/**
		 * Filtre les variantes d'apparition.
		 *
		 * Un thème qui en ajoute une doit aussi écrire sa règle CSS, sur le
		 * sélecteur `[data-bc-anim="<identifiant>"]`.
		 *
		 * @param array $variantes Libellé, par identifiant.
		 */
		return apply_filters( 'blocs_creator_variantes_animation', $variantes );
	}

	/**
	 * L'option est-elle proposée à ce bloc ?
	 *
	 * @param string $nom Nom complet du bloc.
	 * @return bool
	 */
	public static function concerne( $nom ) {
		$nom = (string) $nom;

		if ( '' === $nom || in_array( $nom, self::EXCLUS, true ) ) {
			return false;
		}

		if ( 'crees' === blocs_creator()->reglages->get( 'animations_portee' ) ) {
			$definition = blocs_creator()->registre->definition( $nom );

			if ( null === $definition ) {
				return false;
			}
		}

		/**
		 * Filtre l'accès d'un bloc au réglage d'apparition.
		 *
		 * @param bool   $concerne Le bloc est-il concerné.
		 * @param string $nom      Nom complet du bloc.
		 */
		return (bool) apply_filters( 'blocs_creator_animation_concerne', true, $nom );
	}

	/* ------------------------------------------------------------------ *
	 * Enregistrement
	 * ------------------------------------------------------------------ */

	/**
	 * Ajoute les attributs d'apparition à un bloc.
	 *
	 * Ils sont déclarés côté serveur pour que le rendu les reçoive, et côté
	 * éditeur par le même script qui pose le panneau : un attribut déclaré
	 * d'un seul côté serait perdu à l'enregistrement.
	 *
	 * @param array  $args Arguments d'enregistrement.
	 * @param string $nom  Nom du bloc.
	 * @return array
	 */
	public static function attributs( $args, $nom ) {
		if ( ! self::concerne( $nom ) ) {
			return $args;
		}

		$args['attributes'] = (array) ( $args['attributes'] ?? array() );

		$args['attributes'][ self::ATTRIBUT ]           = array(
			'type'    => 'string',
			'default' => '',
		);
		$args['attributes'][ self::ATTRIBUT . 'Duree' ] = array(
			'type'    => 'number',
			'default' => 0,
		);
		$args['attributes'][ self::ATTRIBUT . 'Delai' ] = array(
			'type'    => 'number',
			'default' => 0,
		);

		return $args;
	}

	/* ------------------------------------------------------------------ *
	 * Rendu
	 * ------------------------------------------------------------------ */

	/**
	 * Pose la classe et les données d'apparition sur le bloc rendu.
	 *
	 * On écrit dans le HTML déjà produit plutôt que dans le `save` du bloc :
	 * c'est ce qui permet d'animer un bloc de WordPress ou d'une autre
	 * extension sans toucher à son code, et sans rendre « inattendu » le
	 * contenu déjà enregistré dans les pages.
	 *
	 * @param string $html  HTML du bloc.
	 * @param array  $bloc  Bloc analysé.
	 * @return string
	 */
	public static function rendre( $html, $bloc ) {
		$variante = (string) ( $bloc['attrs'][ self::ATTRIBUT ] ?? '' );

		if ( '' === $variante || '' === trim( $html ) ) {
			return $html;
		}

		if ( ! array_key_exists( $variante, self::variantes() ) ) {
			return $html;
		}

		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return $html;
		}

		$processeur = new WP_HTML_Tag_Processor( $html );

		if ( ! $processeur->next_tag() ) {
			return $html;
		}

		$processeur->add_class( 'bc-anim' );
		$processeur->set_attribute( 'data-bc-anim', $variante );

		$style = (string) $processeur->get_attribute( 'style' );
		$ajout = '';

		$duree = (float) ( $bloc['attrs'][ self::ATTRIBUT . 'Duree' ] ?? 0 );
		$delai = (float) ( $bloc['attrs'][ self::ATTRIBUT . 'Delai' ] ?? 0 );

		if ( $duree > 0 ) {
			$ajout .= sprintf( '--bc-anim-duree:%dms;', min( 4000, max( 100, (int) $duree ) ) );
		}

		if ( $delai > 0 ) {
			$ajout .= sprintf( '--bc-anim-delai:%dms;', min( 4000, max( 0, (int) $delai ) ) );
		}

		if ( '' !== $ajout ) {
			$processeur->set_attribute( 'style', rtrim( $style, '; ' ) . ( '' !== trim( $style ) ? ';' : '' ) . $ajout );
		}

		return $processeur->get_updated_html();
	}

	/* ------------------------------------------------------------------ *
	 * Assets
	 * ------------------------------------------------------------------ */

	/**
	 * Le script d'en-tête : il décide si l'on cache quoi que ce soit.
	 *
	 * Il doit s'exécuter avant le premier rendu de la page, sans quoi les
	 * blocs s'afficheraient une fraction de seconde avant de disparaître pour
	 * réapparaître. C'est la seule raison d'un script en ligne ici.
	 *
	 * Le filet de sécurité est aussi important que l'animation : si le script
	 * principal ne se charge pas — erreur, réseau coupé, navigateur exotique —
	 * la page se démasque toute seule au bout de quatre secondes. Une page
	 * blanche est un prix trop élevé pour une apparition.
	 */
	public static function amorce() {
		if ( is_admin() ) {
			return;
		}

		echo '<script id="bc-anim-amorce">' .
			'(function(d,w){try{if(w.matchMedia&&w.matchMedia("(prefers-reduced-motion: reduce)").matches){return;}}catch(e){return;}' .
			'var r=d.documentElement;r.classList.add("bc-anim-prete");' .
			'w.bcAnimFilet=w.setTimeout(function(){r.classList.remove("bc-anim-prete");},4000);}(document,window));' .
			'</script>' . "\n";
	}

	/**
	 * Met en file la feuille et le script du site.
	 */
	public static function assets_site() {
		if ( is_admin() ) {
			return;
		}

		wp_enqueue_style(
			'blocs-creator-animations',
			BLOCS_CREATOR_URL . 'assets/css/animations.css',
			array(),
			self::version( 'assets/css/animations.css' )
		);

		wp_enqueue_script(
			'blocs-creator-animations',
			BLOCS_CREATOR_URL . 'assets/js/animations.js',
			array(),
			self::version( 'assets/js/animations.js' ),
			true
		);
	}

	/**
	 * Met en file le panneau de l'éditeur.
	 */
	public static function assets_editeur() {
		wp_enqueue_script(
			'blocs-creator-animations-editeur',
			BLOCS_CREATOR_URL . 'assets/js/animations-editeur.js',
			array( 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-compose', 'wp-element', 'wp-hooks', 'wp-i18n' ),
			self::version( 'assets/js/animations-editeur.js' ),
			true
		);

		wp_set_script_translations( 'blocs-creator-animations-editeur', 'blocs-creator', BLOCS_CREATOR_DIR . 'languages' );

		$variantes = array();

		foreach ( self::variantes() as $valeur => $libelle ) {
			$variantes[] = array(
				'value' => $valeur,
				'label' => $libelle,
			);
		}

		wp_add_inline_script(
			'blocs-creator-animations-editeur',
			'window.blocsCreatorAnimations = ' . wp_json_encode(
				array(
					'attribut'  => self::ATTRIBUT,
					'variantes' => $variantes,
					'exclus'    => self::EXCLUS,
					'crees'     => 'crees' === blocs_creator()->reglages->get( 'animations_portee' )
						? array_keys( blocs_creator()->registre->generes() )
						: null,
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Retourne une version d'asset basée sur la date du fichier.
	 *
	 * @param string $chemin Chemin relatif à la racine du plugin.
	 * @return string
	 */
	private static function version( $chemin ) {
		$fichier = BLOCS_CREATOR_DIR . ltrim( $chemin, '/' );

		return file_exists( $fichier ) ? (string) filemtime( $fichier ) : BLOCS_CREATOR_VERSION;
	}
}
