# Blocs Creator

Créez vos blocs Gutenberg en déclarant leurs champs, puis dessinez-les dans un
fichier PHP de votre thème.

Auteur : **Yanis Singer** — Licence GPL-2.0-or-later — WordPress 6.5+, PHP 8.0+

---

## Le principe

Le plugin tient une frontière, et rien d'autre :

| Ce que le bloc **contient** | Ce à quoi il **ressemble** |
|---|---|
| Se déclare dans le back-office : un nom, des champs, un type par champ. | S'écrit dans un fichier PHP du thème. |
| Devient les attributs Gutenberg du bloc et son formulaire dans l'éditeur. | Reçoit les valeurs saisies, et produit le balisage que vous voulez. |
| Vit en base, s'exporte en JSON. | Vit dans le thème, se versionne avec lui. |

Aucun constructeur visuel ne génère de HTML à votre place. C'est délibéré : le
balisage d'un site est la partie qu'on retouche le plus, et la moins
automatisable.

---

## Démarrer

1. **Blocs Creator → Ajouter un bloc.** Donnez-lui un nom.
2. **Ajoutez des champs.** Un libellé, un type. La clé se déduit du libellé.
3. **Publiez.** Le fichier de rendu est créé dans
   `wp-content/themes/<thème>/blocs/<identifiant>.php`, avec un point de départ
   pour chaque champ.
4. **Ouvrez ce fichier** et écrivez votre balisage. Le plugin n'y retouchera
   jamais.

---

## Écrire un gabarit

Le gabarit reçoit quatre variables :

```php
/**
 * @var array    $attributes Les valeurs brutes, telles qu'enregistrées.
 * @var string   $content    Les blocs imbriqués, déjà rendus.
 * @var WP_Block $block      L'instance du bloc.
 * @var array    $champs     Les valeurs prêtes à l'emploi, par clé.
 */
```

Et une quinzaine de fonctions :

| Fonction | Ce qu'elle rend |
|---|---|
| `bc_champ( $cle, $defaut = null )` | La valeur du champ, prête à l'emploi. |
| `bc_brut( $cle, $defaut = null )` | La valeur telle qu'enregistrée (pour une image, son identifiant). |
| `bc_a_champ( $cle )` | Le champ est-il rempli ? |
| `bc_attributs( $classes, $extra )` | Les attributs de la balise racine. **Indispensable.** |
| `bc_contenu()` | Les blocs imbriqués, rendus. |
| `bc_image( $cle, $attrs, $taille )` | La balise `<img>`, ou une surface d'attente. |
| `bc_url( $cle, $taille )` | L'URL d'une image ou d'un fichier. |
| `bc_lien_rempli( $cle )` | Le lien a-t-il une destination ? |
| `bc_lien_attrs( $cle )` | `href`, `target` et `rel`, déjà échappés. |
| `bc_lien_titre( $cle, $defaut )` | Le libellé du lien. |
| `bc_lien_url( $cle )` | L'URL seule. |
| `bc_boucle( $cle )` | Les lignes d'un répéteur — toujours un tableau. |
| `bc_compte( $cle )` | Le nombre de lignes d'un répéteur. |
| `bc_couleur( $cle, $defaut )` | Une couleur utilisable en CSS. |
| `bc_niveau( $cle, $minimum = 2 )` | Un niveau de titre borné. |
| `bc_rappel( $message )` | Un rappel visible des seuls rédacteurs. |
| `bc_bloc()` | La définition du bloc en cours. |

Ce qui sort échappé sort échappé — `bc_image()`, `bc_lien_attrs()` et
`bc_attributs()` rendent du HTML prêt à poser. Les valeurs de texte sortent
brutes : le gabarit choisit son échappement, parce que lui seul sait s'il écrit
dans un attribut, dans une balise ou dans une URL.

### Exemple

```php
<?php
defined( 'ABSPATH' ) || exit;
?>
<section <?php echo bc_attributs( 'temoignages' ); ?>>

    <?php if ( bc_a_champ( 'titre' ) ) : ?>
        <?php printf(
            '<h%1$d class="temoignages__titre">%2$s</h%1$d>',
            bc_niveau( 'niveau' ),
            esc_html( bc_champ( 'titre' ) )
        ); ?>
    <?php endif; ?>

    <ul class="temoignages__liste">
        <?php foreach ( bc_boucle( 'lignes' ) as $ligne ) : ?>
            <li>
                <blockquote><?php echo wp_kses_post( $ligne['citation'] ); ?></blockquote>
                <cite><?php echo esc_html( $ligne['auteur'] ); ?></cite>
            </li>
        <?php endforeach; ?>
    </ul>

    <?php if ( bc_lien_rempli( 'cta' ) ) : ?>
        <a class="temoignages__lien" <?php echo bc_lien_attrs( 'cta' ); ?>>
            <?php echo esc_html( bc_lien_titre( 'cta' ) ); ?>
        </a>
    <?php endif; ?>

</section>
```

### Une feuille de style par bloc

Posez un `<identifiant>.css` à côté du gabarit : il est chargé automatiquement,
et seulement sur les pages qui portent le bloc.

---

## Les types de champs

| Famille | Types |
|---|---|
| **Texte** | texte, texte long, texte enrichi, nombre |
| **Choix** | oui/non, liste déroulante, groupe de boutons, cases à cocher, niveau de titre, couleur, icône |
| **Médias** | image, galerie, fichier |
| **Liens** | lien, publication, publications, terme |
| **Structure** | groupe, répéteur, blocs imbriqués, note |

Ce que `bc_champ()` rend, par type :

| Type | Rend |
|---|---|
| texte, texte long, texte enrichi | `string` |
| nombre | `float` |
| oui/non | `bool` |
| liste, boutons, couleur, icône | `string` |
| cases à cocher | `string[]` |
| niveau de titre | `int` (1-6) |
| image, fichier | `array` (`id`, `url`, `alt`, `largeur`, `hauteur`, `legende`…) ou `null` |
| galerie | `array[]` |
| lien | `array` (`url`, `titre`, `nouvelOnglet`, `attrs`, `rempli`) |
| publication | `WP_Post` ou `null` |
| publications | `WP_Post[]` |
| terme | `WP_Term` ou `WP_Term[]` |
| groupe | `array` |
| répéteur | `array[]` — une entrée par ligne |
| blocs imbriqués | rien : passe par `$content` / `bc_contenu()` |

**La structure ne s'imbrique qu'un cran.** Un répéteur contient des champs
simples, jamais un autre répéteur. C'est arbitraire, et c'est ce qui garde
l'interface lisible et les gabarits écrivables.

---

## Les blocs codés

Blocs Creator découvre et enregistre tout dossier portant un `block.json`,
dans l'ordre :

1. `blocs-creator/packs/*/blocs/*/` — les packs livrés avec le plugin ;
2. `<thème enfant>/blocs/*/` ;
3. `<thème parent>/blocs/*/` ;
4. `wp-content/blocs-creator/blocs/*/`.

Ces blocs apparaissent dans la même liste que les blocs générés, marqués
« Codés ». Le plugin ne fait que les enregistrer : leur rendu et leur éditeur
restent leur affaire.

### Les packs

Un pack est un dossier de `packs/` portant un `pack.php`. Ce fichier est inclus
avant `init`, peut charger ce qu'il veut, et retourne ses métadonnées :

```php
return array(
    'nom'         => 'Mon pack',
    'description' => "Ce qu'il apporte.",
    'auteur'      => 'Vous',
    'version'     => '1.0.0',
);
```

Supprimer le dossier suffit à retirer le pack. Aucune trace en base.

---

## Où le gabarit est cherché

Du plus spécifique au plus général :

1. `<thème enfant>/blocs/<espace>-<identifiant>.php`
2. `<thème enfant>/blocs/<identifiant>.php`
3. `<thème parent>/blocs/…`
4. `wp-content/blocs-creator/gabarits/<identifiant>.php`
5. le rendu de secours du plugin, qui affiche les champs bruts.

Le point 4 survit au changement de thème. Le point 5 fait qu'un bloc tout juste
créé montre quelque chose plutôt qu'un vide.

---

## Reprendre la main sur un bloc codé

Un bloc écrit à la main est un dossier : un `block.json`, un `rendu.php`, du
JavaScript. On ne peut ni lui ajouter un champ ni lui changer son icône sans
ouvrir un éditeur de code.

**Tous les blocs → Reprendre la main** traduit ce dossier en définition et
recopie son `rendu.php` dans le thème comme gabarit. Trois promesses tiennent
l'opération :

1. **Le nom ne bouge pas.** `salama/banniere` reste `salama/banniere` : les
   pages qui le portent ne voient pas la différence.
2. **Le dessin ne bouge pas.** Le `rendu.php` est recopié tel quel — il lit
   `$attributes`, que le plugin lui passe sous le même nom — et les feuilles de
   style que le `block.json` déclarait restent attachées.
3. **Rien ne se perd.** Un attribut qu'aucun type de champ ne sait porter sans
   en changer la forme — un point focal, une structure à soi — est conservé tel
   quel. Les variantes, les styles de bloc et l'exemple d'inséreur aussi.

L'écran de confirmation montre la traduction avant de la faire : quel attribut
devient quel type de champ, ce qui est conservé, ce qui change.

**Rendre au code** défait tout : la définition est supprimée, le dossier reprend
la main. Le dossier n'a jamais été touché ; le gabarit recopié reste dans le
thème, où il ne gêne pas.

> Ce que la reprise remplace, c'est l'éditeur sur mesure du bloc : un sélecteur
> maison, une barre d'outils dessinée pour lui. Le bloc se règle ensuite par le
> formulaire commun, et son aperçu passe par le rendu serveur.

---

## Les blocs disponibles

**Réglages → Blocs disponibles** liste tous les blocs enregistrés, groupés par
provenance — WordPress, vos blocs, chaque extension — avec une case à cocher.

Deux règles tiennent l'écran :

- **On range en négatif.** C'est la liste de ce qu'on retire qui est
  enregistrée. Un bloc qui arrive demain avec une nouvelle extension est donc
  disponible d'emblée.
- **On ne se coupe pas un bras.** Vos propres blocs et les blocs qui n'existent
  qu'à l'intérieur d'un autre ne se décochent pas.

Décocher un bloc ne touche à aucune page : les blocs déjà posés continuent de
s'afficher et de se modifier. C'est l'inséreur qui ne les propose plus.

---

## Les apparitions

Chaque bloc gagne un panneau « Apparition » : un geste d'entrée parmi quinze
(fondu, monte, descend, gauche, droite, grandit, se pose, pastille, ressort,
bascule, tourne, pivote, se dévoile du bas, se dévoile de la gauche, se
précise), une durée, un retard au départ.

Trois choix de fond :

1. **La classe est posée au rendu**, pas dans le balisage enregistré. Un bloc
   statique garde donc exactement le HTML qu'il avait : changer une animation ne
   rend jamais un contenu « inattendu », et retirer le plugin ne laisse aucune
   classe orpheline.
2. **Rien ne se cache sans JavaScript.** Le CSS ne masque que sous une classe
   posée par un script d'en-tête, muet quand l'appareil demande moins
   d'animations. Un filet de sécurité démasque la page si le script principal
   ne se charge pas.
3. **L'éditeur ne joue rien.** On y règle l'apparition, on ne la subit pas à
   chaque frappe.

Un thème peut ajouter un geste : le filtre `blocs_creator_variantes_animation`
le déclare, une règle CSS sur `[data-bc-anim="…"]` le dessine.

---

## Réglages

| Réglage | Par défaut |
|---|---|
| Espace de noms des nouveaux blocs | déduit du nom du site |
| Catégorie dans l'inséreur | « Mes blocs », choisie parmi les sections existantes |
| Dossier des gabarits | `blocs`, relatif au thème actif |
| Créer le gabarit à la publication | oui |
| Supprimer les données à la désinstallation | non |
| Blocs retirés de l'inséreur | aucun |
| Apparitions au défilement | proposées, sur tous les blocs |

> **Une seule catégorie.** Le plugin n'ajoute sa section à l'inséreur que si
> personne ne l'a déjà déclarée — ni sous ce slug, ni sous ce titre. Deux
> sections du même nom ne sont pas deux rangements : c'est le même, coupé en
> deux.

---

## Import et export

**Blocs Creator → Outils.** L'export produit un JSON qui ne contient que les
définitions — les gabarits sont des fichiers de thème, qu'on copie comme le
reste du thème. Le JSON importé repasse entièrement par la normalisation : un
fichier trafiqué ne peut déclarer que des champs du catalogue.

---

## Crochets

| Crochet | Ce qu'il permet |
|---|---|
| `blocs_creator_champs` | Les valeurs, juste avant qu'elles n'arrivent au gabarit. |
| `blocs_creator_args_bloc` | Les arguments passés à `register_block_type()`. |
| `blocs_creator_candidats_gabarit` | Les chemins où le gabarit est cherché. |
| `blocs_creator_code_depart` | Le code du fichier de rendu généré. |
| `blocs_creator_catalogue_champs` | Ajouter un type de champ. |
| `blocs_creator_emplacements_blocs` | Les dossiers où les blocs codés sont découverts. |
| `blocs_creator_donnees_editeur` | Les données passées à l'éditeur. |
| `blocs_creator_charger_pack` | Désactiver un pack sans supprimer son dossier. |
| `blocs_creator_definition_enregistree` | Après l'enregistrement d'une définition. |
| `blocs_creator_blocs_proteges` | Les blocs qu'on refuse de retirer de l'inséreur. |
| `blocs_creator_variantes_animation` | Ajouter un geste d'apparition. |
| `blocs_creator_animation_concerne` | L'accès d'un bloc au réglage d'apparition. |

---

## Organisation du code

```
blocs-creator.php          En-tête, constantes, point d'entrée
includes/
  class-bc-plugin.php      Bootstrap : chargement, packs, activation
  class-bc-champs.php      Le catalogue des types de champs
  class-bc-definition.php  Une définition de bloc : lecture, nettoyage, écriture
  class-bc-registre.php    Découverte et enregistrement de tous les blocs
  class-bc-rendu.php       Appel du gabarit, pile de contexte
  class-bc-gabarits.php    Résolution des chemins, génération du fichier
  class-bc-usage.php       Où un bloc est-il utilisé
  class-bc-adoption.php    Reprendre en main un bloc codé, et le rendre
  class-bc-disponibilite.php  Ce que l'inséreur a le droit de proposer
  class-bc-animations.php  Les apparitions : réglage, rendu, assets
  class-bc-reglages.php    Les réglages
  class-bc-rest.php        Deux routes pour l'éditeur
  fonctions.php            L'API des gabarits (bc_*)
admin/
  class-bc-admin.php             Menu, écrans, actions
  class-bc-liste-table.php       L'écran « Tous les blocs »
  class-bc-ecran-definition.php  L'écran d'édition d'un bloc
  class-bc-outils.php            Import et export
  js/constructeur.js             Le constructeur de champs
  js/reglages.js                 Onglets et tri de l'écran des réglages
  vues/                          Les gabarits des écrans
assets/
  js/editeur.js            L'éditeur générique des blocs générés
  js/animations.js         Révéler un bloc quand il entre à l'écran
  js/animations-editeur.js Le panneau « Apparition », posé sur tous les blocs
  css/editeur.css          Ce que l'éditeur ajoute autour d'un bloc
  css/blocs.css            Le strict minimum côté site
  css/animations.css       Les quinze gestes d'apparition
gabarits/secours.php       Le rendu d'un bloc sans gabarit
packs/                     Les blocs codés livrés avec le plugin
```

Aucun outil de build : le JavaScript est écrit en natif
(`wp.element.createElement` plutôt que du JSX), pour que le plugin s'installe
partout sans `npm install`.

---

## Ajouter un type de champ

Trois endroits, et pas un de plus :

1. `BC_Champs::catalogue()` — ou le filtre `blocs_creator_catalogue_champs` —
   déclare le type : son attribut Gutenberg, sa valeur par défaut, ses
   réglages.
2. `BC_Champs::assainir_valeur()` et `BC_Champs::preparer()` disent comment il
   se nettoie et ce qu'il rend au gabarit.
3. `assets/js/editeur.js` (fonction `controle`) et `admin/js/constructeur.js`
   (fonction `reglagesDuType`) fournissent ses contrôles.
