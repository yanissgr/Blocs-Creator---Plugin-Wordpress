<?php
/**
 * L'écran des réglages.
 *
 * Trois onglets, un seul formulaire : tout est envoyé d'un coup, quel que soit
 * l'onglet ouvert. C'est ce qui permet de cocher trois blocs ici, de changer
 * une animation là, et de n'appuyer qu'une fois sur « Enregistrer ».
 *
 * @package BlocsCreator
 *
 * @var BC_Reglages $reglages Les réglages.
 */

defined( 'ABSPATH' ) || exit;

$bc_valeurs    = $reglages->tout();
$bc_dossier    = get_stylesheet_directory() . '/' . trim( (string) $bc_valeurs['dossier_gabarits'], '/' );
$bc_option     = BC_Reglages::OPTION;
$bc_categories = BC_Reglages::categories_connues();
$bc_inventaire = BC_Disponibilite::inventaire();
$bc_ecartes    = count( BC_Disponibilite::ecartes() );
?>
<div class="wrap bc-wrap bc-reglages">

	<h1><?php esc_html_e( 'Réglages', 'blocs-creator' ); ?></h1>

	<nav class="nav-tab-wrapper bc-onglets" aria-label="<?php esc_attr_e( 'Sections des réglages', 'blocs-creator' ); ?>">
		<button type="button" class="nav-tab nav-tab-active" data-bc-onglet="general">
			<?php esc_html_e( 'Général', 'blocs-creator' ); ?>
		</button>
		<button type="button" class="nav-tab" data-bc-onglet="disponibilite">
			<?php esc_html_e( 'Blocs disponibles', 'blocs-creator' ); ?>
			<?php if ( $bc_ecartes > 0 ) : ?>
				<span class="bc-pastille"><?php echo esc_html( (string) $bc_ecartes ); ?></span>
			<?php endif; ?>
		</button>
		<button type="button" class="nav-tab" data-bc-onglet="animations">
			<?php esc_html_e( 'Apparitions', 'blocs-creator' ); ?>
		</button>
	</nav>

	<form method="post" action="options.php">
		<?php settings_fields( 'blocs_creator_reglages' ); ?>

		<!-- ---------------------------------------------------------- -->
		<section class="bc-onglet" data-bc-panneau="general">

			<p class="bc-chapo">
				<?php esc_html_e( 'Ces réglages valent pour les blocs à venir. Les blocs déjà créés gardent ce qu\'ils ont : un identifiant de bloc ne change pas sans casser les pages qui s\'en servent.', 'blocs-creator' ); ?>
			</p>

			<table class="form-table" role="presentation">

				<tr>
					<th scope="row">
						<label for="bc-r-espace"><?php esc_html_e( 'Espace de noms', 'blocs-creator' ); ?></label>
					</th>
					<td>
						<input type="text" id="bc-r-espace" class="regular-text"
							name="<?php echo esc_attr( $bc_option ); ?>[espace]"
							value="<?php echo esc_attr( $bc_valeurs['espace'] ); ?>"
							pattern="[a-z0-9-]+">
						<p class="description">
							<?php
							printf(
								/* translators: %s: exemple de nom de bloc. */
								esc_html__( 'Le préfixe des blocs que vous créerez : %s. En minuscules, sans espace.', 'blocs-creator' ),
								'<code>' . esc_html( $bc_valeurs['espace'] ) . '/temoignages</code>'
							);
							?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="bc-r-categorie"><?php esc_html_e( 'Catégorie dans l\'inséreur', 'blocs-creator' ); ?></label>
					</th>
					<td>
						<select id="bc-r-categorie" name="<?php echo esc_attr( $bc_option ); ?>[categorie]" class="regular-text">
							<?php
							$bc_liste = $bc_categories;

							if ( ! isset( $bc_liste[ $bc_valeurs['categorie'] ] ) ) {
								$bc_liste[ $bc_valeurs['categorie'] ] = $bc_valeurs['categorie_titre'];
							}

							foreach ( $bc_liste as $bc_slug => $bc_titre ) :
								?>
								<option value="<?php echo esc_attr( $bc_slug ); ?>"
									data-bc-titre="<?php echo esc_attr( $bc_titre ); ?>"
									<?php selected( $bc_valeurs['categorie'], $bc_slug ); ?>>
									<?php
									printf(
										/* translators: 1: titre de la catégorie, 2: identifiant. */
										esc_html__( '%1$s (%2$s)', 'blocs-creator' ),
										esc_html( $bc_titre ),
										esc_html( $bc_slug )
									);
									?>
								</option>
							<?php endforeach; ?>
						</select>

						<p class="description">
							<?php esc_html_e( 'La section où vos blocs apparaissent quand on clique sur le « + » de l\'éditeur. Choisissez-y une section qui existe déjà — celle d\'un pack, par exemple — plutôt que d\'en créer une du même nom : deux sections identiques dans l\'inséreur, c\'est un rangement coupé en deux.', 'blocs-creator' ); ?>
						</p>

						<p>
							<label for="bc-r-categorie-titre" class="bc-etiquette-champ">
								<?php esc_html_e( 'Ou créez la vôtre :', 'blocs-creator' ); ?>
							</label>
							<input type="text" id="bc-r-categorie-titre" class="regular-text"
								name="<?php echo esc_attr( $bc_option ); ?>[categorie_titre]"
								value="<?php echo esc_attr( $bc_valeurs['categorie_titre'] ); ?>">
						</p>
						<p class="description">
							<?php esc_html_e( 'Ce titre n\'est utilisé que si l\'identifiant choisi au-dessus n\'existe encore nulle part.', 'blocs-creator' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="bc-r-dossier"><?php esc_html_e( 'Dossier des gabarits', 'blocs-creator' ); ?></label>
					</th>
					<td>
						<input type="text" id="bc-r-dossier" class="regular-text"
							name="<?php echo esc_attr( $bc_option ); ?>[dossier_gabarits]"
							value="<?php echo esc_attr( $bc_valeurs['dossier_gabarits'] ); ?>">
						<p class="description">
							<?php esc_html_e( 'Relatif au thème actif. Les fichiers de rendu y sont cherchés, et créés.', 'blocs-creator' ); ?>
						</p>
						<p class="description">
							<code><?php echo esc_html( BC_Gabarits::chemin_court( $bc_dossier ) ); ?></code>
							<?php if ( is_dir( $bc_dossier ) ) : ?>
								<span class="bc-oui dashicons dashicons-yes-alt" aria-hidden="true"></span>
								<?php
								echo is_writable( $bc_dossier )
									? esc_html__( 'existe, accessible en écriture', 'blocs-creator' )
									: esc_html__( 'existe, mais verrouillé en écriture', 'blocs-creator' );
								?>
							<?php else : ?>
								<span class="bc-non dashicons dashicons-marker" aria-hidden="true"></span>
								<?php esc_html_e( 'sera créé au premier gabarit', 'blocs-creator' ); ?>
							<?php endif; ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'À la création d\'un bloc', 'blocs-creator' ); ?></th>
					<td>
						<label>
							<input type="checkbox" value="1"
								name="<?php echo esc_attr( $bc_option ); ?>[creer_gabarit]"
								<?php checked( ! empty( $bc_valeurs['creer_gabarit'] ) ); ?>>
							<?php esc_html_e( 'Créer le fichier de gabarit automatiquement', 'blocs-creator' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Un fichier de départ, avec un exemple de code pour chaque champ déclaré. Il n\'est jamais réécrit ensuite.', 'blocs-creator' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'À la désinstallation', 'blocs-creator' ); ?></th>
					<td>
						<label>
							<input type="checkbox" value="1"
								name="<?php echo esc_attr( $bc_option ); ?>[supprimer_donnees]"
								<?php checked( ! empty( $bc_valeurs['supprimer_donnees'] ) ); ?>>
							<?php esc_html_e( 'Supprimer les définitions de blocs et les réglages', 'blocs-creator' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Décoché, tout reste en base : désinstaller puis réinstaller le plugin retrouve vos blocs. Les fichiers de gabarit du thème ne sont jamais supprimés, dans un cas comme dans l\'autre.', 'blocs-creator' ); ?>
						</p>
					</td>
				</tr>

			</table>
		</section>

		<!-- ---------------------------------------------------------- -->
		<section class="bc-onglet" data-bc-panneau="disponibilite" hidden>

			<p class="bc-chapo">
				<?php esc_html_e( 'Ce que le « + » de l\'éditeur a le droit de proposer. Décocher un bloc ne touche à aucune page : les blocs déjà posés continuent de s\'afficher et de se modifier — ils ne s\'insèrent simplement plus.', 'blocs-creator' ); ?>
			</p>

			<p class="bc-recherche-blocs">
				<label for="bc-filtre-blocs" class="screen-reader-text"><?php esc_html_e( 'Filtrer les blocs', 'blocs-creator' ); ?></label>
				<input type="search" id="bc-filtre-blocs" class="regular-text"
					placeholder="<?php esc_attr_e( 'Filtrer par nom…', 'blocs-creator' ); ?>">
			</p>

			<?php
			/*
			 * La liste de ce que cet écran montrait part en UN champ, pas en
			 * cent trente. Un champ par bloc ferait dépasser `max_input_vars`
			 * sur un site un peu fourni, et le formulaire arriverait tronqué —
			 * c'est-à-dire avec des blocs qu'on croirait réactivés.
			 */
			$bc_connus = array();

			foreach ( $bc_inventaire as $bc_groupe_connu ) {
				foreach ( $bc_groupe_connu['blocs'] as $bc_bloc_connu ) {
					$bc_connus[] = $bc_bloc_connu['nom'];
				}
			}
			?>
			<input type="hidden" name="<?php echo esc_attr( $bc_option ); ?>[blocs_connus]"
				value="<?php echo esc_attr( implode( ',', $bc_connus ) ); ?>">

			<?php foreach ( $bc_inventaire as $bc_espace => $bc_groupe ) : ?>
				<div class="bc-groupe-blocs" data-bc-groupe="<?php echo esc_attr( $bc_espace ); ?>">

					<h2 class="bc-groupe-blocs__titre">
						<?php echo esc_html( $bc_groupe['titre'] ); ?>
						<span class="bc-groupe-blocs__compte"><?php echo esc_html( (string) count( $bc_groupe['blocs'] ) ); ?></span>

						<span class="bc-groupe-blocs__actions">
							<button type="button" class="button-link" data-bc-tout="1"><?php esc_html_e( 'Tout cocher', 'blocs-creator' ); ?></button>
							<button type="button" class="button-link" data-bc-tout="0"><?php esc_html_e( 'Tout décocher', 'blocs-creator' ); ?></button>
						</span>
					</h2>

					<ul class="bc-blocs">
						<?php foreach ( $bc_groupe['blocs'] as $bc_bloc ) : ?>
							<li class="bc-blocs__item<?php echo $bc_bloc['protege'] ? ' est-protege' : ''; ?>"
								data-bc-cherche="<?php echo esc_attr( strtolower( $bc_bloc['titre'] . ' ' . $bc_bloc['nom'] ) ); ?>">

								<label>
									<input type="checkbox"
										name="<?php echo esc_attr( $bc_option ); ?>[blocs_actifs][]"
										value="<?php echo esc_attr( $bc_bloc['nom'] ); ?>"
										<?php checked( ! $bc_bloc['ecarte'] || $bc_bloc['protege'] ); ?>
										<?php disabled( $bc_bloc['protege'] ); ?>>

									<?php if ( $bc_bloc['protege'] ) : ?>
										<input type="hidden" name="<?php echo esc_attr( $bc_option ); ?>[blocs_actifs][]"
											value="<?php echo esc_attr( $bc_bloc['nom'] ); ?>">
									<?php endif; ?>

									<span class="bc-blocs__titre"><?php echo esc_html( $bc_bloc['titre'] ); ?></span>
									<code class="bc-code"><?php echo esc_html( $bc_bloc['nom'] ); ?></code>

									<?php if ( $bc_bloc['usage'] > 0 ) : ?>
										<span class="bc-blocs__usage">
											<?php
											printf(
												esc_html(
													/* translators: %d: nombre de publications. */
													_n( 'posé dans %d publication', 'posé dans %d publications', $bc_bloc['usage'], 'blocs-creator' )
												),
												(int) $bc_bloc['usage']
											);
											?>
										</span>
									<?php endif; ?>

									<?php if ( $bc_bloc['protege'] ) : ?>
										<span class="bc-blocs__protege"><?php esc_html_e( 'ne se retire pas', 'blocs-creator' ); ?></span>
									<?php endif; ?>
								</label>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>

			<p class="description">
				<?php esc_html_e( 'Deux familles ne se décochent pas : vos propres blocs, et les blocs qui n\'existent qu\'à l\'intérieur d\'un autre — une carte dans une grille de cartes. Les retirer laisserait un conteneur qu\'on ne pourrait plus remplir.', 'blocs-creator' ); ?>
			</p>
		</section>

		<!-- ---------------------------------------------------------- -->
		<section class="bc-onglet" data-bc-panneau="animations" hidden>

			<p class="bc-chapo">
				<?php esc_html_e( 'Une animation d\'entrée se règle bloc par bloc, dans la colonne de droite de l\'éditeur, au panneau « Apparition ». Ici, on décide seulement si l\'option existe, et à quels blocs elle est proposée.', 'blocs-creator' ); ?>
			</p>

			<table class="form-table" role="presentation">

				<tr>
					<th scope="row"><?php esc_html_e( 'Apparitions au défilement', 'blocs-creator' ); ?></th>
					<td>
						<label>
							<input type="checkbox" value="1"
								name="<?php echo esc_attr( $bc_option ); ?>[animations]"
								<?php checked( ! empty( $bc_valeurs['animations'] ) ); ?>>
							<?php esc_html_e( 'Proposer une animation d\'entrée sur les blocs', 'blocs-creator' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Le bloc s\'anime quand le visiteur arrive dessus. Rien ne s\'anime pour qui a demandé moins d\'animations dans les réglages de son appareil, et rien n\'est jamais caché si le JavaScript ne se charge pas.', 'blocs-creator' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'À quels blocs', 'blocs-creator' ); ?></th>
					<td>
						<fieldset>
							<label>
								<input type="radio" value="tous"
									name="<?php echo esc_attr( $bc_option ); ?>[animations_portee]"
									<?php checked( 'tous', $bc_valeurs['animations_portee'] ); ?>>
								<?php esc_html_e( 'À tous les blocs — les vôtres, ceux de WordPress, ceux des autres extensions', 'blocs-creator' ); ?>
							</label>
							<br>
							<label>
								<input type="radio" value="crees"
									name="<?php echo esc_attr( $bc_option ); ?>[animations_portee]"
									<?php checked( 'crees', $bc_valeurs['animations_portee'] ); ?>>
								<?php esc_html_e( 'À vos blocs seulement', 'blocs-creator' ); ?>
							</label>
						</fieldset>
						<p class="description">
							<?php esc_html_e( 'Une page dont la moitié des éléments apparaissent est plus décousue qu\'une page qui n\'anime rien : c\'est pourquoi l\'option est offerte partout par défaut.', 'blocs-creator' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Les gestes disponibles', 'blocs-creator' ); ?></th>
					<td>
						<ul class="bc-variantes">
							<?php foreach ( BC_Animations::variantes() as $bc_valeur => $bc_libelle ) : ?>
								<li>
									<span class="bc-variantes__nom"><?php echo esc_html( $bc_libelle ); ?></span>
									<code class="bc-code"><?php echo esc_html( $bc_valeur ); ?></code>
								</li>
							<?php endforeach; ?>
						</ul>
						<p class="description">
							<?php
							printf(
								/* translators: %s: sélecteur CSS. */
								esc_html__( 'Un thème peut en ajouter : le filtre %1$s déclare le geste, et une règle CSS sur %2$s le dessine.', 'blocs-creator' ),
								'<code>blocs_creator_variantes_animation</code>',
								'<code>[data-bc-anim="…"]</code>'
							);
							?>
						</p>
					</td>
				</tr>

			</table>
		</section>

		<?php submit_button(); ?>
	</form>

</div>
