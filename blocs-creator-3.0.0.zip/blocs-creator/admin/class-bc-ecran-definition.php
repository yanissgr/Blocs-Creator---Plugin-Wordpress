<?php
/**
 * L'écran d'édition d'un bloc.
 *
 * WordPress fournit déjà un écran d'édition solide : un titre, une colonne
 * latérale, un bouton Publier, la corbeille, les révisions. On s'en sert plutôt
 * que d'en réécrire un — le bloc est un type de contenu, ses champs sont des
 * métaboxes. Ce qui est spécifique tient dans une seule : le constructeur.
 *
 * L'enregistrement passe par deux hooks plutôt qu'un :
 *
 *   - `wp_insert_post_data` pose le slug et la description AVANT l'écriture,
 *     pour que WordPress les valide comme les siens ;
 *   - `save_post` écrit la définition en méta.
 *
 * Faire les deux dans `save_post` obligerait à ré-enregistrer le post depuis
 * son propre hook d'enregistrement. On sait comment ça finit.
 *
 * @package BlocsCreator
 */

defined( 'ABSPATH' ) || exit;

/**
 * Métaboxes et enregistrement d'une définition.
 */
class BC_Ecran_Definition {

	/**
	 * Messages à afficher au prochain écran.
	 *
	 * @var array<int, array{type:string, texte:string}>
	 */
	private $messages = array();

	/**
	 * Branche les hooks.
	 */
	public function demarrer() {
		add_action( 'add_meta_boxes_' . BC_Definition::TYPE, array( $this, 'metaboxes' ) );
		add_filter( 'wp_insert_post_data', array( $this, 'avant_ecriture' ), 10, 2 );
		add_action( 'save_post_' . BC_Definition::TYPE, array( $this, 'enregistrer' ), 10, 2 );
		add_filter( 'enter_title_here', array( $this, 'invite_titre' ), 10, 2 );
		add_action( 'edit_form_after_title', array( $this, 'sous_titre' ) );
		add_filter( 'post_updated_messages', array( $this, 'messages_edition' ) );
		add_action( 'admin_notices', array( $this, 'afficher_messages' ) );
		add_filter( 'screen_options_show_screen', array( $this, 'masquer_options_ecran' ), 10, 2 );
	}

	/* ------------------------------------------------------------------ *
	 * Écran
	 * ------------------------------------------------------------------ */

	/**
	 * Remplace l'invite du champ titre.
	 *
	 * @param string  $texte Invite courante.
	 * @param WP_Post $post  Le post.
	 * @return string
	 */
	public function invite_titre( $texte, $post ) {
		if ( $post instanceof WP_Post && BC_Definition::TYPE === $post->post_type ) {
			return __( 'Nom du bloc — « Bannière », « Témoignages »…', 'blocs-creator' );
		}

		return $texte;
	}

	/**
	 * Affiche l'identifiant du bloc juste sous le titre.
	 *
	 * C'est le nom que portera le bloc dans le contenu des pages. Le voir au
	 * moment où l'on nomme le bloc évite de le découvrir trop tard.
	 *
	 * @param WP_Post $post Le post.
	 */
	public function sous_titre( $post ) {
		if ( ! $post instanceof WP_Post || BC_Definition::TYPE !== $post->post_type ) {
			return;
		}

		$definition = BC_Definition::charger( $post );
		$nom        = $definition ? BC_Definition::nom( $definition ) : '';

		printf(
			'<p class="bc-sous-titre">%s <code id="bc-apercu-nom">%s</code></p>',
			esc_html__( 'Identifiant du bloc :', 'blocs-creator' ),
			esc_html( '' !== $nom ? $nom : blocs_creator()->reglages->get( 'espace' ) . '/…' )
		);
	}

	/**
	 * Retire le panneau « Options de l'écran », qui n'a rien à proposer ici.
	 *
	 * @param bool      $afficher Faut-il l'afficher.
	 * @param WP_Screen $ecran    L'écran.
	 * @return bool
	 */
	public function masquer_options_ecran( $afficher, $ecran ) {
		if ( $ecran instanceof WP_Screen && BC_Definition::TYPE === $ecran->post_type ) {
			return false;
		}

		return $afficher;
	}

	/**
	 * Déclare les métaboxes.
	 *
	 * @param WP_Post $post Le post.
	 */
	public function metaboxes( $post ) {
		remove_meta_box( 'slugdiv', BC_Definition::TYPE, 'normal' );

		add_meta_box(
			'bc-champs',
			__( 'Champs du bloc', 'blocs-creator' ),
			array( $this, 'metabox_champs' ),
			BC_Definition::TYPE,
			'normal',
			'high'
		);

		add_meta_box(
			'bc-identite',
			__( 'Identité', 'blocs-creator' ),
			array( $this, 'metabox_identite' ),
			BC_Definition::TYPE,
			'side',
			'high'
		);

		add_meta_box(
			'bc-gabarit',
			__( 'Gabarit', 'blocs-creator' ),
			array( $this, 'metabox_gabarit' ),
			BC_Definition::TYPE,
			'side',
			'default'
		);

		add_meta_box(
			'bc-comportement',
			__( 'Comportement', 'blocs-creator' ),
			array( $this, 'metabox_comportement' ),
			BC_Definition::TYPE,
			'side',
			'default'
		);

		$definition = BC_Definition::charger( $post );

		if ( $definition && BC_Usage::compter( BC_Definition::nom( $definition ) ) > 0 ) {
			add_meta_box(
				'bc-usage',
				__( 'Où ce bloc est-il utilisé ?', 'blocs-creator' ),
				array( $this, 'metabox_usage' ),
				BC_Definition::TYPE,
				'side',
				'low'
			);
		}
	}

	/**
	 * Affiche une métabox.
	 *
	 * @param string  $vue  Nom du fichier de vue, sans extension.
	 * @param WP_Post $post Le post.
	 */
	private function vue( $vue, $post ) {
		$definition = BC_Definition::charger( $post );

		if ( null === $definition ) {
			$definition = BC_Definition::vierge();
		}

		include BLOCS_CREATOR_DIR . 'admin/vues/' . $vue . '.php';
	}

	/**
	 * Métabox « Champs du bloc ».
	 *
	 * @param WP_Post $post Le post.
	 */
	public function metabox_champs( $post ) {
		wp_nonce_field( 'bc_enregistrer_' . $post->ID, 'bc_nonce' );

		$this->vue( 'metabox-champs', $post );
	}

	/**
	 * Métabox « Identité ».
	 *
	 * @param WP_Post $post Le post.
	 */
	public function metabox_identite( $post ) {
		$this->vue( 'metabox-identite', $post );
	}

	/**
	 * Métabox « Gabarit ».
	 *
	 * @param WP_Post $post Le post.
	 */
	public function metabox_gabarit( $post ) {
		$this->vue( 'metabox-gabarit', $post );
	}

	/**
	 * Métabox « Comportement ».
	 *
	 * @param WP_Post $post Le post.
	 */
	public function metabox_comportement( $post ) {
		$this->vue( 'metabox-comportement', $post );
	}

	/**
	 * Métabox « Où ce bloc est-il utilisé ? ».
	 *
	 * @param WP_Post $post Le post.
	 */
	public function metabox_usage( $post ) {
		$this->vue( 'metabox-usage', $post );
	}

	/* ------------------------------------------------------------------ *
	 * Enregistrement
	 * ------------------------------------------------------------------ */

	/**
	 * Le formulaire a-t-il bien été soumis par nous ?
	 *
	 * @param int $post_id Identifiant du post.
	 * @return bool
	 */
	private function soumission_valide( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return false;
		}

		if ( empty( $_POST['bc_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['bc_nonce'] ) ), 'bc_enregistrer_' . $post_id ) ) {
			return false;
		}

		return current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Reconstruit la définition depuis le formulaire.
	 *
	 * @param WP_Post|array $post    Le post, pour son titre et son statut.
	 * @param int           $post_id Identifiant du post, pour ce qui ne se saisit pas.
	 * @return array
	 */
	private function depuis_formulaire( $post, $post_id = 0 ) {
		$brut = isset( $_POST['bc'] ) ? wp_unslash( $_POST['bc'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$brut = is_array( $brut ) ? $brut : array();

		$champs = array();

		if ( ! empty( $_POST['bc_champs_json'] ) ) {
			$json   = json_decode( wp_unslash( $_POST['bc_champs_json'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$champs = is_array( $json ) ? $json : array();
		}

		$definition = wp_parse_args(
			array(
				'titre'       => is_array( $post ) ? (string) ( $post['post_title'] ?? '' ) : $post->post_title,
				'slug'        => (string) ( $brut['slug'] ?? '' ),
				'espace'      => (string) ( $brut['espace'] ?? '' ),
				'description' => (string) ( $brut['description'] ?? '' ),
				'icone'       => (string) ( $brut['icone'] ?? '' ),
				'categorie'   => (string) ( $brut['categorie'] ?? '' ),
				'mots_cles'   => (string) ( $brut['mots_cles'] ?? '' ),
				'apercu'      => (string) ( $brut['apercu'] ?? 'serveur' ),
				'parent'      => (string) ( $brut['parent'] ?? '' ) !== '' ? explode( ',', (string) $brut['parent'] ) : array(),
				'supports'    => (array) ( $brut['supports'] ?? array() ),
				'champs'      => $champs,
			),
			BC_Definition::vierge()
		);

		if ( '' === trim( (string) $definition['slug'] ) ) {
			$definition['slug'] = sanitize_title( $definition['titre'] );
		}

		/*
		 * Ce que le formulaire ne montre pas, il ne doit pas l'effacer. Les
		 * attributs conservés, les feuilles de style et la trace de reprise
		 * d'un bloc codé n'ont aucun champ dans l'écran : on les relit tels
		 * qu'ils sont en base et on les repose.
		 */
		$stockee = $post_id > 0 ? BC_Definition::charger( $post_id ) : null;

		if ( null !== $stockee ) {
			foreach ( array( 'attributs', 'assets', 'extras', 'adoption' ) as $cle ) {
				$definition[ $cle ] = $stockee[ $cle ];
			}
		}

		return BC_Definition::normaliser( $definition );
	}

	/**
	 * Pose le slug et la description avant que WordPress n'écrive le post.
	 *
	 * @param array $donnees Données prêtes à l'écriture.
	 * @param array $brut    Données soumises.
	 * @return array
	 */
	public function avant_ecriture( $donnees, $brut ) {
		if ( BC_Definition::TYPE !== ( $donnees['post_type'] ?? '' ) ) {
			return $donnees;
		}

		$post_id = (int) ( $brut['ID'] ?? 0 );

		if ( ! $this->soumission_valide( $post_id ) ) {
			return $donnees;
		}

		$definition = $this->depuis_formulaire( $donnees, $post_id );
		$slug       = $definition['slug'];

		// Deux blocs de même nom, c'est le second qui gagne au hasard de
		// l'ordre d'enregistrement. On corrige et on le dit.
		$libre = $this->slug_libre( $slug, $definition['espace'], $post_id, $definition );

		if ( $libre !== $slug ) {
			$this->message(
				'warning',
				sprintf(
					/* translators: 1: identifiant demandé, 2: identifiant retenu. */
					__( 'L\'identifiant « %1$s » était déjà pris : le bloc a été enregistré sous « %2$s ».', 'blocs-creator' ),
					$slug,
					$libre
				)
			);
		}

		$donnees['post_name']    = $libre;
		$donnees['post_excerpt'] = $definition['description'];

		if ( '' === trim( (string) $donnees['post_title'] ) ) {
			$donnees['post_title'] = __( 'Bloc sans nom', 'blocs-creator' );
		}

		return $donnees;
	}

	/**
	 * Retourne un slug libre dans cet espace de noms, hors du bloc courant.
	 *
	 * @param string $slug       Slug demandé.
	 * @param string $espace     Espace de noms.
	 * @param int    $post_id    Bloc en cours d'édition.
	 * @param array  $definition La définition soumise.
	 * @return string
	 */
	private function slug_libre( $slug, $espace, $post_id, $definition = array() ) {
		$pris    = array();
		$reprend = (string) ( $definition['adoption']['nom'] ?? '' );

		foreach ( BC_Definition::toutes() as $autre ) {
			if ( (int) $autre['id'] === (int) $post_id || $autre['espace'] !== $espace ) {
				continue;
			}

			$pris[] = $autre['slug'];
		}

		foreach ( blocs_creator()->registre->blocs_codes() as $code ) {
			// Le bloc codé qu'on a repris porte le même nom que sa reprise :
			// c'est voulu, il ne prend donc pas la place.
			if ( $code['espace'] === $espace && $code['nom'] !== $reprend ) {
				$pris[] = $code['slug'];
			}
		}

		$base  = $slug;
		$index = 2;

		while ( in_array( $slug, $pris, true ) ) {
			$slug = $base . '-' . $index;
			++$index;
		}

		return $slug;
	}

	/**
	 * Écrit la définition en méta, puis crée le gabarit s'il le faut.
	 *
	 * @param int     $post_id Identifiant du post.
	 * @param WP_Post $post    Le post enregistré.
	 */
	public function enregistrer( $post_id, $post ) {
		if ( ! $this->soumission_valide( $post_id ) ) {
			return;
		}

		$definition = $this->depuis_formulaire( $post, $post_id );

		// Le titre, le slug et la description sont déjà dans les colonnes du
		// post : les répéter en méta, c'est préparer une divergence.
		$a_stocker = $definition;
		unset( $a_stocker['id'], $a_stocker['titre'], $a_stocker['slug'], $a_stocker['description'], $a_stocker['statut'], $a_stocker['source'] );

		update_post_meta(
			$post_id,
			BC_Definition::META,
			wp_slash( wp_json_encode( $a_stocker, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) )
		);

		BC_Usage::vider_cache();

		$fraiche = BC_Definition::charger( $post_id );

		if ( null === $fraiche ) {
			return;
		}

		if ( empty( $fraiche['champs'] ) ) {
			$this->message(
				'warning',
				__( 'Ce bloc n\'a aucun champ : il s\'insérera, mais il n\'y aura rien à y saisir.', 'blocs-creator' )
			);
		}

		if (
			'publish' === $post->post_status
			&& blocs_creator()->reglages->get( 'creer_gabarit' )
			&& empty( $fraiche['adoption'] )
			&& '' === BC_Gabarits::chemin( $fraiche )
		) {
			$resultat = BC_Gabarits::creer( $fraiche );

			if ( is_wp_error( $resultat ) ) {
				$this->message( 'warning', $resultat->get_error_message() );
			} else {
				$this->message(
					'success',
					sprintf(
						/* translators: %s: chemin du fichier créé. */
						__( 'Gabarit créé : %s — c\'est là que se dessine le bloc.', 'blocs-creator' ),
						BC_Gabarits::chemin_court( $resultat )
					)
				);
			}
		}

		do_action( 'blocs_creator_definition_enregistree', $post_id, $fraiche );
	}

	/* ------------------------------------------------------------------ *
	 * Messages
	 * ------------------------------------------------------------------ */

	/**
	 * Met un message de côté pour le prochain écran.
	 *
	 * @param string $type  `success`, `warning` ou `error`.
	 * @param string $texte Le message.
	 */
	private function message( $type, $texte ) {
		$this->messages[] = array(
			'type'  => $type,
			'texte' => $texte,
		);

		set_transient( 'bc_messages_' . get_current_user_id(), $this->messages, 60 );
	}

	/**
	 * Affiche les messages mis de côté.
	 */
	public function afficher_messages() {
		$cle      = 'bc_messages_' . get_current_user_id();
		$messages = get_transient( $cle );

		if ( empty( $messages ) || ! is_array( $messages ) ) {
			return;
		}

		delete_transient( $cle );

		foreach ( $messages as $message ) {
			printf(
				'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
				esc_attr( $message['type'] ),
				esc_html( $message['texte'] )
			);
		}
	}

	/**
	 * Remplace les messages d'enregistrement natifs.
	 *
	 * « Article publié. Voir l'article » n'a aucun sens pour un bloc : il n'a
	 * pas de page à voir.
	 *
	 * @param array $messages Messages existants.
	 * @return array
	 */
	public function messages_edition( $messages ) {
		$messages[ BC_Definition::TYPE ] = array(
			0  => '',
			1  => __( 'Bloc mis à jour. Il est disponible dans l\'éditeur.', 'blocs-creator' ),
			2  => __( 'Champ mis à jour.', 'blocs-creator' ),
			3  => __( 'Champ supprimé.', 'blocs-creator' ),
			4  => __( 'Bloc mis à jour.', 'blocs-creator' ),
			5  => __( 'Bloc restauré à sa version précédente.', 'blocs-creator' ),
			6  => __( 'Bloc créé. Il est disponible dans l\'éditeur.', 'blocs-creator' ),
			7  => __( 'Bloc enregistré.', 'blocs-creator' ),
			8  => __( 'Bloc soumis.', 'blocs-creator' ),
			9  => __( 'Bloc programmé.', 'blocs-creator' ),
			10 => __( 'Brouillon du bloc mis à jour.', 'blocs-creator' ),
		);

		return $messages;
	}
}
