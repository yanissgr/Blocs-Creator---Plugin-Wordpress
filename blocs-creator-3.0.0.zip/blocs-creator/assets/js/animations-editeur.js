/*
 * Le panneau « Apparition », posé sur tous les blocs.
 *
 * Deux filtres suffisent : l'un ajoute les attributs à la déclaration de
 * chaque bloc, l'autre ajoute le panneau à son inspecteur. Aucun bloc n'est
 * modifié, aucun `save` n'est touché — c'est PHP qui pose la classe au rendu,
 * ce qui permet d'animer un bloc de WordPress ou d'une autre extension sans
 * rendre « inattendu » le contenu déjà enregistré dans les pages.
 *
 * L'éditeur ne joue pas l'animation : on la règle, on ne la subit pas à
 * chaque frappe. Le panneau le dit.
 */

( function ( wp ) {
	'use strict';

	if ( ! wp || ! wp.hooks || ! window.blocsCreatorAnimations ) {
		return;
	}

	var donnees  = window.blocsCreatorAnimations;
	var ATTRIBUT = donnees.attribut || 'bcAnim';
	var DUREE    = ATTRIBUT + 'Duree';
	var DELAI    = ATTRIBUT + 'Delai';

	var el       = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __       = wp.i18n.__;

	var InspectorControls = wp.blockEditor.InspectorControls;

	var PanelBody     = wp.components.PanelBody;
	var SelectControl = wp.components.SelectControl;
	var RangeControl  = wp.components.RangeControl;
	var Button        = wp.components.Button;

	/**
	 * Le bloc a-t-il droit au réglage ?
	 *
	 * La liste des exclus et, le cas échéant, celle des blocs créés ici,
	 * viennent de PHP : les deux côtés répondent donc exactement la même
	 * chose, et un bloc ne peut pas porter un réglage que le rendu ignorerait.
	 *
	 * @param {string} nom Nom complet du bloc.
	 * @return {boolean} Vrai si le bloc est concerné.
	 */
	function concerne( nom ) {
		if ( ! nom || -1 !== ( donnees.exclus || [] ).indexOf( nom ) ) {
			return false;
		}

		if ( Array.isArray( donnees.crees ) ) {
			return -1 !== donnees.crees.indexOf( nom );
		}

		return true;
	}

	/* -------------------------------------------------------------- *
	 * Les attributs
	 * -------------------------------------------------------------- */

	wp.hooks.addFilter(
		'blocks.registerBlockType',
		'blocs-creator/animation-attributs',
		function ( reglages, nom ) {
			if ( ! concerne( nom ) ) {
				return reglages;
			}

			reglages.attributes = Object.assign( {}, reglages.attributes );

			reglages.attributes[ ATTRIBUT ] = { type: 'string', default: '' };
			reglages.attributes[ DUREE ]    = { type: 'number', default: 0 };
			reglages.attributes[ DELAI ]    = { type: 'number', default: 0 };

			return reglages;
		}
	);

	/* -------------------------------------------------------------- *
	 * Le panneau
	 * -------------------------------------------------------------- */

	var choix = [ { value: '', label: __( 'Aucune', 'blocs-creator' ) } ].concat( donnees.variantes || [] );

	var panneau = wp.compose.createHigherOrderComponent( function ( BlockEdit ) {
		return function ( props ) {
			if ( ! props.isSelected || ! concerne( props.name ) ) {
				return el( BlockEdit, props );
			}

			var a   = props.attributes;
			var set = props.setAttributes;

			var variante = a[ ATTRIBUT ] || '';

			return el(
				Fragment,
				null,
				el( BlockEdit, props ),
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{
							title: __( 'Apparition', 'blocs-creator' ),
							initialOpen: false,
						},
						el( SelectControl, {
							label: __( 'Animation à l’entrée', 'blocs-creator' ),
							value: variante,
							options: choix,
							onChange: function ( valeur ) {
								set( { [ ATTRIBUT ]: valeur } );
							},
							help: __(
								'Le bloc s’anime quand le visiteur arrive dessus. L’éditeur, lui, ne la joue pas.',
								'blocs-creator'
							),
							__nextHasNoMarginBottom: true,
						} ),

						variante
							? el( RangeControl, {
									label: __( 'Durée', 'blocs-creator' ),
									value: a[ DUREE ] || 700,
									min: 200,
									max: 2000,
									step: 50,
									onChange: function ( valeur ) {
										set( { [ DUREE ]: valeur || 0 } );
									},
									help: __( 'En millisecondes.', 'blocs-creator' ),
									__nextHasNoMarginBottom: true,
							  } )
							: null,

						variante
							? el( RangeControl, {
									label: __( 'Retard au départ', 'blocs-creator' ),
									value: a[ DELAI ] || 0,
									min: 0,
									max: 1200,
									step: 50,
									onChange: function ( valeur ) {
										set( { [ DELAI ]: valeur || 0 } );
									},
									help: __(
										'De quoi faire entrer deux blocs voisins l’un après l’autre.',
										'blocs-creator'
									),
									__nextHasNoMarginBottom: true,
							  } )
							: null,

						variante
							? el(
									Button,
									{
										variant: 'tertiary',
										onClick: function () {
											var remise = {};

											remise[ ATTRIBUT ] = '';
											remise[ DUREE ]    = 0;
											remise[ DELAI ]    = 0;

											set( remise );
										},
									},
									__( 'Retirer l’apparition', 'blocs-creator' )
							  )
							: null
					)
				)
			);
		};
	}, 'blocsCreatorApparition' );

	wp.hooks.addFilter( 'editor.BlockEdit', 'blocs-creator/animation-panneau', panneau );
}( window.wp ) );
