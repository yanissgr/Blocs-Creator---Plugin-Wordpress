/*
 * Les apparitions : révéler un bloc quand il entre à l'écran.
 *
 * Le script ne décide de rien visuellement. Il ne fait qu'une chose : poser
 * `is-vu` au bon moment. Tout le dessin est dans assets/css/animations.css,
 * et c'est PHP qui a posé `data-bc-anim` sur le bloc.
 *
 * Écrit en JavaScript natif, sans dépendance : le plugin s'installe partout
 * sans outil de build, et cette feuille-là part sur toutes les pages du site.
 */

( function ( window, document ) {
	'use strict';

	/* Un bloc est considéré entré quand il a franchi 10 % du bas de l'écran. */
	var MARGE = '0px 0px -10% 0px';

	/*
	 * Le filet de sécurité, en millisecondes.
	 *
	 * Passé ce temps, si rien n'a jamais été révélé, c'est que l'observateur
	 * ne rendra pas la main : page pré-rendue, moteur qui ne livre pas ses
	 * entrées. On montre tout. Une page blanche est un prix trop élevé pour
	 * une apparition.
	 */
	var FILET = 3500;

	function demarrer() {
		var racine = document.documentElement;

		if ( ! racine.classList.contains( 'bc-anim-prete' ) ) {
			return;
		}

		var blocs = document.querySelectorAll( '.bc-anim[data-bc-anim]' );

		if ( ! blocs.length ) {
			return;
		}

		/*
		 * Le filet posé par le script d'en-tête a fait son travail : il a
		 * couvert le temps de chargement de ce fichier. À partir d'ici, c'est
		 * le nôtre qui prend la suite, avec un compte à rebours qui ne part
		 * que quand la page est réellement regardée — un onglet ouvert en
		 * arrière-plan ne reçoit pas d'entrées non plus, mais lui les recevra
		 * dès qu'on le regardera.
		 */
		window.clearTimeout( window.bcAnimFilet );

		function tout_montrer() {
			Array.prototype.forEach.call( blocs, function ( bloc ) {
				bloc.classList.add( 'is-vu' );
			} );
		}

		if ( ! ( 'IntersectionObserver' in window ) ) {
			tout_montrer();
			return;
		}

		var revele = false;

		var observateur = new window.IntersectionObserver(
			function ( entrees ) {
				entrees.forEach( function ( entree ) {
					if ( ! entree.isIntersecting ) {
						return;
					}

					entree.target.classList.add( 'is-vu' );
					observateur.unobserve( entree.target );
					revele = true;
				} );
			},
			{ rootMargin: MARGE }
		);

		Array.prototype.forEach.call( blocs, function ( bloc ) {
			observateur.observe( bloc );
		} );

		var armer = function () {
			window.setTimeout( function () {
				if ( ! revele ) {
					tout_montrer();
				}
			}, FILET );
		};

		if ( 'hidden' === document.visibilityState ) {
			document.addEventListener( 'visibilitychange', function une_fois() {
				document.removeEventListener( 'visibilitychange', une_fois );
				armer();
			} );
		} else {
			armer();
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', demarrer );
	} else {
		demarrer();
	}
}( window, document ) );
