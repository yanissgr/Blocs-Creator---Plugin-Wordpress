<?php
/**
 * Aides de rendu partagées par les blocs.
 *
 * @package BlocsCreator\Packs\Salama
 */

defined( 'ABSPATH' ) || exit;

/**
 * Retourne l'image d'un bloc, ou la surface d'attente s'il n'y en a pas.
 *
 * Le repli n'est pas une erreur : une section reste présentable pendant que la
 * rédaction cherche son visuel. Même principe que `.card__media-empty` dans le
 * thème.
 *
 * @param int    $id     Identifiant du média.
 * @param string $taille Taille d'image WordPress.
 * @param string $classe Classe CSS posée sur l'image comme sur le repli.
 * @return string
 */
function salama_blocs_image( $id, $taille = 'salama-card', $classe = '' ) {
	$id = (int) $id;

	if ( $id > 0 && wp_attachment_is_image( $id ) ) {
		$atours = array( 'loading' => 'lazy' );

		// Un class="" vide dans le balisage n'apprend rien à personne.
		if ( '' !== $classe ) {
			$atours['class'] = $classe;
		}

		$image = wp_get_attachment_image( $id, $taille, false, $atours );

		if ( $image ) {
			return $image;
		}
	}

	return sprintf(
		'<span class="salama-blocs__attente %s" aria-hidden="true"></span>',
		esc_attr( $classe )
	);
}

/**
 * Retourne un rappel visible des seuls administrateurs.
 *
 * Convention du thème, posée par le calendrier, les coordonnées et les
 * carrousels : le visiteur ne voit rien, la rédaction voit ce qu'il reste à
 * remplir. Un bloc à moitié configuré ne doit ni disparaître en silence, ni
 * s'afficher cassé.
 *
 * @param string $message Ce qui manque.
 * @return string
 */
function salama_blocs_rappel( $message ) {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return '';
	}

	return sprintf(
		'<p class="salama-blocs__rappel">%s</p>',
		esc_html( $message )
	);
}

/**
 * Ramène un niveau de titre dans une plage valide.
 *
 * Le plancher est h2 par défaut : le h1 appartient au titre de la page, et
 * deux h1 sur une même page cassent le plan du document. Les gabarits « sans
 * en-tête » sont l'exception — la page n'affiche alors aucun titre de son
 * côté, et c'est un bloc qui porte le h1. Ceux-là passent $minimum à 1.
 *
 * @param mixed $niveau  Niveau demandé.
 * @param int   $minimum Niveau le plus haut autorisé.
 * @return int
 */
function salama_blocs_niveau( $niveau, $minimum = 2 ) {
	$niveau  = (int) $niveau;
	$minimum = min( 6, max( 1, (int) $minimum ) );

	return min( 6, max( $minimum, $niveau ) );
}

/**
 * Met un prix en forme, et lui pose sa devise.
 *
 * La rédaction saisit un nombre — « 45 », « 45,50 », « 45.5 » — et l'euro est
 * ajouté ici. Un prix qui n'est pas un nombre — « sur devis », « nous
 * consulter » — passe tel quel : lui coller un € en ferait une phrase fausse.
 *
 * Un euro déjà tapé est retiré avant d'être reposé, pour qu'une ligne saisie à
 * l'ancienne ne se retrouve pas avec deux devises.
 *
 * @param string $prix   Le prix saisi.
 * @param string $devise Le symbole, € par défaut.
 * @return string Balisage prêt à poser, déjà échappé.
 */
function salama_blocs_prix( $prix, $devise = '€' ) {
	$prix = trim( (string) $prix );
	$prix = trim( preg_replace( '/\s*(€|EUR|euros?)\s*$/iu', '', $prix ) );

	if ( '' === $prix ) {
		return '<span class="salama-tarifs__vide" aria-hidden="true">—</span>';
	}

	// Un nombre, avec ou sans décimales, virgule ou point. Tout le reste est
	// une phrase, et une phrase ne prend pas de devise.
	if ( ! preg_match( '/^\d+([.,]\d{1,2})?$/', $prix ) ) {
		return '<span class="salama-tarifs__mention">' . esc_html( $prix ) . '</span>';
	}

	return sprintf(
		'<span class="salama-tarifs__montant">%s</span><span class="salama-tarifs__devise">%s</span>',
		esc_html( str_replace( '.', ',', $prix ) ),
		esc_html( $devise )
	);
}
