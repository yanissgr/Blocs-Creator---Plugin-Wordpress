<?php
/**
 * Les assets du pack Salama.
 *
 * Les blocs partagent un seul script d'éditeur et une seule feuille de style :
 * les block.json y renvoient par identifiant plutôt que par fichier, ce qui
 * évite une requête par bloc pour des blocs qui vont toujours ensemble.
 *
 * L'enregistrement des blocs eux-mêmes n'est plus ici : Blocs Creator parcourt
 * `packs/salama/blocs/` et enregistre tout dossier portant un `block.json`
 * (BC_Registre, sur `init` priorité 20). Une seule source pour enregistrer et
 * pour lister — sans quoi l'écran « Tous les blocs » finirait par mentir.
 *
 * Ce fichier garde donc les assets, qui doivent être enregistrés AVANT les
 * blocs : d'où le `init` par défaut, priorité 10.
 *
 * @package BlocsCreator\Packs\Salama
 */

defined( 'ABSPATH' ) || exit;

/**
 * Retourne une version basée sur la date de modification du fichier.
 *
 * Même principe que le thème : en développement, le cache navigateur
 * s'invalide à chaque enregistrement.
 *
 * @param string $chemin Chemin du fichier, relatif à la racine du plugin.
 * @return string
 */
function salama_blocs_version( $chemin ) {
	$fichier = SALAMA_BLOCS_DIR . ltrim( $chemin, '/' );

	if ( file_exists( $fichier ) ) {
		return (string) filemtime( $fichier );
	}

	return SALAMA_BLOCS_VERSION;
}

/**
 * Retourne l'URL complète d'un asset du plugin.
 *
 * @param string $chemin Chemin du fichier, relatif à la racine du plugin.
 * @return string
 */
function salama_blocs_uri( $chemin ) {
	return SALAMA_BLOCS_URL . ltrim( $chemin, '/' );
}

/**
 * Déclare la catégorie « Salama » de l'inséreur, en tête de liste.
 *
 * Elle n'est ajoutée que si personne ne l'a déjà déclarée — ni sous ce slug,
 * ni sous ce titre. Deux sections « Salama » dans l'inséreur ne sont pas deux
 * rangements : c'est le même, coupé en deux, et plus personne ne sait dans
 * laquelle chercher. Le cas se produit dès qu'on nomme « Salama » la catégorie
 * des blocs créés dans Blocs Creator, ce qui est le premier réflexe.
 *
 * @param array $categories Catégories existantes.
 * @return array
 */
function salama_blocs_categorie( $categories ) {
	foreach ( (array) $categories as $existante ) {
		$slug  = (string) ( $existante['slug'] ?? '' );
		$titre = (string) ( $existante['title'] ?? '' );

		if ( 'salama' === $slug || 0 === strcasecmp( $titre, 'Salama' ) ) {
			return $categories;
		}
	}

	array_unshift(
		$categories,
		array(
			'slug'  => 'salama',
			'title' => __( 'Salama', 'salama-blocs' ),
		)
	);

	return $categories;
}
add_filter( 'block_categories_all', 'salama_blocs_categorie', 5 );

/**
 * Enregistre les assets partagés du pack.
 *
 * Ils doivent l'être avant register_block_type(), sinon les identifiants cités
 * dans les block.json ne pointent sur rien.
 */
function salama_blocs_enregistrer() {
	wp_register_style(
		'salama-blocs',
		salama_blocs_uri( 'assets/css/blocs.css' ),
		array(),
		salama_blocs_version( 'assets/css/blocs.css' )
	);

	wp_register_style(
		'salama-blocs-editeur',
		salama_blocs_uri( 'assets/css/editeur.css' ),
		array( 'salama-blocs' ),
		salama_blocs_version( 'assets/css/editeur.css' )
	);

	/*
	 * Éditeur écrit en JavaScript natif : le thème n'a aucun outil de build et
	 * on ne lui en impose pas un pour huit blocs. Plus verbeux que du JSX,
	 * mais lisible et modifiable sans `npm install`.
	 */
	wp_register_script(
		'salama-blocs-editeur',
		salama_blocs_uri( 'assets/js/editeur.js' ),
		array( 'wp-api-fetch', 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-core-data', 'wp-data', 'wp-element', 'wp-i18n', 'wp-url' ),
		salama_blocs_version( 'assets/js/editeur.js' ),
		true
	);

	wp_set_script_translations( 'salama-blocs-editeur', 'salama-blocs' );
}
add_action( 'init', 'salama_blocs_enregistrer' );
