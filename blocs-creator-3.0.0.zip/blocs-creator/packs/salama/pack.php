<?php
/**
 * Pack « Salama ».
 *
 * Un pack rassemble des blocs écrits à la main : leur balisage, leur éditeur et
 * leur habillage sont du code, pas une définition saisie dans le back-office.
 * Blocs Creator les découvre, les enregistre et les liste au même endroit que
 * les blocs générés — voir BC_Registre.
 *
 * Ce pack-ci porte les blocs du site Salama. Sur une autre installation, il n'a
 * rien à faire : supprimez le dossier `packs/salama/`, le plugin n'en saura
 * rien. C'est le contrat de tous les packs.
 *
 * Contrat : ce fichier est inclus avant `init`, il peut charger ce qu'il veut,
 * et il retourne ses métadonnées. Les dossiers de `blocs/` qui contiennent un
 * `block.json` sont enregistrés par le plugin, pas par le pack.
 *
 * @package BlocsCreator\Packs\Salama
 */

defined( 'ABSPATH' ) || exit;

define( 'SALAMA_BLOCS_VERSION', '1.2.0' );
define( 'SALAMA_BLOCS_DIR', plugin_dir_path( __FILE__ ) );
define( 'SALAMA_BLOCS_URL', plugin_dir_url( __FILE__ ) );

require_once SALAMA_BLOCS_DIR . 'inc/rendu.php';
require_once SALAMA_BLOCS_DIR . 'inc/reservations.php';
require_once SALAMA_BLOCS_DIR . 'inc/blocs.php';
require_once SALAMA_BLOCS_DIR . 'inc/editeur.php';
require_once SALAMA_BLOCS_DIR . 'inc/motifs.php';

/*
 * Les métadonnées ne passent pas par __() : ce fichier est lu avant `init`, et
 * WordPress refuse qu'on y charge un domaine de traduction. Un pack propre à
 * un site n'a de toute façon qu'une langue.
 */
return array(
	'nom'         => 'Salama',
	'description' => 'Les blocs sur mesure du site Salama : bannière, texte et image décorée, cartes de spécialité, carrousels de publications, tableau de tarifs, calendrier de réservation.',
	'auteur'      => 'Yanis Singer',
	'version'     => SALAMA_BLOCS_VERSION,
	'site'        => 'Salama',
);
