<?php
/**
 * Rendu du bloc « Tarifs ».
 *
 * Un tableau, au sens propre : trois colonnes, une ligne par prestation. Le
 * balisage porte les rôles ARIA explicitement — `role="table"`, `role="row"`,
 * `role="cell"` — parce que le CSS change le `display` des lignes dès que le
 * bloc est posé dans une colonne étroite. Sans ces rôles, un lecteur d'écran
 * perdrait la structure au moment précis où elle devient la plus utile.
 *
 * C'est cette même contrainte qui a écarté la largeur fixe : le bloc doit
 * pouvoir tenir à côté du formulaire de contact, dans une demi-colonne, sans
 * pousser la page vers la droite. Il lit donc la largeur de son CONTENEUR, et
 * non celle de l'écran — voir la requête de conteneur dans blocs.css.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Les lignes de tarif, déjà rendues.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_titre  = trim( (string) ( $attributes['titre'] ?? '' ) );
$salama_intro  = trim( (string) ( $attributes['intro'] ?? '' ) );
$salama_note   = trim( (string) ( $attributes['note'] ?? '' ) );
$salama_niveau = salama_blocs_niveau( $attributes['niveau'] ?? 2 );
$salama_avec   = ! empty( $attributes['complement'] );
$salama_entete = ! empty( $attributes['entetes'] );
$salama_lignes = trim( (string) $content );

$salama_classes = 'salama-tarifs';

if ( ! empty( $attributes['fond'] ) ) {
	$salama_classes .= ' salama-tarifs--fond';
}

if ( ! $salama_avec ) {
	$salama_classes .= ' salama-tarifs--deux';
}

$salama_attributs = get_block_wrapper_attributes( array( 'class' => $salama_classes ) );
?>
<section <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>

	<?php if ( '' !== $salama_titre ) : ?>
		<?php printf( '<h%1$d class="salama-tarifs__titre">%2$s</h%1$d>', (int) $salama_niveau, wp_kses_post( $salama_titre ) ); ?>
	<?php endif; ?>

	<?php if ( '' !== $salama_intro ) : ?>
		<p class="salama-tarifs__intro"><?php echo wp_kses_post( $salama_intro ); ?></p>
	<?php endif; ?>

	<div class="salama-tarifs__cadre">
		<div class="salama-tarifs__table" role="table">

			<?php if ( $salama_entete ) : ?>
				<div class="salama-tarifs__entete" role="row">
					<span class="salama-tarifs__col salama-tarifs__col--nom" role="columnheader">
						<?php echo esc_html( (string) ( $attributes['enPrestation'] ?? '' ) ); ?>
					</span>
					<span class="salama-tarifs__col salama-tarifs__col--prix" role="columnheader">
						<?php echo esc_html( (string) ( $attributes['enPrix'] ?? '' ) ); ?>
					</span>
					<?php if ( $salama_avec ) : ?>
						<span class="salama-tarifs__col salama-tarifs__col--plus" role="columnheader">
							<?php echo esc_html( (string) ( $attributes['enComplement'] ?? '' ) ); ?>
						</span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( '' !== $salama_lignes ) : ?>
				<?php echo $salama_lignes; // phpcs:ignore WordPress.Security.EscapeOutput -- lignes déjà rendues par leurs blocs. ?>
			<?php else : ?>
				<?php
				echo salama_blocs_rappel( // phpcs:ignore WordPress.Security.EscapeOutput
					__( 'Ce tableau n\'a aucune ligne : ajoutez une « Ligne de tarif » à l\'intérieur du bloc.', 'salama-blocs' )
				);
				?>
			<?php endif; ?>

		</div>
	</div>

	<?php if ( '' !== $salama_note ) : ?>
		<p class="salama-tarifs__note"><?php echo wp_kses_post( $salama_note ); ?></p>
	<?php endif; ?>

</section>
