<?php
/**
 * Rendu d'une ligne du tableau des tarifs.
 *
 * Le prix s'écrit sans devise dans l'éditeur — « 45 », « 45,50 » — et l'euro
 * est posé ici. C'est un choix : la rédaction saisit un nombre, pas une mise
 * en forme, et le site reste cohérent même si une ligne est saisie autrement.
 * Un prix qui n'est pas un nombre — « sur devis » — passe tel quel, sans
 * devise : lui coller un € en ferait une phrase fausse.
 *
 * Les libellés de colonnes viennent du bloc parent par le contexte. Ils
 * servent aux petites largeurs, où le tableau se replie en lignes empilées et
 * où chaque valeur a besoin de dire de quoi elle parle.
 *
 * @package BlocsCreator\Packs\Salama
 *
 * @var array    $attributes Attributs du bloc.
 * @var string   $content    Inutilisé.
 * @var WP_Block $block      Instance du bloc.
 */

defined( 'ABSPATH' ) || exit;

$salama_prestation = trim( (string) ( $attributes['prestation'] ?? '' ) );
$salama_prix       = trim( (string) ( $attributes['prix'] ?? '' ) );
$salama_plus       = trim( (string) ( $attributes['complement'] ?? '' ) );

$salama_contexte = $block instanceof WP_Block ? (array) $block->context : array();
$salama_avec     = ! isset( $salama_contexte['salama/tarifsComplement'] ) || ! empty( $salama_contexte['salama/tarifsComplement'] );

$salama_classes = 'salama-tarifs__ligne';

if ( ! empty( $attributes['enAvant'] ) ) {
	$salama_classes .= ' salama-tarifs__ligne--avant';
}

$salama_attributs = get_block_wrapper_attributes(
	array(
		'class' => $salama_classes,
		'role'  => 'row',
	)
);
?>
<div <?php echo $salama_attributs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>

	<span class="salama-tarifs__col salama-tarifs__col--nom" role="rowheader"
		data-libelle="<?php echo esc_attr( (string) ( $salama_contexte['salama/tarifsEnPrestation'] ?? '' ) ); ?>">
		<?php
		echo '' !== $salama_prestation
			? wp_kses_post( $salama_prestation )
			: salama_blocs_rappel( __( 'Ligne sans prestation.', 'salama-blocs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		?>
	</span>

	<span class="salama-tarifs__col salama-tarifs__col--prix" role="cell"
		data-libelle="<?php echo esc_attr( (string) ( $salama_contexte['salama/tarifsEnPrix'] ?? '' ) ); ?>">
		<?php echo salama_blocs_prix( $salama_prix ); // phpcs:ignore WordPress.Security.EscapeOutput -- balisage déjà échappé. ?>
	</span>

	<?php if ( $salama_avec ) : ?>
		<?php
		/*
		 * Pas d'espace autour de la valeur : une cellule vide doit l'être
		 * vraiment, sinon `:empty` ne la reconnaît pas et elle garde sa place
		 * dans la ligne repliée.
		 */
		?>
		<span class="salama-tarifs__col salama-tarifs__col--plus" role="cell"
			data-libelle="<?php echo esc_attr( (string) ( $salama_contexte['salama/tarifsEnComplement'] ?? '' ) ); ?>"><?php echo wp_kses_post( $salama_plus ); ?></span>
	<?php endif; ?>

</div>
