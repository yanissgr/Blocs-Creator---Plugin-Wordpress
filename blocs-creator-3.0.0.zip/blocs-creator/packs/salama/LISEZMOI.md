# Pack Salama

Blocs Gutenberg sur mesure du site Salama.

> **Ce dossier est un pack de [Blocs Creator](../../README.md).** Il était
> autrefois un plugin à part, `salama-blocs` ; ses blocs gardent leurs
> noms d'origine (`salama/banniere`, `salama/carte`…), qui sont inscrits dans
> le contenu des pages et ne peuvent pas changer. Blocs Creator les découvre,
> les enregistre et les liste au même endroit que les blocs générés.
>
> Sur une autre installation, supprimez ce dossier : le plugin n'en saura rien.

Le bloc **Salama — Lien avec icône** peut être inséré seul ou dans une colonne
WordPress. Le libellé s'écrit directement dans le bloc ; les panneaux **Lien**
et **Image de l’icône** permettent de choisir la destination (page, URL,
`tel:` ou `mailto:`), l'ouverture dans un nouvel onglet et l'image. L'image
garde ses proportions et les longs libellés se replient dans les colonnes
étroites. Sans destination, le texte reste visible mais n'est pas cliquable.

Dans le bloc **Salama — Bannière**, le panneau **Image** permet de désactiver
le fond (l'ombre découpée), de choisir le vert ou le rouge du thème, de déplacer
le point de cadrage et de recentrer
la photo. Ces réglages sont propres à chaque bannière et se retrouvent dans
l'aperçu comme sur le site. Les bannières existantes gardent le fond vert et
un cadrage centré ; choisir une nouvelle image réinitialise son cadrage.

Le plugin fournit le **balisage et les champs** ; l'habillage repose sur les
feuilles du thème (`jetons.css`, `composants.css`). Il est écrit pour ce thème,
pas pour être portable : sans lui, les blocs perdent leurs arrondis, leurs
encres et leur coup de pinceau.

## Deux règles, valables pour tout bloc à venir

### 1. L'aperçu ne ment pas

Ce qu'on voit dans l'éditeur est ce que le visiteur verra. Trois choses le
permettent, et il faut les tenir :

- **Les mêmes classes des deux côtés.** Chaque fonction `edit` produit le
  balisage du rendu PHP, à la classe près.
- **Les mêmes feuilles des deux côtés.** Le thème charge `jetons.css` et
  `composants.css` dans l'éditeur comme sur le site (`add_editor_style()`), et
  `theme.json` y annonce la vraie largeur de contenu. Un style qui doit se voir
  dans l'éditeur va donc dans `composants.css`, **jamais** dans `main.css`.
- **Le vrai contenu, pas un dessin.** Quand un bloc dépend de données du site —
  les publications d'un carrousel — l'éditeur en demande le rendu au serveur
  (`inc/editeur.php`, route `salama/v1/carrousel`) au lieu de le redessiner en
  JavaScript. Le code est le même : l'aperçu ne peut pas diverger.
- **Mais l'aperçu ne se clique pas.** Les cartes de l'aperçu sont rendues sans
  lien : `salama_card( …, [ 'lien' => false ] )` les fabrique en `<span>` au lieu
  de `<a>`. Cliquer une carte quitterait la page en cours d'écriture. Le dessin
  ne change pas — tout est porté par la classe `.card` — et le curseur redevient
  une flèche, ce qui dit bien qu'il n'y a rien à cliquer.

  > Neutraliser le clic en CSS (`pointer-events: none`) aurait laissé la carte
  > atteignable au clavier et annoncée comme lien par un lecteur d'écran. Ne pas
  > fabriquer de lien du tout ferme les trois chemins d'un coup, et à la source :
  > c'est la route REST qui le décide, donc les deux blocs carrousel en héritent.

`assets/css/editeur.css` ne contient donc **que** ce que le site ne connaît
pas : les états propres à l'édition — une piste vide, un bouton dont le libellé
n'est pas encore écrit. Rien de décoratif.

### 2. Le réglage est là où se trouve la chose

- Ce qui **s'écrit** s'écrit dans le bloc (`RichText`) : titres, chapôs,
  libellés de boutons.
- Ce qui **se choisit d'un geste** est dans la barre d'outils : niveau de
  titre, sens de l'image, lien.
- La **colonne de droite** ne garde que ce qui ne se montre pas : la source des
  publications, le décor.

Un panneau de moins, c'est un aller-retour de moins. Et quand un réglage vaut
la peine d'être expliqué, l'explication est dans son `help`, pas dans une
documentation que personne n'ouvrira.

## Structure

| Chemin | Rôle |
|---|---|
| `salama-blocs.php` | Bootstrap, constantes, chargement des modules |
| `inc/blocs.php` | Catégorie « Salama », assets partagés, enregistrement des blocs |
| `inc/editeur.php` | Types de publication et routes d'aperçu (carrousels, calendrier) |
| `inc/reservations.php` | Le secours du type « Réservations » (ACF le déclare) et le panneau du calendrier |
| `inc/motifs.php` | Motifs : bannière d'accueil, page d'accueil complète |
| `inc/rendu.php` | Aides de rendu : image ou surface d'attente, rappel admin, niveau de titre, mise en forme d'un prix |
| `blocs/*/block.json` | Déclaration de chaque bloc, et ses variantes d'inséreur |
| `blocs/*/rendu.php` | Rendu public |
| `assets/js/editeur.js` | Éditeur des blocs |
| `assets/css/blocs.css` | Styles du site public |
| `assets/css/editeur.css` | États que seul l'éditeur connaît |

## Les blocs

### Salama — Contact

Maquette de formulaire sur fond vert : prénom et nom côte à côte, mail,
téléphone, sujet, message et bouton « Envoyer ». Sur mobile, prénom et nom
s'empilent. Le titre se modifie dans le bloc et son niveau dans la barre d'outils.
Les champs et le bouton sont désactivés : aucun envoi, aucune collecte de données.
Le rendu PHP n'utilise pas de balise `form` ni de traitement serveur.

### Salama — Titre avec flag

Un bandeau vert sur un cercle rose face à un titre, comme sur la maquette
« Mes méthodes ». Les deux textes se modifient directement dans le bloc.
La barre d'outils permet de choisir le niveau du titre (H2 à H6) et d'inverser
le sens : le titre, le bandeau et le cercle changent de côté ensemble.
Sur mobile, les éléments s'empilent en conservant le sens choisi.
Les couleurs et les arrondis utilisent les jetons du thème.

### Salama — Texte et image

La section « Qui suis-je ? » : une colonne de texte face à une image décorée.

| Réglage | Où | Défaut |
|---|---|---|
| Titre | Dans le bloc | « Qui suis-je ? » |
| Niveau du titre | Barre d'outils | `h2` (le `h1` revient à la page) |
| Position de l'image | Barre d'outils | À droite du texte |
| Image | Barre d'outils | — |
| Bloc rosé derrière l'image | Colonne de droite | activé |
| Disque orange | Colonne de droite | activé |
| Coup de pinceau sous le texte | Colonne de droite | activé |

Le sens de la mise en page se choisit d'un geste, avec deux icônes qui montrent
le résultat, là où un menu déroulant demandait de lire deux libellés.

Le corps du texte est un **InnerBlocks libre** : la rédaction y écrit avec les
blocs qu'elle connaît — paragraphes, listes, gras, liens — pendant que le bloc
garde la main sur la colonne, l'image et le décor.

### Salama — Spécialités

La grille de cartes, sous un titre de section. Elle n'accepte que des cartes,
et en propose deux à l'insertion. On peut en ajouter autant qu'on veut.

### Salama — Carte de spécialité

Une image entièrement cliquable, coiffée d'une pastille qui porte son libellé.

| Réglage | Où | Rôle |
|---|---|---|
| Libellé | Dans le bloc | Texte de la pastille |
| Image | Barre d'outils | Visuel de la carte |
| Lien | Barre d'outils | Recherche de page, ou adresse collée. Les ancres sont acceptées : `/ma-page/#ma-section` |
| Nouvel onglet | Barre d'outils | Dans le même panneau que le lien |

Le lien passe par le bouton **Lien** de la barre d'outils : la même commande,
le même popover et la même recherche par titre de page que sur un texte ou un
bouton natif. La colonne de droite ne garde qu'un rappel quand la carte n'a pas
encore de destination.

### Salama — Carrousel · Carrousel vertical (× 2 avec fond)

Les dernières publications d'un type de contenu, en cartes qui défilent.

**Deux blocs, quatre entrées d'inséreur.** Chaque bloc porte deux *variantes*,
avec ou sans fond, et un interrupteur « Fond rosé » pour passer de l'une à
l'autre après coup — sans supprimer le bloc et le refaire.

| Entrée de l'inséreur | Bloc | Sens |
|---|---|---|
| Salama — Carrousel | `salama/carrousel` | horizontal |
| Salama — Carrousel avec fond | `salama/carrousel` | horizontal |
| Salama — Carrousel vertical | `salama/carrousel-vertical` | vertical |
| Salama — Carrousel vertical avec fond | `salama/carrousel-vertical` | vertical |

Les deux blocs ont **les mêmes réglages et le même aperçu**. Leur `edit` est
produit une seule fois, par `editCarrousel( sens )`, et appelé deux fois : sans
cela, la moindre correction d'aperçu serait à faire à deux endroits — c'est
précisément le prix que ce plugin paie déjà ailleurs (voir *Choix techniques*),
et qu'il ne fallait pas payer deux fois.

Côté PHP, les deux `rendu.php` appellent le même `salama_carousel()` du thème,
avec un argument `sens` en plus pour le vertical, et composent leurs classes avec
`salama_carousel_classes()` — le pendant exact de `classesCarrousel()` en
JavaScript. Les deux côtés posent donc littéralement les mêmes classes.

| Réglage | Où | Défaut |
|---|---|---|
| Titre | Dans le bloc | vide |
| Chapô | Dans le bloc, sous le titre | vide |
| Libellé du bouton | Dans le bloc, sous les cartes | vide |
| Niveau du titre | Barre d'outils | `h2` |
| Type de publication | Colonne de droite | Ateliers |
| Nombre affiché | Colonne de droite | 5 |
| Fond rosé | Colonne de droite | non |

Le **balisage vient du thème** (`salama_carousel()`) : un carrousel posé au
bloc, au code court `[carrousel]` ou appelé depuis un gabarit PHP donne
exactement le même résultat.

Le **titre porte toujours la même taille**, quel que soit son niveau. C'est le
point de départ de ce bloc : tant que le titre était un bloc Titre posé
au-dessus du carrousel, sa taille suivait son niveau, et deux carrousels d'une
même page ne se répondaient pas.

Le **bouton mène tout seul** à la page qui liste ce type de contenu : il n'y a
pas d'adresse à saisir, donc pas d'adresse qui puisse devenir fausse. Seul son
libellé se règle — vide, il ne s'affiche pas.

La liste des types de publication vient de PHP : un type de contenu créé plus
tard y apparaît sans qu'on touche au JavaScript.

Le niveau descend ici jusqu'à `h1`, contrairement aux autres blocs : la page
« Ateliers et Retraites » utilise le gabarit « Page sans en-tête », et c'est
son premier carrousel qui porte le `h1`.

### Salama — Tarifs · Ligne de tarif

Un tableau de prestations : le nom d'un côté, le prix de l'autre, et un
complément facultatif — une durée, une précision, une option.

| Réglage | Où | Défaut |
|---|---|---|
| Titre | Dans le bloc | vide |
| Introduction | Dans le bloc, sous le titre | vide |
| Intitulés des colonnes | Dans l'en-tête du tableau | Prestation / Tarif / Complément |
| Note | Dans le bloc, sous le tableau | vide |
| Niveau du titre | Barre d'outils | `h2` |
| Colonne « complément » | Colonne de droite | affichée |
| Ligne d'en-tête | Colonne de droite | affichée |
| Panneau vert | Colonne de droite | non |

Chaque ligne est un bloc **Salama — Ligne de tarif**, comme une carte dans une
grille de cartes. Elle porte la prestation, le prix, le complément, et un
interrupteur « mettre en avant » qui pose un aplat léger.

**Le prix se tape en chiffres, l'euro est posé par le rendu.** « 45 » devient
« 45 € », « 45.50 » devient « 45,50 € ». Un texte qui n'est pas un nombre —
« sur devis » — s'affiche tel quel, sans devise : lui coller un € en ferait une
phrase fausse. Un euro déjà tapé est retiré avant d'être reposé, pour qu'une
ligne saisie à l'ancienne n'en porte pas deux. Un prix vide affiche un tiret.

**Le tableau lit la largeur de son conteneur, pas celle de l'écran.** C'est une
requête de conteneur (`@container`), et c'est ce qui lui permet de tenir dans
une demi-colonne à côté du formulaire de contact : sous 26 rem de conteneur,
l'en-tête disparaît et chaque ligne se replie, chaque valeur annonçant de quoi
elle parle. Le même bloc, sur le même écran, s'affiche donc en trois colonnes
en pleine page et en lignes empilées dans une colonne étroite.

La variante **avec fond** pose le tableau sur le même panneau vert que le
formulaire de contact : posés côte à côte dans deux colonnes, les deux blocs se
lisent comme deux panneaux du même objet.

**Les rôles ARIA sont écrits à la main** — `role="table"`, `role="row"`,
`role="cell"` — parce que le CSS change le `display` des lignes dès que le bloc
est à l'étroit. Sans eux, un lecteur d'écran perdrait la structure au moment
précis où elle devient la plus utile.

### Salama — Calendrier de réservation

Le mois en cours face à la liste des prestations réservables. **C'est une
maquette**, au même titre que le bloc Contact : les flèches, les créneaux et le
bouton « Réserver » sont des commandes désactivées, rien n'est envoyé, rien
n'est enregistré.

| Réglage | Où | Défaut |
|---|---|---|
| Titre | Dans le bloc | « RÉSERVER UNE SÉANCE » |
| Chapô | Dans le bloc, sous le titre | vide |
| Niveau du titre | Barre d'outils | `h2` |

Il n'y a rien d'autre à régler : le mois affiché est celui d'aujourd'hui, et la
liste des prestations vient du back-office.

**Les prestations se saisissent dans le menu « Réservations ».** C'est un type
de contenu à part (`salama_resa`), **déclaré par ACF** depuis la version 1.2 du
pack : il se règle dans *ACF → Types de publication*, comme Ateliers et
Retraites. Lui ajouter un champ, une taxonomie ou un support ne demande donc
plus de toucher au code.

Il n'est pas public : ces prestations n'ont ni page, ni archive, ni place dans
la recherche — elles n'existent que dans les blocs qui les citent. Mais elles
prennent le titre, le contenu, l'extrait, l'image mise en avant, l'ordre
d'affichage, les champs personnalisés et les révisions : de quoi décrire une
prestation, et pas seulement la nommer. Le champ « Ordre » des attributs range
la liste ; à égalité, c'est l'ordre de création qui tranche.

`inc/reservations.php` garde une déclaration de secours, en priorité 20 sur
`init` — après ACF — qui ne fait rien si le type existe déjà. C'est ce qui
permet d'installer le pack sur un site sans ACF sans que le calendrier ne perde
ses prestations.

**Les disponibilités sont une décoration, pas une donnée.** Tant que rien n'est
réservable pour de bon, le calendrier montre à quoi ressemblera un mois ouvert :
les mardis, jeudis et samedis à venir portent la pastille verte, le premier
d'entre eux prend l'accent mauve, et les jours écoulés s'effacent. La règle est
écrite une seule fois, dans `salama_blocs_calendrier_mois()`.

**Le panneau vient du serveur**, comme la piste d'un carrousel : il dépend du
mois en cours et de ce qui a été saisi en back-office, deux choses que
l'éditeur ne peut pas deviner. La route `salama/v1/calendrier` rend exactement
le même balisage que le site — l'aperçu ne peut pas diverger. Seuls le titre et
le chapô s'écrivent dans le bloc.

**Le bouton porte l'accent en aplat**, avec `--salama-color-cta-text` dessus :
c'est l'usage que `jetons.css` décrit pour cette encre, et il tient 8,8:1. Le
bouton du bloc Contact pose l'inverse — mauve sur blanc, autour de 1,9:1 — et
n'était pas un exemple à suivre.

Sans aucun élément de réservation, la colonne affiche le rappel réservé aux
administrateurs, selon la convention des états vides ci-dessous.

## Ce qui se déduit tout seul

**Le sens du débord du bloc d'accent.** Carte impaire, il déborde à gauche ;
paire, à droite — les cartes s'ouvrent vers l'extérieur, comme sur la maquette.
C'est du `:nth-child` en CSS, pas un attribut : il n'y a rien à régler, et une
troisième carte s'insère sans que personne ait à y penser.

**Le format des images.** Le CSS recadre en 6/5 avec `object-fit`, quelles que
soient les dimensions du fichier déposé.

## Le survol

Le décor sert le survol au lieu d'ajouter un effet de plus : **le bloc d'accent
glisse sous l'image et l'écart se referme**, comme si la carte se posait.
S'y ajoutent trois gestes qui existent déjà ailleurs sur le site — le zoom de
`.card__media img`, le filet de `.card__label`, l'ombre de `.salama-btn`.

Sous `prefers-reduced-motion`, le bloc reste en place et l'image ne zoome plus :
ce sont les deux gestes qui déplacent de la matière. Le filet et l'ombre
restent, pour que l'état survolé demeure perceptible.

## États vides

Convention reprise du thème — posée par le calendrier, les coordonnées et les
carrousels : **le visiteur ne voit rien, la rédaction voit ce qu'il reste à
remplir.**

| Situation | Visiteur | Administrateur |
|---|---|---|
| Aucune image | Surface rosée d'attente | idem |
| Carte sans lien | Carte affichée, non cliquable | Rappel « lien à renseigner » |
| Grille sans carte | Rien | Rappel « ajouter une carte » |
| Calendrier sans élément de réservation | Le mois seul | Rappel « ajoutez-en dans le menu Réservations » |

Une carte sans lien n'est pas rendue en `<a href="">` : ce lien renverrait le
visiteur sur la page courante. Mieux vaut un bloc inerte qu'un lien menteur.

## Choix techniques

**Rendu PHP, pas de `save` statique.** Le markup vit à un seul endroit et peut
évoluer sans imposer de dépréciations de blocs ni casser le contenu déjà
enregistré en base. Seuls les blocs à contenu interne ont un `save`, et il ne
rend que `InnerBlocks.Content`.

**Aucune étape de build.** L'éditeur est écrit en JavaScript natif
(`wp.element.createElement`), pas en JSX — le thème n'a aucun outil de build et
on ne lui en impose pas un pour cinq blocs. Le prix à payer : les fonctions
`edit` reproduisent la structure du rendu PHP, donc un changement de balisage se
fait à deux endroits. Le carrousel échappe à ce prix : ses cartes viennent du
serveur, il n'y a rien à reproduire.

**Les composants stabilisés au fil des versions sont pris avec repli.**
`HeadingLevelDropdown` et `LinkControl` ont vécu sous un préfixe `__experimental`
avant d'être stabilisés. `editeur.js` prend le nom définitif s'il existe,
l'expérimental sinon, et retombe sur un champ de la colonne de droite si aucun
des deux n'est là : un bloc doit rester réglable, même sur une version plus
ancienne de WordPress.

Les blocs sont déclarés par leurs `block.json` côté PHP. `editeur.js` ne fournit
que `edit` et `save` : attributs, titre, catégorie et supports viennent du
serveur, les redire ici serait de la dérive en puissance.

**Une seule feuille, un seul script pour tous les blocs.** Les `block.json` y
renvoient par identifiant plutôt que par fichier : des blocs qui vont toujours
ensemble n'ont pas à coûter une requête chacun. WordPress ne les charge que sur
les pages qui portent effectivement un bloc `salama/*`.

## La bannière d'accueil

Ce n'est **pas** un bloc de ce plugin mais un motif de blocs natifs
(`inc/motifs.php`) : elle ne figurait pas sur la maquette, son dessin n'est donc
pas arrêté. Un motif se retouche dans l'éditeur, un bloc se recode.

Son CSS vit dans `composants.css` du thème, pas ici : la feuille du plugin
n'est chargée que sur les pages portant un bloc `salama/*`, et une bannière
faite de blocs natifs ne la déclencherait jamais. Elle y gagne au passage
l'aperçu dans l'éditeur, puisque le thème charge cette feuille des deux côtés.

L'attribut `isDark` y est explicitement à `false`. Sans cela le bloc Couverture
se croit sombre et écrit en blanc — sur le rosé `#adebb3`, le titre tombait à
**1,12:1**. Le jour où une photo sombre arrivera en fond, l'éditeur remettra
l'attribut à `true` tout seul et le texte repassera au blanc : le CSS du thème
ne s'applique qu'à la variante `.is-light`.

## À faire

- Rendre le calendrier fonctionnel : ce n'est pour l'instant qu'un dessin.
  Deux chemins possibles — brancher les éléments de réservation sur
  l'intégration Cal.com que le thème porte déjà (`inc/booking.php`), ou leur
  donner leurs propres créneaux

- Les sections d'accueil suivantes, absentes de la maquette fournie
- Remplacer les textes de remplacement de « Qui suis-je ? »
- La section portant l'ancre `#accompagnement-des-femmes`, sur la page
  Sophrologies, aujourd'hui vide
- Remplacer les chapôs en faux-texte des deux carrousels de la page
  « Ateliers et Retraites »
