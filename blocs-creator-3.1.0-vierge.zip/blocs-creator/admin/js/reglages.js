/*
 * L'écran des réglages : ses onglets, et le tri de la liste des blocs.
 *
 * Les trois sections sont dans un seul formulaire, et y restent : les onglets
 * ne font que masquer, jamais retirer. C'est ce qui permet de cocher des blocs
 * dans l'un, de changer une apparition dans l'autre, et de n'appuyer qu'une
 * fois sur « Enregistrer ».
 *
 * Écrit en JavaScript natif, sans dépendance : le plugin s'installe partout
 * sans outil de build.
 */

( function ( document ) {
	'use strict';

	function onglets() {
		var boutons = document.querySelectorAll( '[data-bc-onglet]' );

		if ( ! boutons.length ) {
			return;
		}

		Array.prototype.forEach.call( boutons, function ( bouton ) {
			bouton.addEventListener( 'click', function () {
				var cible = bouton.getAttribute( 'data-bc-onglet' );

				Array.prototype.forEach.call( boutons, function ( autre ) {
					autre.classList.toggle( 'nav-tab-active', autre === bouton );
				} );

				Array.prototype.forEach.call(
					document.querySelectorAll( '[data-bc-panneau]' ),
					function ( panneau ) {
						panneau.hidden = panneau.getAttribute( 'data-bc-panneau' ) !== cible;
					}
				);
			} );
		} );
	}

	function groupes() {
		Array.prototype.forEach.call(
			document.querySelectorAll( '[data-bc-tout]' ),
			function ( bouton ) {
				bouton.addEventListener( 'click', function () {
					var groupe = bouton.closest( '.bc-groupe-blocs' );
					var coche  = '1' === bouton.getAttribute( 'data-bc-tout' );

					if ( ! groupe ) {
						return;
					}

					Array.prototype.forEach.call(
						groupe.querySelectorAll( '.bc-blocs__item:not([hidden]) input[type="checkbox"]:not(:disabled)' ),
						function ( case_a_cocher ) {
							case_a_cocher.checked = coche;
						}
					);
				} );
			}
		);
	}

	/**
	 * Filtre la liste des blocs sur la saisie, groupe par groupe.
	 *
	 * Un groupe dont plus rien ne correspond se masque entièrement : laisser
	 * un titre de section seul au-dessus du vide ne dit rien à personne.
	 */
	function filtre() {
		var champ = document.getElementById( 'bc-filtre-blocs' );

		if ( ! champ ) {
			return;
		}

		champ.addEventListener( 'input', function () {
			var terme = champ.value.trim().toLowerCase();

			Array.prototype.forEach.call(
				document.querySelectorAll( '.bc-groupe-blocs' ),
				function ( groupe ) {
					var visibles = 0;

					Array.prototype.forEach.call(
						groupe.querySelectorAll( '.bc-blocs__item' ),
						function ( item ) {
							var trouve =
								'' === terme ||
								-1 !== ( item.getAttribute( 'data-bc-cherche' ) || '' ).indexOf( terme );

							item.hidden = ! trouve;

							if ( trouve ) {
								visibles += 1;
							}
						}
					);

					groupe.hidden = 0 === visibles;
				}
			);
		} );
	}

	function demarrer() {
		onglets();
		groupes();
		filtre();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', demarrer );
	} else {
		demarrer();
	}
}( document ) );
